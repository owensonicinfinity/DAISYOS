/* ═══════════════════════════════════════════════════
   DAISY GT — Service Worker
   PWA offline caching + push notifications
═══════════════════════════════════════════════════ */

const CACHE_NAME = 'daisygt-v1';
const STATIC_CACHE = 'daisygt-static-v1';

const PRECACHE_URLS = [
  '/',
  '/index.html',
  '/static/css/main.chunk.css',
  '/static/js/main.chunk.js',
  '/static/js/bundle.js',
];

// ─── Install ────────────────────────────────────────
self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(STATIC_CACHE).then((cache) => {
      return cache.addAll(PRECACHE_URLS).catch(() => {
        // Silently fail on missing files during dev
      });
    })
  );
  self.skipWaiting();
});

// ─── Activate ───────────────────────────────────────
self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((keys) =>
      Promise.all(
        keys.filter(k => k !== CACHE_NAME && k !== STATIC_CACHE).map(k => caches.delete(k))
      )
    )
  );
  self.clients.claim();
});

// ─── Fetch (Network first, cache fallback) ─────────
self.addEventListener('fetch', (event) => {
  const { request } = event;

  // Skip non-GET and chrome-extension requests
  if (request.method !== 'GET' || request.url.startsWith('chrome-extension')) return;

  // API calls — network only, no cache
  if (request.url.includes('generativelanguage.googleapis.com') ||
      request.url.includes('api.anthropic.com')) {
    return;
  }

  event.respondWith(
    fetch(request)
      .then((response) => {
        if (response.ok) {
          const clone = response.clone();
          caches.open(CACHE_NAME).then((cache) => cache.put(request, clone));
        }
        return response;
      })
      .catch(() => caches.match(request).then(cached => cached || caches.match('/index.html')))
  );
});

// ─── Push Notifications ─────────────────────────────
self.addEventListener('push', (event) => {
  let data = { title: 'Daisy GT', body: 'You have a new notification', icon: '/favicon.ico', badge: '/favicon.ico' };
  try { data = { ...data, ...event.data.json() }; } catch {}

  event.waitUntil(
    self.registration.showNotification(data.title, {
      body: data.body,
      icon: data.icon || '/favicon.ico',
      badge: data.badge || '/favicon.ico',
      tag: data.tag || 'daisygt',
      data: data,
      vibrate: [200, 100, 200],
      actions: data.actions || [],
    })
  );
});

// ─── Notification Click ─────────────────────────────
self.addEventListener('notificationclick', (event) => {
  event.notification.close();
  const url = event.notification.data?.action || '/app';
  event.waitUntil(
    clients.matchAll({ type: 'window' }).then((windowClients) => {
      for (const client of windowClients) {
        if (client.url.includes(self.location.origin) && 'focus' in client) {
          client.navigate(url);
          return client.focus();
        }
      }
      if (clients.openWindow) return clients.openWindow(url);
    })
  );
});

// ─── Background Sync (offline uploads) ──────────────
self.addEventListener('sync', (event) => {
  if (event.tag === 'daisygt-upload-telemetry') {
    event.waitUntil(
      // Notify the app to trigger upload
      clients.matchAll().then(clientList => {
        clientList.forEach(client => client.postMessage({ type: 'SYNC_TELEMETRY' }));
      })
    );
  }
});

self.addEventListener('message', (event) => {
  if (event.data?.type === 'SKIP_WAITING') self.skipWaiting();
});
