import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useNotifStore } from '../store/notifStore';

function timeAgo(iso) {
  const diff = Date.now() - new Date(iso).getTime();
  const m = Math.floor(diff / 60000);
  if (m < 1) return 'just now';
  if (m < 60) return `${m}m ago`;
  const h = Math.floor(m / 60);
  if (h < 24) return `${h}h ago`;
  return `${Math.floor(h / 24)}d ago`;
}

export default function NotifPanel() {
  const [open, setOpen] = useState(false);
  const { notifications, unreadCount, markRead, markAllRead } = useNotifStore();
  const navigate = useNavigate();

  const handleClick = (n) => {
    markRead(n.id);
    if (n.action) navigate(n.action);
    setOpen(false);
  };

  return (
    <>
      {/* Bell button */}
      <button
        onClick={() => setOpen(o => !o)}
        style={{
          position: 'relative',
          background: 'none',
          border: 'none',
          cursor: 'pointer',
          color: 'var(--chrome-dim)',
          fontSize: 18,
          padding: '4px 6px',
          display: 'flex',
          alignItems: 'center',
          transition: 'color 0.15s',
        }}
        title="Notifications"
        onMouseEnter={e => e.currentTarget.style.color = 'var(--chrome)'}
        onMouseLeave={e => e.currentTarget.style.color = 'var(--chrome-dim)'}
      >
        🔔
        {unreadCount > 0 && (
          <span style={{
            position: 'absolute',
            top: 0, right: 0,
            background: 'var(--red)',
            color: '#fff',
            fontSize: 9,
            fontFamily: 'var(--font-mono)',
            fontWeight: 700,
            width: 16, height: 16,
            borderRadius: '50%',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            border: '1px solid var(--bg-panel)',
          }}>
            {unreadCount > 9 ? '9+' : unreadCount}
          </span>
        )}
      </button>

      {/* Panel */}
      {open && (
        <>
          <div
            style={{ position: 'fixed', inset: 0, zIndex: 198 }}
            onClick={() => setOpen(false)}
          />
          <div style={{
            position: 'fixed',
            top: 60, right: 12,
            width: 320,
            maxHeight: '70vh',
            background: 'var(--bg-panel)',
            border: '1px solid rgba(255,255,255,0.08)',
            borderRadius: 2,
            zIndex: 199,
            boxShadow: '0 12px 40px rgba(0,0,0,0.7)',
            display: 'flex',
            flexDirection: 'column',
            overflow: 'hidden',
          }}>
            {/* Header */}
            <div style={{ padding: '12px 14px', borderBottom: 'var(--border)', display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexShrink: 0 }}>
              <span style={{ fontFamily: 'var(--font-display)', fontSize: 12, fontWeight: 700, letterSpacing: '0.08em', textTransform: 'uppercase', color: 'var(--chrome-bright)' }}>
                Notifications {unreadCount > 0 && <span style={{ color: 'var(--red)' }}>({unreadCount})</span>}
              </span>
              {unreadCount > 0 && (
                <button onClick={markAllRead} style={{ background: 'none', border: 'none', cursor: 'pointer', fontSize: 11, color: 'var(--red)', fontFamily: 'var(--font-display)', letterSpacing: '0.04em' }}>
                  Mark all read
                </button>
              )}
            </div>

            {/* List */}
            <div style={{ flex: 1, overflowY: 'auto' }}>
              {notifications.length === 0 ? (
                <div style={{ textAlign: 'center', padding: '40px 20px', color: 'var(--chrome-dim)' }}>
                  <div style={{ fontSize: 32, marginBottom: 8 }}>🔔</div>
                  <p style={{ fontSize: 12 }}>No notifications yet</p>
                </div>
              ) : notifications.map(n => (
                <button
                  key={n.id}
                  onClick={() => handleClick(n)}
                  style={{
                    width: '100%',
                    textAlign: 'left',
                    background: n.read ? 'transparent' : 'rgba(224,0,32,0.04)',
                    border: 'none',
                    borderBottom: 'var(--border)',
                    padding: '12px 14px',
                    cursor: 'pointer',
                    display: 'flex',
                    gap: 10,
                    alignItems: 'flex-start',
                    transition: 'background 0.15s',
                  }}
                  onMouseEnter={e => e.currentTarget.style.background = 'rgba(255,255,255,0.03)'}
                  onMouseLeave={e => e.currentTarget.style.background = n.read ? 'transparent' : 'rgba(224,0,32,0.04)'}
                >
                  <span style={{ fontSize: 18, flexShrink: 0, lineHeight: 1.4 }}>{n.icon}</span>
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', gap: 6 }}>
                      <span style={{ fontFamily: 'var(--font-display)', fontSize: 12, fontWeight: 700, color: n.read ? 'var(--chrome)' : 'var(--chrome-bright)', letterSpacing: '0.04em', textTransform: 'uppercase' }}>{n.title}</span>
                      {!n.read && <div style={{ width: 6, height: 6, borderRadius: '50%', background: 'var(--red)', flexShrink: 0, marginTop: 4 }} />}
                    </div>
                    <p style={{ fontSize: 12, color: 'var(--chrome-dim)', marginTop: 2, lineHeight: 1.5 }}>{n.body}</p>
                    <span style={{ fontFamily: 'var(--font-mono)', fontSize: 9, color: 'rgba(200,205,216,0.4)', marginTop: 4, display: 'block' }}>{timeAgo(n.createdAt)}</span>
                  </div>
                </button>
              ))}
            </div>
          </div>
        </>
      )}
    </>
  );
}
