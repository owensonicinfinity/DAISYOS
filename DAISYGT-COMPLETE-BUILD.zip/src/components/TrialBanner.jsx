import React, { useState } from 'react';
import { useAuthStore } from '../store/authStore';

export default function TrialBanner() {
  const { trialActive, daysLeftInTrial, activateTrial, subscription } = useAuthStore();
  const [code, setCode] = useState('');
  const [showInput, setShowInput] = useState(false);
  const [msg, setMsg] = useState('');
  const days = daysLeftInTrial();

  if (trialActive && days > 0) {
    return (
      <div style={{
        background: 'linear-gradient(90deg, rgba(0,229,255,0.08), rgba(0,229,255,0.03))',
        borderBottom: '1px solid rgba(0,229,255,0.2)',
        padding: '8px 16px',
        display: 'flex', alignItems: 'center', justifyContent: 'space-between',
        fontSize: 12, gap: 12,
      }}>
        <span style={{ fontFamily: 'var(--font-mono)', color: 'var(--cyan)' }}>
          ⚡ ELITE TRIAL — {days} DAYS REMAINING
        </span>
        <span style={{ color: 'var(--chrome-dim)' }}>Full access to all features including Dyno + Ghost Racing</span>
      </div>
    );
  }

  if (subscription !== 'free') return null;

  return (
    <div style={{
      background: 'rgba(224,0,32,0.05)',
      borderBottom: '1px solid rgba(224,0,32,0.15)',
      padding: '8px 16px',
      display: 'flex', alignItems: 'center', gap: 12, flexWrap: 'wrap',
      fontSize: 12,
    }}>
      <span style={{ color: 'var(--chrome-dim)' }}>
        🎁 Have a free trial code?
      </span>
      {!showInput ? (
        <button onClick={() => setShowInput(true)}
          style={{ fontSize: 11, padding: '4px 10px', background: 'var(--bg-surface)', border: 'var(--border)', color: 'var(--red)', borderRadius: 1, cursor: 'pointer', fontFamily: 'var(--font-display)', letterSpacing: '0.06em', textTransform: 'uppercase' }}>
          Enter Code
        </button>
      ) : (
        <div style={{ display: 'flex', gap: 6 }}>
          <input
            value={code}
            onChange={e => setCode(e.target.value.toUpperCase())}
            placeholder="DAISYGT-FREE-2025"
            style={{ width: 180, fontSize: 11, padding: '4px 8px', fontFamily: 'var(--font-mono)' }}
          />
          <button onClick={() => {
            if (activateTrial(code)) setMsg('✅ 14-day Elite trial activated!');
            else setMsg('❌ Invalid code');
            setTimeout(() => setMsg(''), 3000);
          }} className="btn btn-primary btn-sm">Apply</button>
        </div>
      )}
      {msg && <span style={{ fontFamily: 'var(--font-mono)', color: msg.startsWith('✅') ? 'var(--green)' : 'var(--red)', fontSize: 11 }}>{msg}</span>}
      <span style={{ marginLeft: 'auto', color: 'var(--chrome-dim)', fontFamily: 'var(--font-mono)', fontSize: 10 }}>
        Trial code: <span style={{ color: 'var(--yellow)' }}>DAISYGT-FREE-2025</span>
      </span>
    </div>
  );
}
