import React, { useState } from 'react';
import toast from 'react-hot-toast';

const WRAP_COLORS = [
  '#e00020','#ff1a35','#c8002a',  // reds
  '#0066ff','#004cc4','#00e5ff',  // blues
  '#00cc44','#00ff88','#009933',  // greens
  '#ffcc00','#ff9900','#ff6b00',  // yellows/oranges
  '#9900ff','#cc00ff','#6600cc',  // purples
  '#ffffff','#c8cdd8','#7a8090',  // whites/greys
  '#111116','#050506','#1e1e28',  // blacks/darks
  '#8B4513','#D2691E','#A0522D',  // browns
  '#FF69B4','#FF1493','#C71585',  // pinks
];

const WRAP_PATTERNS = [
  { id: 'solid', label: 'Solid', preview: (c) => c },
  { id: 'matte', label: 'Matte', preview: (c) => c },
  { id: 'carbon', label: 'Carbon Fiber', preview: () => '#1a1a1a' },
  { id: 'chrome', label: 'Chrome', preview: () => '#c0c0c0' },
  { id: 'pearl', label: 'Pearl', preview: (c) => c },
  { id: 'satin', label: 'Satin', preview: (c) => c },
  { id: 'gloss', label: 'Gloss', preview: (c) => c },
  { id: 'racing_stripe', label: 'Racing Stripe', preview: (c) => c },
  { id: 'flames', label: 'Flames', preview: () => '#ff4400' },
  { id: 'camo', label: 'Camo', preview: () => '#4a5c2a' },
  { id: 'digital_camo', label: 'Digital Camo', preview: () => '#2a3a4a' },
  { id: 'two_tone', label: 'Two Tone', preview: (c) => c },
];

const RIM_STYLES = ['Stock','OEM+','Concave Mesh','Multi-Spoke','Forged Mono','Deep Dish','Star','Flow Form','Directional','Flush','Staggered'];
const TINT_LEVELS = ['None', 'Light (30%)', 'Medium (20%)', 'Dark (15%)', 'Limo (5%)', 'Blackout'];
const UNDERGLOW = ['Off', 'Red', 'Blue', 'Green', 'Purple', 'Cyan', 'White', 'Rainbow RGB', 'Police RGB'];
const DECALS = ['None', 'Racing Numbers', 'Sponsor Logos', 'Flames', 'Tribal', 'Carbon Accents', 'Pinstripes', 'Checkered', 'DaisyGT Watermark', 'Custom Text'];

export default function VehicleCustomizer({ vehicle, onSave, onClose }) {
  const [config, setConfig] = useState({
    wrapColor: vehicle?.color || '#e00020',
    wrapPattern: 'solid',
    accentColor: '#ffffff',
    rimStyle: 'Concave Mesh',
    rimColor: '#c8cdd8',
    tint: 'Medium (20%)',
    underglow: 'Off',
    decal: 'None',
    customText: '',
    lowered: false,
    widebody: false,
    spoiler: 'None',
    exhaust: 'Stock',
    numberPlate: '',
  });

  const set = (k, v) => setConfig(c => ({ ...c, [k]: v }));

  const handleSave = () => {
    onSave({ ...vehicle, color: config.wrapColor, customization: config });
    toast.success('Vehicle customization saved! 🔥');
  };

  // SVG car preview
  const CarPreview = () => (
    <svg viewBox="0 0 220 100" style={{ width: '100%', height: 'auto', maxHeight: 160 }}>
      <defs>
        <linearGradient id="bodyGrad" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor={config.wrapColor} stopOpacity="1" />
          <stop offset="100%" stopColor={config.wrapColor} stopOpacity="0.7" />
        </linearGradient>
        {config.wrapPattern === 'carbon' && (
          <pattern id="carbonPat" x="0" y="0" width="6" height="6" patternUnits="userSpaceOnUse">
            <rect width="3" height="3" fill="#222" />
            <rect x="3" y="3" width="3" height="3" fill="#222" />
            <rect x="3" y="0" width="3" height="3" fill="#2a2a2a" />
            <rect x="0" y="3" width="3" height="3" fill="#2a2a2a" />
          </pattern>
        )}
        {config.wrapPattern === 'chrome' && (
          <linearGradient id="chromePat" x1="0%" y1="0%" x2="0%" y2="100%">
            <stop offset="0%" stopColor="#f0f0f0" />
            <stop offset="40%" stopColor="#c0c0c0" />
            <stop offset="70%" stopColor="#e8e8e8" />
            <stop offset="100%" stopColor="#a0a0a0" />
          </linearGradient>
        )}
      </defs>

      {/* Body */}
      <path d="M 20 65 L 30 40 L 60 28 L 130 25 L 170 35 L 195 55 L 200 65 L 200 75 L 20 75 Z"
        fill={config.wrapPattern === 'carbon' ? 'url(#carbonPat)' : config.wrapPattern === 'chrome' ? 'url(#chromePat)' : `url(#bodyGrad)`}
        stroke="rgba(255,255,255,0.1)" strokeWidth="0.5"
      />
      {/* Windshield */}
      <path d="M 65 28 L 55 50 L 110 50 L 125 28 Z"
        fill="rgba(0,229,255,0.25)" stroke="rgba(0,229,255,0.5)" strokeWidth="0.5"
      />
      {/* Rear window */}
      <path d="M 130 26 L 145 26 L 165 42 L 155 50 L 130 50 Z"
        fill="rgba(0,229,255,0.2)" stroke="rgba(0,229,255,0.4)" strokeWidth="0.5"
      />
      {/* Front wheel arch */}
      <ellipse cx="60" cy="76" rx="18" ry="10" fill="#111" stroke="rgba(255,255,255,0.1)" strokeWidth="0.5" />
      <ellipse cx="60" cy="76" rx="13" ry="7" fill={config.rimColor} opacity="0.9" />
      <ellipse cx="60" cy="76" rx="5" ry="3" fill="#222" />
      {/* Rear wheel arch */}
      <ellipse cx="160" cy="76" rx="18" ry="10" fill="#111" stroke="rgba(255,255,255,0.1)" strokeWidth="0.5" />
      <ellipse cx="160" cy="76" rx="13" ry="7" fill={config.rimColor} opacity="0.9" />
      <ellipse cx="160" cy="76" rx="5" ry="3" fill="#222" />
      {/* Headlights */}
      <ellipse cx="196" cy="58" rx="5" ry="3" fill="#ffffaa" opacity="0.9" />
      {/* Tail lights */}
      <ellipse cx="22" cy="60" rx="4" ry="3" fill="#ff2200" opacity="0.9" />
      {/* Accent stripe */}
      {config.wrapPattern === 'racing_stripe' && (
        <path d="M 80 25 L 95 25 L 195 55 L 190 57 L 88 27 Z" fill={config.accentColor} opacity="0.8" />
      )}
      {/* Underglow */}
      {config.underglow !== 'Off' && (
        <ellipse cx="110" cy="79" rx="90" ry="6"
          fill={config.underglow === 'Red' ? 'rgba(224,0,32,0.6)' : config.underglow === 'Blue' ? 'rgba(0,100,255,0.6)' : config.underglow === 'Cyan' ? 'rgba(0,229,255,0.6)' : config.underglow === 'Green' ? 'rgba(0,255,100,0.6)' : 'rgba(200,200,200,0.4)'}
          filter="blur(3px)"
        />
      )}
      {/* Spoiler */}
      {config.spoiler !== 'None' && (
        <rect x="15" y="30" width="8" height="18" fill={config.wrapColor} stroke="rgba(255,255,255,0.2)" strokeWidth="0.5" rx="1" />
      )}
      {/* Number plate */}
      {config.numberPlate && (
        <rect x="85" y="70" width="40" height="10" fill="white" rx="1" />
      )}
      {config.numberPlate && (
        <text x="105" y="79" textAnchor="middle" fontSize="6" fontFamily="JetBrains Mono" fontWeight="700" fill="#111">{config.numberPlate.slice(0,7)}</text>
      )}
    </svg>
  );

  return (
    <div style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.9)', zIndex: 500, display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 16 }}>
      <div style={{ background: 'var(--bg-panel)', border: 'var(--border-red)', borderRadius: 2, width: '100%', maxWidth: 700, maxHeight: '92vh', display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>

        {/* Header */}
        <div style={{ padding: '14px 20px', borderBottom: 'var(--border)', display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexShrink: 0 }}>
          <div>
            <div style={{ fontFamily: 'var(--font-display)', fontSize: '1rem', fontWeight: 700, letterSpacing: '0.08em', textTransform: 'uppercase', color: 'var(--chrome-bright)' }}>
              🎨 Vehicle Customizer
            </div>
            <div style={{ fontSize: 11, color: 'var(--chrome-dim)', marginTop: 2 }}>{vehicle?.name || 'Vehicle'}</div>
          </div>
          <button onClick={onClose} style={{ background: 'none', border: 'none', color: 'var(--chrome-dim)', cursor: 'pointer', fontSize: 22 }}>×</button>
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: '1fr 260px', flex: 1, overflow: 'hidden' }}>

          {/* Controls */}
          <div style={{ padding: 16, overflowY: 'auto', borderRight: 'var(--border)' }}>

            {/* Wrap */}
            <div style={{ marginBottom: 18 }}>
              <label>Wrap Color</label>
              <div style={{ display: 'flex', flexWrap: 'wrap', gap: 5, marginTop: 6 }}>
                {WRAP_COLORS.map(c => (
                  <button key={c} onClick={() => set('wrapColor', c)}
                    style={{ width: 22, height: 22, background: c, border: config.wrapColor === c ? '2px solid white' : '1px solid rgba(255,255,255,0.12)', borderRadius: '50%', cursor: 'pointer', padding: 0, transition: 'transform 0.1s', transform: config.wrapColor === c ? 'scale(1.2)' : 'scale(1)' }}
                  />
                ))}
              </div>
            </div>

            {/* Pattern */}
            <div style={{ marginBottom: 16 }}>
              <label>Wrap Pattern</label>
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3,1fr)', gap: 5, marginTop: 6 }}>
                {WRAP_PATTERNS.map(p => (
                  <button key={p.id} onClick={() => set('wrapPattern', p.id)}
                    style={{ padding: '7px 4px', background: config.wrapPattern === p.id ? 'rgba(224,0,32,0.15)' : 'var(--bg-surface)', border: config.wrapPattern === p.id ? 'var(--border-red)' : 'var(--border)', borderRadius: 2, cursor: 'pointer', color: config.wrapPattern === p.id ? 'var(--red)' : 'var(--chrome-dim)', fontSize: 10, fontFamily: 'var(--font-display)', fontWeight: 600, letterSpacing: '0.04em', textTransform: 'uppercase' }}>
                    {p.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Accent */}
            <div style={{ marginBottom: 16 }}>
              <label>Accent Color</label>
              <div style={{ display: 'flex', flexWrap: 'wrap', gap: 5, marginTop: 6 }}>
                {WRAP_COLORS.slice(0, 12).map(c => (
                  <button key={c} onClick={() => set('accentColor', c)}
                    style={{ width: 22, height: 22, background: c, border: config.accentColor === c ? '2px solid white' : '1px solid rgba(255,255,255,0.12)', borderRadius: '50%', cursor: 'pointer', padding: 0 }}
                  />
                ))}
              </div>
            </div>

            {/* Two-column selects */}
            <div className="grid-2" style={{ gap: 10, marginBottom: 12 }}>
              <div>
                <label>Rim Style</label>
                <select value={config.rimStyle} onChange={e => set('rimStyle', e.target.value)} style={{ fontSize: 11 }}>
                  {RIM_STYLES.map(r => <option key={r}>{r}</option>)}
                </select>
              </div>
              <div>
                <label>Rim Color</label>
                <div style={{ display: 'flex', gap: 4, flexWrap: 'wrap', marginTop: 6 }}>
                  {['#c8cdd8','#ffffff','#1a1a1a','#e00020','#ffcc00','#00e5ff'].map(c => (
                    <button key={c} onClick={() => set('rimColor', c)}
                      style={{ width: 20, height: 20, background: c, border: config.rimColor === c ? '2px solid white' : '1px solid rgba(255,255,255,0.1)', borderRadius: '50%', cursor: 'pointer', padding: 0 }}
                    />
                  ))}
                </div>
              </div>
              <div>
                <label>Window Tint</label>
                <select value={config.tint} onChange={e => set('tint', e.target.value)} style={{ fontSize: 11 }}>
                  {TINT_LEVELS.map(t => <option key={t}>{t}</option>)}
                </select>
              </div>
              <div>
                <label>Underglow</label>
                <select value={config.underglow} onChange={e => set('underglow', e.target.value)} style={{ fontSize: 11 }}>
                  {UNDERGLOW.map(u => <option key={u}>{u}</option>)}
                </select>
              </div>
              <div>
                <label>Decals</label>
                <select value={config.decal} onChange={e => set('decal', e.target.value)} style={{ fontSize: 11 }}>
                  {DECALS.map(d => <option key={d}>{d}</option>)}
                </select>
              </div>
              <div>
                <label>Spoiler</label>
                <select value={config.spoiler} onChange={e => set('spoiler', e.target.value)} style={{ fontSize: 11 }}>
                  {['None','Ducktail','Wing','Diffuser','Lip','Whale Tail'].map(s => <option key={s}>{s}</option>)}
                </select>
              </div>
            </div>

            {/* Checkboxes */}
            <div style={{ display: 'flex', gap: 16, marginBottom: 12 }}>
              {[['lowered', 'Lowered'], ['widebody', 'Wide Body']].map(([key, label]) => (
                <label key={key} style={{ display: 'flex', alignItems: 'center', gap: 6, cursor: 'pointer', fontSize: 12, color: 'var(--chrome)' }}>
                  <input type="checkbox" checked={config[key]} onChange={e => set(key, e.target.checked)} style={{ accentColor: 'var(--red)' }} />
                  {label}
                </label>
              ))}
            </div>

            {/* Number plate */}
            <div style={{ marginBottom: 12 }}>
              <label>Custom Plate</label>
              <input value={config.numberPlate} onChange={e => set('numberPlate', e.target.value.toUpperCase())} placeholder="DAISYGT" maxLength={7} style={{ fontFamily: 'var(--font-mono)', letterSpacing: '0.1em' }} />
            </div>
          </div>

          {/* Preview */}
          <div style={{ padding: 16, display: 'flex', flexDirection: 'column', gap: 12 }}>
            <div style={{ fontFamily: 'var(--font-display)', fontSize: 11, fontWeight: 600, letterSpacing: '0.08em', textTransform: 'uppercase', color: 'var(--chrome-dim)' }}>Live Preview</div>
            <div style={{ background: 'var(--bg-void)', border: 'var(--border)', borderRadius: 2, padding: 16 }}>
              <CarPreview />
            </div>
            <div style={{ background: 'var(--bg-surface)', border: 'var(--border)', borderRadius: 2, padding: 12 }}>
              <div style={{ fontSize: 10, color: 'var(--chrome-dim)', fontFamily: 'var(--font-mono)', marginBottom: 6, letterSpacing: '0.08em', textTransform: 'uppercase' }}>Config Summary</div>
              {[
                ['Wrap', config.wrapPattern],
                ['Pattern', config.wrapPattern],
                ['Rims', `${config.rimStyle}`],
                ['Tint', config.tint],
                ['Underglow', config.underglow],
                ['Decal', config.decal],
              ].map(([label, val]) => (
                <div key={label} style={{ display: 'flex', justifyContent: 'space-between', fontSize: 11, padding: '3px 0', borderBottom: 'var(--border)' }}>
                  <span style={{ color: 'var(--chrome-dim)' }}>{label}</span>
                  <span style={{ fontFamily: 'var(--font-mono)', color: 'var(--chrome)' }}>{val}</span>
                </div>
              ))}
            </div>
            <button onClick={handleSave} className="btn btn-primary" style={{ width: '100%', justifyContent: 'center' }}>
              ✓ Save Customization
            </button>
            <button onClick={onClose} className="btn btn-ghost btn-sm" style={{ width: '100%', justifyContent: 'center' }}>Cancel</button>
          </div>
        </div>
      </div>
    </div>
  );
}
