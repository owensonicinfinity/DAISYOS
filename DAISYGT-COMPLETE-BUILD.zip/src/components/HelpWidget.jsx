import React, { useState } from 'react';
import { answerHelp } from '../services/gemini';

export default function HelpWidget() {
  const [open, setOpen] = useState(false);
  const [question, setQuestion] = useState('');
  const [answer, setAnswer] = useState('');
  const [loading, setLoading] = useState(false);
  const [suggestions] = useState([
    'How do I start a race?',
    'What is Ghost Mode?',
    'How does the Dyno work?',
    'What is the free trial code?',
    'How do I join a club?',
  ]);

  const ask = async (q) => {
    setLoading(true);
    setAnswer('');
    try {
      const res = await answerHelp(q || question);
      setAnswer(res);
    } catch {
      setAnswer('Try again — AI is warming up! 🏎️');
    }
    setLoading(false);
  };

  return (
    <>
      {/* Floating Button */}
      <button
        onClick={() => setOpen(true)}
        style={{
          position: 'fixed',
          top: 64,
          right: 12,
          zIndex: 200,
          width: 32, height: 32,
          background: 'var(--bg-panel)',
          border: '1px solid rgba(255,255,255,0.1)',
          borderRadius: '50%',
          color: 'var(--chrome-dim)',
          cursor: 'pointer',
          fontSize: 14,
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          transition: 'all 0.15s',
        }}
        title="Help & Suggestions"
      >?</button>

      {/* Panel */}
      {open && (
        <div style={{
          position: 'fixed', top: 100, right: 12,
          width: 300, zIndex: 300,
          background: 'var(--bg-panel)',
          border: '1px solid rgba(224,0,32,0.3)',
          borderRadius: 2,
          boxShadow: '0 8px 40px rgba(0,0,0,0.6)',
        }}>
          <div style={{
            padding: '12px 14px',
            borderBottom: 'var(--border)',
            display: 'flex', alignItems: 'center', justifyContent: 'space-between',
          }}>
            <span style={{ fontFamily: 'var(--font-display)', fontSize: 13, fontWeight: 700, letterSpacing: '0.06em', color: 'var(--chrome-bright)', textTransform: 'uppercase' }}>
              ❓ Help & AI
            </span>
            <button onClick={() => setOpen(false)} style={{ background: 'none', border: 'none', color: 'var(--chrome-dim)', cursor: 'pointer', fontSize: 16 }}>×</button>
          </div>

          <div style={{ padding: 14 }}>
            {/* Suggestions */}
            <div style={{ marginBottom: 12 }}>
              <div style={{ fontSize: 10, letterSpacing: '0.08em', textTransform: 'uppercase', color: 'var(--chrome-dim)', marginBottom: 6 }}>Quick Questions</div>
              <div style={{ display: 'flex', flexWrap: 'wrap', gap: 4 }}>
                {suggestions.map(s => (
                  <button key={s} onClick={() => { setQuestion(s); ask(s); }}
                    style={{ fontSize: 10, padding: '3px 8px', background: 'var(--bg-surface)', border: 'var(--border)', color: 'var(--chrome-dim)', borderRadius: 1, cursor: 'pointer', fontFamily: 'var(--font-body)' }}>
                    {s}
                  </button>
                ))}
              </div>
            </div>

            {/* Text Input */}
            <div style={{ display: 'flex', gap: 6 }}>
              <input
                value={question}
                onChange={e => setQuestion(e.target.value)}
                onKeyDown={e => e.key === 'Enter' && ask()}
                placeholder="Ask DaisyAI anything..."
                style={{ flex: 1, fontSize: 12, padding: '8px 10px' }}
              />
              <button onClick={() => ask()} className="btn btn-primary btn-sm">→</button>
            </div>

            {/* Answer */}
            {loading && (
              <div style={{ marginTop: 12, display: 'flex', alignItems: 'center', gap: 8 }}>
                <div className="loading-spinner" style={{ width: 16, height: 16 }} />
                <span style={{ fontSize: 12, color: 'var(--chrome-dim)' }}>DaisyAI thinking...</span>
              </div>
            )}
            {answer && (
              <div style={{
                marginTop: 12,
                padding: 10,
                background: 'var(--bg-surface)',
                border: 'var(--border)',
                borderRadius: 2,
                fontSize: 12,
                lineHeight: 1.6,
                color: 'var(--chrome)',
              }}>
                {answer}
              </div>
            )}

            {/* Suggestions box */}
            <div style={{ marginTop: 12, fontSize: 10, color: 'var(--chrome-dim)', borderTop: 'var(--border)', paddingTop: 8 }}>
              💡 Have a suggestion? <a href="mailto:suggestions@daisygt.app" style={{ color: 'var(--red)' }}>Email us</a>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
