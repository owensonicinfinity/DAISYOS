import React, { useState } from 'react';
import { Outlet, NavLink, useNavigate } from 'react-router-dom';
import { useAuthStore } from '../store/authStore';
import TrialBanner from './TrialBanner';
import NotifPanel from './NotifPanel';
import styles from './AppShell.module.css';

const NAV_GROUPS = [
  {
    label: 'Racing',
    items: [
      { path: '/app', label: 'HQ Dashboard', icon: '⬡', exact: true },
      { path: '/app/race', label: 'Race', icon: '🏁' },
      { path: '/app/race/replay', label: 'Race Replay', icon: '🎬' },
      { path: '/app/world', label: 'World Tour', icon: '🌍' },
      { path: '/app/garage', label: 'Garage', icon: '🔧' },
      { path: '/app/dyno', label: 'Dyno (DDG)', icon: '📊' },
      { path: '/app/obd2', label: 'OBD2 + Engine', icon: '🔌' },
    ],
  },
  {
    label: 'Social',
    items: [
      { path: '/app/social', label: 'Social Feed', icon: '📡' },
      { path: '/app/clubs', label: 'Clubs', icon: '🔗' },
      { path: '/app/leaderboards', label: 'Leaderboards', icon: '🏆' },
      { path: '/app/marketplace', label: 'Marketplace', icon: '💎' },
    ],
  },
  {
    label: 'Performance',
    items: [
      { path: '/app/analytics', label: 'Analytics', icon: '📈' },
      { path: '/app/training', label: 'Training', icon: '💪' },
      { path: '/app/sports', label: 'Live Sports', icon: '⚽' },
    ],
  },
  {
    label: 'DaisyOS',
    items: [
      { path: '/app/hunting', label: 'DaisyAI Hunting', icon: '🎯' },
      { path: '/app/wallet', label: 'Wallet & Disputes', icon: '⚖️' },
      { path: '/app/profile', label: 'Profile', icon: '👤' },
    ],
  },
];

export default function AppShell() {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const { user, logout, daysLeftInTrial, isElite } = useAuthStore();
  const navigate = useNavigate();

  const handleLogout = () => { logout(); navigate('/'); };
  const trialDays = daysLeftInTrial();
  const elite = isElite();

  return (
    <div className={styles.shell}>
      {/* ─── Top Bar ─── */}
      <header className={styles.topbar}>
        <button className={styles.menuBtn} onClick={() => setSidebarOpen(!sidebarOpen)} aria-label="Menu">
          <span /><span /><span />
        </button>
        <div className={styles.brand}>
          <span className={styles.brandDaisy}>DAISY</span>
          <span className={styles.brandGT}>GT</span>
          <span className={styles.brandOs}>OS</span>
        </div>
        <div className={styles.topRight}>
          {elite && <span className="badge badge-cyan">ELITE</span>}
          {trialDays > 0 && <span className="badge badge-yellow">{trialDays}d trial</span>}
          <NotifPanel />
          <button
            onClick={() => { navigate('/app/profile'); setSidebarOpen(false); }}
            style={{ background: 'none', border: 'none', cursor: 'pointer', padding: 0 }}
          >
            <img
              src={user?.avatar || `https://api.dicebear.com/7.x/avataaars/svg?seed=${user?.username}`}
              alt={user?.username}
              className={styles.avatarImg}
            />
          </button>
        </div>
      </header>

      {/* ─── Sidebar ─── */}
      <aside className={`${styles.sidebar} ${sidebarOpen ? styles.open : ''}`}>
        <div className={styles.sidebarInner}>
          {/* User card */}
          <div className={styles.userInfo}>
            <img
              src={user?.avatar || `https://api.dicebear.com/7.x/avataaars/svg?seed=${user?.username}`}
              alt={user?.username}
              className={styles.userAvatar}
            />
            <div style={{ minWidth: 0 }}>
              <div className={styles.userName}>{user?.username || 'Racer'}</div>
              <div className={styles.userLevel}>
                Lv.{user?.level || 1} · {user?.xp || 0} XP
              </div>
              {elite && <span className="badge badge-cyan" style={{ fontSize: 8, padding: '1px 6px', marginTop: 2, display: 'inline-block' }}>ELITE</span>}
            </div>
          </div>

          {/* Nav groups */}
          <nav className={styles.nav}>
            {NAV_GROUPS.map(group => (
              <div key={group.label}>
                <div style={{
                  fontFamily: 'var(--font-mono)',
                  fontSize: 9,
                  letterSpacing: '0.14em',
                  textTransform: 'uppercase',
                  color: 'rgba(200,205,216,0.3)',
                  padding: '12px 16px 4px',
                }}>
                  {group.label}
                </div>
                {group.items.map((item) => (
                  <NavLink
                    key={item.path}
                    to={item.path}
                    end={item.exact}
                    className={({ isActive }) => `${styles.navItem} ${isActive ? styles.active : ''}`}
                    onClick={() => setSidebarOpen(false)}
                  >
                    <span className={styles.navIcon}>{item.icon}</span>
                    <span className={styles.navLabel}>{item.label}</span>
                  </NavLink>
                ))}
              </div>
            ))}
          </nav>

          {/* Bottom section */}
          <div className={styles.sidebarBottom}>
            {!elite && (
              <div className={styles.upgradeBox}>
                <div className={styles.upgradeTitle}>⚡ ELITE ACCESS</div>
                <div className={styles.upgradeDesc}>Dyno · Ghost Racing · OBD2 · Analytics · NFTs</div>
                <button
                  className="btn btn-primary btn-sm"
                  style={{ width: '100%', justifyContent: 'center' }}
                  onClick={() => { navigate('/app/profile'); setSidebarOpen(false); }}
                >
                  Upgrade — $4.99
                </button>
                <div style={{ marginTop: 8, fontFamily: 'var(--font-mono)', fontSize: 9, color: 'var(--chrome-dim)', textAlign: 'center' }}>
                  Free trial: <span style={{ color: 'var(--yellow)' }}>DAISYGT-FREE-2025</span>
                </div>
              </div>
            )}
            <button className={styles.logoutBtn} onClick={handleLogout}>
              ⏻ Sign Out
            </button>
          </div>
        </div>
      </aside>

      {/* ─── Overlay for mobile ─── */}
      {sidebarOpen && (
        <div className={styles.overlay} onClick={() => setSidebarOpen(false)} />
      )}

      {/* ─── Main content ─── */}
      <main className={styles.main}>
        <TrialBanner />
        <Outlet />
      </main>
    </div>
  );
}
