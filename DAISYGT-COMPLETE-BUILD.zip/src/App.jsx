import React, { useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { Toaster } from 'react-hot-toast';
import './styles/global.css';

import Landing from './pages/Landing';
import Login from './pages/Login';
import Register from './pages/Register';
import Dashboard from './pages/Dashboard';
import Race from './pages/Race';
import SplitScreen from './pages/SplitScreen';
import Garage from './pages/Garage';
import Dyno from './pages/Dyno';
import Social from './pages/Social';
import Leaderboards from './pages/Leaderboards';
import Clubs from './pages/Clubs';
import Marketplace from './pages/Marketplace';
import Profile from './pages/Profile';
import Spectator from './pages/Spectator';
import Analytics from './pages/Analytics';
import Hunting from './pages/Hunting';
import Sports from './pages/Sports';
import Training from './pages/Training';
import OBD2 from './pages/OBD2';
import WorldTour from './pages/WorldTour';
import RaceReplay from './pages/RaceReplay';
import Wallet from './pages/Wallet';
import AppShell from './components/AppShell';
import HelpWidget from './components/HelpWidget';
import { useAuthStore } from './store/authStore';
import { seedDemoData } from './services/api';

function ProtectedRoute({ children }) {
  const { user } = useAuthStore();
  if (!user) return <Navigate to="/login" replace />;
  return children;
}

export default function App() {
  const { checkTrial } = useAuthStore();

  useEffect(() => {
    seedDemoData();
    checkTrial();
    const params = new URLSearchParams(window.location.search);
    const trial = params.get('trial');
    if (trial === 'DAISYGT-FREE-2025') {
      localStorage.setItem('trial_code', trial);
    }
  }, [checkTrial]);

  return (
    <Router>
      <Toaster
        position="top-right"
        toastOptions={{
          style: {
            background: '#18181f',
            color: '#c8cdd8',
            border: '1px solid rgba(224,0,32,0.3)',
            fontFamily: "'IBM Plex Sans', sans-serif",
            fontSize: '13px',
            maxWidth: '360px',
          },
          success: { iconTheme: { primary: '#00ff88', secondary: '#0a0a0c' } },
          error: { iconTheme: { primary: '#e00020', secondary: '#0a0a0c' } },
        }}
      />
      <HelpWidget />
      <Routes>
        {/* Public */}
        <Route path="/" element={<Landing />} />
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Register />} />
        <Route path="/spectator/:raceId" element={<Spectator />} />

        {/* Protected App */}
        <Route path="/app" element={
          <ProtectedRoute><AppShell /></ProtectedRoute>
        }>
          <Route index element={<Dashboard />} />
          <Route path="race" element={<Race />} />
          <Route path="race/split/:raceId" element={<SplitScreen />} />
          <Route path="race/replay" element={<RaceReplay />} />
          <Route path="garage" element={<Garage />} />
          <Route path="dyno" element={<Dyno />} />
          <Route path="obd2" element={<OBD2 />} />
          <Route path="social" element={<Social />} />
          <Route path="leaderboards" element={<Leaderboards />} />
          <Route path="clubs" element={<Clubs />} />
          <Route path="marketplace" element={<Marketplace />} />
          <Route path="analytics" element={<Analytics />} />
          <Route path="training" element={<Training />} />
          <Route path="sports" element={<Sports />} />
          <Route path="hunting" element={<Hunting />} />
          <Route path="profile" element={<Profile />} />
          <Route path="world" element={<WorldTour />} />
          <Route path="wallet" element={<Wallet />} />
        </Route>

        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </Router>
  );
}
