// ─── Offline Recording Service ─────────────────────────────────
// Records GPS + telemetry to IndexedDB while offline.
// Uploads when connection is restored.

const DB_NAME = 'daisygt_offline';
const STORE_NAME = 'recordings';
const DB_VERSION = 1;

let db = null;

export function openOfflineDB() {
  return new Promise((resolve, reject) => {
    if (db) { resolve(db); return; }
    const req = indexedDB.open(DB_NAME, DB_VERSION);
    req.onupgradeneeded = (e) => {
      const database = e.target.result;
      if (!database.objectStoreNames.contains(STORE_NAME)) {
        const store = database.createObjectStore(STORE_NAME, { keyPath: 'id', autoIncrement: true });
        store.createIndex('sessionId', 'sessionId', { unique: false });
        store.createIndex('uploaded', 'uploaded', { unique: false });
        store.createIndex('timestamp', 'timestamp', { unique: false });
      }
    };
    req.onsuccess = (e) => { db = e.target.result; resolve(db); };
    req.onerror = () => reject(req.error);
  });
}

export async function saveOfflinePoint(sessionId, data) {
  try {
    const database = await openOfflineDB();
    return new Promise((resolve, reject) => {
      const tx = database.transaction(STORE_NAME, 'readwrite');
      const store = tx.objectStore(STORE_NAME);
      const req = store.add({ sessionId, ...data, timestamp: Date.now(), uploaded: false });
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => reject(req.error);
    });
  } catch (e) {
    console.warn('Offline save failed:', e);
  }
}

export async function getOfflineSessions() {
  try {
    const database = await openOfflineDB();
    return new Promise((resolve, reject) => {
      const tx = database.transaction(STORE_NAME, 'readonly');
      const store = tx.objectStore(STORE_NAME);
      const req = store.getAll();
      req.onsuccess = () => {
        const records = req.result;
        // Group by sessionId
        const sessions = {};
        records.forEach(r => {
          if (!sessions[r.sessionId]) sessions[r.sessionId] = { sessionId: r.sessionId, points: [], uploaded: r.uploaded };
          sessions[r.sessionId].points.push(r);
        });
        resolve(Object.values(sessions));
      };
      req.onerror = () => reject(req.error);
    });
  } catch { return []; }
}

export async function getPendingUploadCount() {
  try {
    const database = await openOfflineDB();
    return new Promise((resolve) => {
      const tx = database.transaction(STORE_NAME, 'readonly');
      const store = tx.objectStore(STORE_NAME);
      const idx = store.index('uploaded');
      const req = idx.count(IDBKeyRange.only(false));
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => resolve(0);
    });
  } catch { return 0; }
}

export async function markSessionUploaded(sessionId) {
  try {
    const database = await openOfflineDB();
    return new Promise((resolve) => {
      const tx = database.transaction(STORE_NAME, 'readwrite');
      const store = tx.objectStore(STORE_NAME);
      const idx = store.index('sessionId');
      const req = idx.openCursor(IDBKeyRange.only(sessionId));
      req.onsuccess = (e) => {
        const cursor = e.target.result;
        if (cursor) { cursor.update({ ...cursor.value, uploaded: true }); cursor.continue(); }
        else resolve();
      };
    });
  } catch { /* silent */ }
}

export async function uploadPendingSessions(apiSaveFn, userId) {
  if (!navigator.onLine) return { uploaded: 0 };
  const sessions = await getOfflineSessions();
  const pending = sessions.filter(s => !s.uploaded);
  let uploaded = 0;
  for (const session of pending) {
    try {
      await apiSaveFn({ userId, sessionId: session.sessionId, points: session.points.length, offline: true, createdAt: new Date(session.points[0]?.timestamp).toISOString() });
      await markSessionUploaded(session.sessionId);
      uploaded++;
    } catch { /* skip failed */ }
  }
  return { uploaded };
}

// ─── Offline Mode Manager ─────────────────────────────────────
let offlineSessionId = null;
let recordingInterval = null;

export function startOfflineRecording(onTelemetryCallback) {
  offlineSessionId = `offline_${Date.now()}`;
  let isOffline = !navigator.onLine;

  const handleOnline = async () => {
    isOffline = false;
    const count = await getPendingUploadCount();
    if (count > 0) {
      window.dispatchEvent(new CustomEvent('daisygt:pendingUpload', { detail: { count } }));
    }
  };

  const handleOffline = () => { isOffline = true; };
  window.addEventListener('online', handleOnline);
  window.addEventListener('offline', handleOffline);

  recordingInterval = setInterval(() => {
    // This interval just flags that we're in recording mode
    // Actual telemetry is saved in Race.jsx via the GPS listener
  }, 5000);

  return {
    sessionId: offlineSessionId,
    save: (data) => saveOfflinePoint(offlineSessionId, data),
    stop: () => {
      clearInterval(recordingInterval);
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    },
  };
}

export function isOnline() { return navigator.onLine; }
