const GEMINI_API_KEY = 'AIzaSyAOKYw_xQ9QLtZg-vwZ9Rb1lMt56kbNdys';
const GEMINI_URL = `https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=${GEMINI_API_KEY}`;

export async function askGemini(prompt, systemContext = '') {
  const body = {
    contents: [
      {
        role: 'user',
        parts: [{ text: `${systemContext}\n\n${prompt}` }],
      },
    ],
    generationConfig: {
      temperature: 0.7,
      topP: 0.95,
      maxOutputTokens: 1024,
    },
  };

  const res = await fetch(GEMINI_URL, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
  });

  if (!res.ok) throw new Error('Gemini API error');
  const data = await res.json();
  return data.candidates?.[0]?.content?.parts?.[0]?.text || '';
}

export async function analyzeRaceTelemetry(telemetryData) {
  const system = `You are DaisyAI, the advanced racing AI for Daisy GT. 
  You analyze race telemetry data and provide expert insights on performance, 
  vehicle tuning, and race strategy. Be concise, data-driven, and use racing terminology.
  Keep responses under 150 words.`;

  const prompt = `Analyze this race telemetry and give actionable insights:
  ${JSON.stringify(telemetryData, null, 2)}
  
  Provide: 1) Performance rating (1-100), 2) Key strength, 3) Main improvement area, 4) One specific tuning tip.`;

  return askGemini(prompt, system);
}

export async function getHuntingAdvice(conditions) {
  const system = `You are DaisyAI Hunting Guide. You provide expert hunting advice 
  based on weather, terrain, animal behavior, and seasons. Be specific and practical.
  Keep responses under 120 words.`;

  const prompt = `Give hunting advice for these conditions: ${JSON.stringify(conditions)}`;
  return askGemini(prompt, system);
}

export async function getSportsInsight(sport, stats) {
  const system = `You are DaisyAI Sports Analyst. Provide brief, actionable performance insights 
  for athletes. Be encouraging but honest. Under 100 words.`;

  const prompt = `Sport: ${sport}. Stats: ${JSON.stringify(stats)}. Give performance insight and one improvement tip.`;
  return askGemini(prompt, system);
}

export async function answerHelp(question) {
  const system = `You are the Daisy GT help assistant. Answer questions about the Daisy GT 
  racing platform, DaisyOS, features, and how to use the app. Be helpful and concise. Under 120 words.`;
  return askGemini(question, system);
}
