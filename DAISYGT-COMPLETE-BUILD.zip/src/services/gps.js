// ─── GPS & Telemetry Service ───────────────────────────────────
// Real device GPS + accelerometer for G-force tracking

let watchId = null;
let accelListener = null;
let lastPosition = null;
let lastTime = null;
let gForceData = { x: 0, y: 0, z: 0, total: 0 };
let listeners = [];

export function onTelemetryUpdate(cb) {
  listeners.push(cb);
  return () => { listeners = listeners.filter(l => l !== cb); };
}

function emit(data) {
  listeners.forEach(cb => cb(data));
}

function calcSpeed(pos1, pos2, time1, time2) {
  if (!pos1 || !pos2) return 0;
  const R = 6371000; // Earth radius meters
  const lat1 = pos1.lat * Math.PI / 180;
  const lat2 = pos2.lat * Math.PI / 180;
  const dLat = (pos2.lat - pos1.lat) * Math.PI / 180;
  const dLon = (pos2.lng - pos1.lng) * Math.PI / 180;
  const a = Math.sin(dLat/2)**2 + Math.cos(lat1)*Math.cos(lat2)*Math.sin(dLon/2)**2;
  const dist = 2 * R * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
  const dtSec = (time2 - time1) / 1000;
  if (dtSec <= 0) return 0;
  return (dist / dtSec) * 2.237; // m/s to mph
}

export function startGPS() {
  if (!navigator.geolocation) {
    console.warn('Geolocation not supported');
    startSimulation();
    return;
  }

  watchId = navigator.geolocation.watchPosition(
    (pos) => {
      const now = Date.now();
      const current = { lat: pos.coords.latitude, lng: pos.coords.longitude };
      const speed = pos.coords.speed
        ? pos.coords.speed * 2.237
        : calcSpeed(lastPosition, current, lastTime, now);

      const data = {
        lat: current.lat,
        lng: current.lng,
        speed: Math.round(speed * 10) / 10,
        altitude: pos.coords.altitude || 0,
        heading: pos.coords.heading || 0,
        accuracy: pos.coords.accuracy,
        timestamp: now,
        gForce: gForceData.total,
        gForceX: gForceData.x,
        gForceY: gForceData.y,
        gForceZ: gForceData.z,
      };

      lastPosition = current;
      lastTime = now;
      emit(data);
    },
    (err) => {
      console.warn('GPS error:', err.message);
      startSimulation();
    },
    { enableHighAccuracy: true, timeout: 5000, maximumAge: 0 }
  );

  // Accelerometer for G-force
  if (typeof DeviceMotionEvent !== 'undefined') {
    const handler = (e) => {
      if (e.accelerationIncludingGravity) {
        const x = e.accelerationIncludingGravity.x || 0;
        const y = e.accelerationIncludingGravity.y || 0;
        const z = e.accelerationIncludingGravity.z || 0;
        const total = Math.sqrt(x*x + y*y + z*z) / 9.81;
        gForceData = { x: x/9.81, y: y/9.81, z: z/9.81, total };
      }
    };
    window.addEventListener('devicemotion', handler);
    accelListener = handler;
  }
}

export function stopGPS() {
  if (watchId !== null) navigator.geolocation.clearWatch(watchId);
  if (accelListener) window.removeEventListener('devicemotion', accelListener);
  watchId = null;
  accelListener = null;
}

// ─── Simulation Mode (desktop / no GPS) ──────────────
let simInterval = null;
let simLat = 29.7604;
let simLng = -95.3698;
let simSpeed = 0;
let simHeading = 45;
let simDist = 0;

export function startSimulation() {
  let t = 0;
  simInterval = setInterval(() => {
    t += 0.1;
    simSpeed = 60 + Math.sin(t * 0.3) * 30 + Math.random() * 5;
    simLat += (simSpeed * Math.cos(simHeading * Math.PI/180)) * 0.000004;
    simLng += (simSpeed * Math.sin(simHeading * Math.PI/180)) * 0.000004;
    simHeading = (simHeading + (Math.random() - 0.48) * 2) % 360;
    simDist += simSpeed * 0.1 / 3600;

    const gX = (Math.random() - 0.5) * 0.4;
    const gY = (Math.random() - 0.5) * 0.3;
    const gTotal = Math.sqrt(gX*gX + gY*gY);

    emit({
      lat: simLat,
      lng: simLng,
      speed: Math.round(simSpeed),
      altitude: 50 + Math.sin(t * 0.1) * 20,
      heading: simHeading,
      accuracy: 5,
      timestamp: Date.now(),
      distance: simDist,
      gForce: Math.round(gTotal * 100) / 100,
      gForceX: gX,
      gForceY: gY,
      gForceZ: 1.0,
      simulated: true,
    });
  }, 500);
}

export function stopSimulation() {
  if (simInterval) clearInterval(simInterval);
  simInterval = null;
}

export function getMicrophoneRPM(stream) {
  // Audio-based RPM estimation from microphone
  const ctx = new AudioContext();
  const source = ctx.createMediaStreamSource(stream);
  const analyser = ctx.createAnalyser();
  analyser.fftSize = 2048;
  source.connect(analyser);

  const buf = new Uint8Array(analyser.frequencyBinCount);

  return {
    getRPM: () => {
      analyser.getByteFrequencyData(buf);
      // Find dominant frequency in engine RPM range (50-200Hz = 3000-12000 RPM)
      let maxAmp = 0, maxIdx = 0;
      for (let i = 2; i < 100; i++) {
        if (buf[i] > maxAmp) { maxAmp = buf[i]; maxIdx = i; }
      }
      const freq = maxIdx * ctx.sampleRate / analyser.fftSize;
      const rpm = freq * 30; // rough conversion
      return Math.min(9000, Math.max(600, Math.round(rpm)));
    },
    stop: () => { source.disconnect(); ctx.close(); },
  };
}
