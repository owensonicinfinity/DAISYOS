// ─── Mock Backend API ─────────────────────────────────────────
// Fully functional with localStorage. Swap fetch calls with real API later.

const DB = {
  get: (key) => JSON.parse(localStorage.getItem(`daisygt_${key}`) || 'null'),
  set: (key, val) => localStorage.setItem(`daisygt_${key}`, JSON.stringify(val)),
  getArr: (key) => JSON.parse(localStorage.getItem(`daisygt_${key}`) || '[]'),
  push: (key, item) => {
    const arr = DB.getArr(key);
    arr.unshift({ ...item, id: item.id || `${key}_${Date.now()}`, createdAt: new Date().toISOString() });
    DB.set(key, arr.slice(0, 200));
    return arr[0];
  },
};

// ─── AUTH ──────────────────────────────────────────────────────
export const api = {
  auth: {
    register: async ({ username, email, password, vehicle }) => {
      const users = DB.getArr('users');
      if (users.find(u => u.email === email)) throw new Error('Email already registered');
      const user = {
        id: `user_${Date.now()}`,
        username,
        email,
        passwordHash: btoa(password),
        avatar: `https://api.dicebear.com/7.x/avataaars/svg?seed=${username}`,
        subscription: 'free',
        joinedAt: new Date().toISOString(),
        wins: 0, losses: 0, races: 0,
        bio: '',
        location: '',
        primaryVehicle: vehicle || 'Car',
        xp: 0, level: 1,
        badges: [],
        trialUsed: false,
      };
      DB.push('users', user);
      const token = btoa(JSON.stringify({ id: user.id, exp: Date.now() + 30 * 86400000 }));
      return { user, token };
    },

    login: async ({ email, password }) => {
      const users = DB.getArr('users');
      const user = users.find(u => u.email === email && u.passwordHash === btoa(password));
      if (!user) throw new Error('Invalid email or password');
      const token = btoa(JSON.stringify({ id: user.id, exp: Date.now() + 30 * 86400000 }));
      return { user, token };
    },

    googleLogin: async (googleData) => {
      const users = DB.getArr('users');
      let user = users.find(u => u.email === googleData.email);
      if (!user) {
        user = {
          id: `user_${Date.now()}`,
          username: googleData.name?.replace(' ', '_') || 'racer',
          email: googleData.email,
          avatar: googleData.picture || `https://api.dicebear.com/7.x/avataaars/svg?seed=${googleData.email}`,
          subscription: 'free',
          joinedAt: new Date().toISOString(),
          wins: 0, losses: 0, races: 0,
          bio: '', location: '', primaryVehicle: 'Car',
          xp: 0, level: 1, badges: [], trialUsed: false,
        };
        DB.push('users', user);
      }
      const token = btoa(JSON.stringify({ id: user.id, exp: Date.now() + 30 * 86400000 }));
      return { user, token };
    },
  },

  // ─── RACES ──────────────────────────────────────────────
  races: {
    create: async (config) => {
      const race = DB.push('races', { ...config, status: 'pending', spectators: 0 });
      return race;
    },
    getHistory: async (userId) => {
      return DB.getArr('races').filter(r => r.userId === userId);
    },
    getAll: async () => DB.getArr('races').slice(0, 20),
    getLive: async () => DB.getArr('races').filter(r => r.status === 'active'),
    saveResult: async (result) => {
      const saved = DB.push('race_results', result);
      // Update user stats
      const users = DB.getArr('users');
      const idx = users.findIndex(u => u.id === result.userId);
      if (idx !== -1) {
        users[idx].races = (users[idx].races || 0) + 1;
        users[idx].wins = (users[idx].wins || 0) + (result.position === 1 ? 1 : 0);
        users[idx].xp = (users[idx].xp || 0) + (result.position === 1 ? 100 : 25);
        DB.set('users', users);
      }
      return saved;
    },
  },

  // ─── GARAGE ─────────────────────────────────────────────
  garage: {
    getVehicles: async (userId) => {
      return DB.getArr('vehicles').filter(v => v.userId === userId);
    },
    addVehicle: async (vehicle) => {
      return DB.push('vehicles', vehicle);
    },
    updateVehicle: async (id, updates) => {
      const vehicles = DB.getArr('vehicles');
      const idx = vehicles.findIndex(v => v.id === id);
      if (idx !== -1) vehicles[idx] = { ...vehicles[idx], ...updates };
      DB.set('vehicles', vehicles);
      return vehicles[idx];
    },
    deleteVehicle: async (id) => {
      const vehicles = DB.getArr('vehicles').filter(v => v.id !== id);
      DB.set('vehicles', vehicles);
    },
  },

  // ─── SOCIAL ─────────────────────────────────────────────
  social: {
    getFeed: async () => DB.getArr('posts').slice(0, 50),
    createPost: async (post) => DB.push('posts', post),
    likePost: async (postId, userId) => {
      const posts = DB.getArr('posts');
      const p = posts.find(p => p.id === postId);
      if (p) {
        p.likes = p.likes || [];
        if (p.likes.includes(userId)) p.likes = p.likes.filter(l => l !== userId);
        else p.likes.push(userId);
        DB.set('posts', posts);
      }
      return p;
    },
    addComment: async (postId, comment) => {
      const posts = DB.getArr('posts');
      const p = posts.find(p => p.id === postId);
      if (p) { p.comments = p.comments || []; p.comments.push(comment); DB.set('posts', posts); }
      return p;
    },
  },

  // ─── CLUBS ──────────────────────────────────────────────
  clubs: {
    getAll: async () => DB.getArr('clubs'),
    getMyClubs: async (userId) => DB.getArr('clubs').filter(c => c.members?.includes(userId)),
    create: async (club) => DB.push('clubs', club),
    join: async (clubId, userId) => {
      const clubs = DB.getArr('clubs');
      const c = clubs.find(c => c.id === clubId);
      if (c) {
        c.members = c.members || [];
        if (c.members.length >= 12) throw new Error('Club is full (max 12 racers)');
        if (!c.members.includes(userId)) c.members.push(userId);
        DB.set('clubs', clubs);
      }
      return c;
    },
    leave: async (clubId, userId) => {
      const clubs = DB.getArr('clubs');
      const c = clubs.find(c => c.id === clubId);
      if (c) { c.members = (c.members || []).filter(m => m !== userId); DB.set('clubs', clubs); }
    },
  },

  // ─── LEADERBOARDS ───────────────────────────────────────
  leaderboards: {
    get: async (category, limit = 20) => {
      const results = DB.getArr('race_results');
      const users = DB.getArr('users');

      const lookup = {};
      users.forEach(u => lookup[u.id] = u);

      let entries = [];
      if (category === 'top_speed') {
        entries = results.map(r => ({ userId: r.userId, value: r.topSpeed || 0, unit: 'mph' }));
      } else if (category === 'most_wins') {
        const wins = {};
        results.forEach(r => { if (r.position === 1) wins[r.userId] = (wins[r.userId] || 0) + 1; });
        entries = Object.entries(wins).map(([userId, value]) => ({ userId, value, unit: 'wins' }));
      } else if (category === 'quarter_mile') {
        entries = results.filter(r => r.quarterMile).map(r => ({ userId: r.userId, value: r.quarterMile, unit: 's' }));
      } else {
        entries = results.map(r => ({ userId: r.userId, value: r.distance || 0, unit: 'mi' }));
      }

      return entries
        .sort((a, b) => category === 'quarter_mile' ? a.value - b.value : b.value - a.value)
        .slice(0, limit)
        .map((e, i) => ({
          rank: i + 1,
          user: lookup[e.userId] || { username: 'Unknown', avatar: '' },
          value: e.value,
          unit: e.unit,
        }));
    },
  },

  // ─── TELEMETRY ──────────────────────────────────────────
  telemetry: {
    save: async (session) => DB.push('telemetry', session),
    getHistory: async (userId) => DB.getArr('telemetry').filter(t => t.userId === userId).slice(0, 30),
  },

  // ─── MARKETPLACE ────────────────────────────────────────
  marketplace: {
    getListings: async () => DB.getArr('nft_listings'),
    createListing: async (listing) => DB.push('nft_listings', listing),
    purchase: async (listingId, buyerId) => {
      const listings = DB.getArr('nft_listings');
      const item = listings.find(l => l.id === listingId);
      if (!item) throw new Error('Listing not found');
      item.ownerId = buyerId;
      item.sold = true;
      DB.set('nft_listings', listings);
      return item;
    },
  },

  // ─── TRAINING ───────────────────────────────────────────
  training: {
    logSession: async (session) => DB.push('training_sessions', session),
    getHistory: async (userId) => DB.getArr('training_sessions').filter(t => t.userId === userId),
    getLeaderboard: async (metric) => {
      const sessions = DB.getArr('training_sessions');
      const users = DB.getArr('users');
      const lookup = {};
      users.forEach(u => lookup[u.id] = u);

      return sessions
        .filter(s => s[metric] !== undefined)
        .sort((a, b) => b[metric] - a[metric])
        .slice(0, 20)
        .map((s, i) => ({
          rank: i + 1,
          user: lookup[s.userId] || { username: 'Racer', avatar: '' },
          value: s[metric],
          unit: s[`${metric}_unit`] || '',
        }));
    },
  },

  // ─── PROFILE ────────────────────────────────────────────
  profile: {
    update: async (userId, updates) => {
      const users = DB.getArr('users');
      const idx = users.findIndex(u => u.id === userId);
      if (idx !== -1) { users[idx] = { ...users[idx], ...updates }; DB.set('users', users); return users[idx]; }
      throw new Error('User not found');
    },
    getStats: async (userId) => {
      const races = DB.getArr('race_results').filter(r => r.userId === userId);
      const training = DB.getArr('training_sessions').filter(t => t.userId === userId);
      const wins = races.filter(r => r.position === 1).length;
      return {
        totalRaces: races.length,
        wins,
        losses: races.length - wins,
        winRate: races.length ? Math.round(wins / races.length * 100) : 0,
        bestSpeed: Math.max(...races.map(r => r.topSpeed || 0), 0),
        totalDistance: races.reduce((s, r) => s + (r.distance || 0), 0),
        trainingSessions: training.length,
      };
    },
  },

  // ─── HUNTING ────────────────────────────────────────────
  hunting: {
    logTrip: async (trip) => DB.push('hunting_trips', trip),
    getTrips: async (userId) => DB.getArr('hunting_trips').filter(t => t.userId === userId),
    logHarvest: async (harvest) => DB.push('harvests', harvest),
    getLeaderboard: async () => {
      const harvests = DB.getArr('harvests');
      const users = DB.getArr('users');
      const lookup = {};
      users.forEach(u => lookup[u.id] = u);
      const totals = {};
      harvests.forEach(h => { totals[h.userId] = (totals[h.userId] || 0) + 1; });
      return Object.entries(totals)
        .sort((a, b) => b[1] - a[1])
        .slice(0, 20)
        .map(([userId, count], i) => ({
          rank: i + 1,
          user: lookup[userId] || { username: 'Hunter', avatar: '' },
          value: count,
        }));
    },
  },
};

// ─── Seed demo data ─────────────────────────────────────────────
export function seedDemoData() {
  if (DB.get('seeded')) return;

  const demoUsers = [
    { id: 'demo1', username: 'RocketMike', email: 'demo1@daisygt.com', avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=mike', wins: 47, losses: 12, races: 59, xp: 4700, level: 8, subscription: 'elite' },
    { id: 'demo2', username: 'DaisyRacer', email: 'demo2@daisygt.com', avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=daisy', wins: 33, losses: 19, races: 52, xp: 3300, level: 6 },
    { id: 'demo3', username: 'TurboQueen', email: 'demo3@daisygt.com', avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=queen', wins: 61, losses: 8, races: 69, xp: 6100, level: 11 },
    { id: 'demo4', username: 'GhostRider_X', email: 'demo4@daisygt.com', avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=ghost', wins: 22, losses: 30, races: 52, xp: 2200, level: 4 },
  ];

  DB.set('users', demoUsers);

  const demoVehicles = [
    { id: 'v1', userId: 'demo1', name: 'Turbo Beast', make: 'Dodge', model: 'Challenger SRT', year: 2022, color: '#e00020', type: 'car', horsepower: 717, torque: 650, weight: 4450 },
    { id: 'v2', userId: 'demo2', name: 'Night Runner', make: 'Ford', model: 'Mustang GT500', year: 2021, color: '#111', type: 'car', horsepower: 760, torque: 625, weight: 4230 },
  ];
  DB.set('vehicles', demoVehicles);

  const demoPosts = [
    { id: 'p1', userId: 'demo3', username: 'TurboQueen', avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=queen', content: '🏁 New personal best! 10.8s quarter mile in the GT500. The track was PERFECT tonight. Who wants to run?', likes: ['demo1','demo2'], comments: [], createdAt: new Date(Date.now() - 3600000).toISOString(), type: 'post' },
    { id: 'p2', userId: 'demo1', username: 'RocketMike', avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=mike', content: '👻 Ghost mode is insane — raced my own run from last week and beat it by 0.3s. This app is built different 🔥 #DaisyGT #GhostRacing', likes: ['demo3','demo4','demo2'], comments: [{ text: 'LETS GO', username: 'TurboQueen' }], createdAt: new Date(Date.now() - 7200000).toISOString(), type: 'post' },
    { id: 'p3', userId: 'demo4', username: 'GhostRider_X', avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=ghost', content: 'Just completed 500 miles on the Daisy GT tracker. Dyno numbers are wild — 162 mph top speed logged. #Telemetry', likes: ['demo1'], comments: [], createdAt: new Date(Date.now() - 14400000).toISOString(), type: 'post' },
  ];
  DB.set('posts', demoPosts);

  const demoClubs = [
    { id: 'c1', name: 'Daisy Elite Runners', description: 'Fastest 12 on the platform. Invite only.', members: ['demo1','demo3'], maxMembers: 12, type: 'invite', avatar: '🏆', createdAt: new Date().toISOString() },
    { id: 'c2', name: 'Houston Street Kings', description: 'HTX local racing club. All vehicles welcome.', members: ['demo2','demo4'], maxMembers: 12, type: 'open', avatar: '👑', createdAt: new Date().toISOString() },
    { id: 'c3', name: 'Ghost Protocol Racing', description: 'Ghost vehicle specialists. Master the overlay.', members: ['demo1','demo2','demo3','demo4'], maxMembers: 12, type: 'open', avatar: '👻', createdAt: new Date().toISOString() },
  ];
  DB.set('clubs', demoClubs);

  const demoRaceResults = [
    { id: 'r1', userId: 'demo3', position: 1, topSpeed: 162, distance: 0.25, quarterMile: 10.8, createdAt: new Date(Date.now()-3600000).toISOString() },
    { id: 'r2', userId: 'demo1', position: 1, topSpeed: 158, distance: 0.25, quarterMile: 11.2, createdAt: new Date(Date.now()-7200000).toISOString() },
    { id: 'r3', userId: 'demo2', position: 2, topSpeed: 155, distance: 0.25, quarterMile: 11.5, createdAt: new Date(Date.now()-10800000).toISOString() },
    { id: 'r4', userId: 'demo4', position: 1, topSpeed: 148, distance: 0.25, quarterMile: 12.1, createdAt: new Date(Date.now()-14400000).toISOString() },
  ];
  DB.set('race_results', demoRaceResults);

  DB.set('seeded', true);
}

// ─── DISPUTES ───────────────────────────────────────────────────
// Appended to existing api object - import and spread where needed
export const disputeAPI = {
  file: async (dispute) => DB.push('disputes', { ...dispute, status: 'open' }),
  getAll: async (userId) => DB.getArr('disputes').filter(d => d.reporterId === userId || d.reportedId === userId),
  resolve: async (id, resolution) => {
    const disputes = DB.getArr('disputes');
    const idx = disputes.findIndex(d => d.id === id);
    if (idx !== -1) { disputes[idx] = { ...disputes[idx], status: 'resolved', resolution }; DB.set('disputes', disputes); }
    return disputes[idx];
  },
};

// ─── NOTIFICATIONS ──────────────────────────────────────────────
export const notifAPI = {
  getAll: async (userId) => DB.getArr('notifications').filter(n => n.userId === userId),
  add: async (notif) => DB.push('notifications', notif),
  markRead: async (id) => {
    const notifs = DB.getArr('notifications');
    const idx = notifs.findIndex(n => n.id === id);
    if (idx !== -1) { notifs[idx].read = true; DB.set('notifications', notifs); }
  },
  markAllRead: async (userId) => {
    const notifs = DB.getArr('notifications').map(n => n.userId === userId ? { ...n, read: true } : n);
    DB.set('notifications', notifs);
  },
};

// ─── RACE REPLAY ────────────────────────────────────────────────
export const replayAPI = {
  save: async (replay) => DB.push('replays', replay),
  getAll: async (userId) => DB.getArr('replays').filter(r => r.userId === userId),
  getById: async (id) => DB.getArr('replays').find(r => r.id === id) || null,
};

// ─── FRIENDS ────────────────────────────────────────────────────
export const friendsAPI = {
  getFriends: async (userId) => DB.getArr('friends').filter(f => f.userId === userId || f.friendId === userId),
  addFriend: async (userId, friendId) => DB.push('friends', { userId, friendId, status: 'pending' }),
  accept: async (userId, friendId) => {
    const friends = DB.getArr('friends');
    const idx = friends.findIndex(f => f.userId === friendId && f.friendId === userId);
    if (idx !== -1) { friends[idx].status = 'accepted'; DB.set('friends', friends); }
  },
  searchUsers: async (query) => DB.getArr('users').filter(u => u.username?.toLowerCase().includes(query.toLowerCase())).slice(0, 10),
};

// ─── WALLET / BLOCKCHAIN STUB ────────────────────────────────────
export const walletAPI = {
  getWallet: async (userId) => {
    const key = `wallet_${userId}`;
    const w = DB.get(key);
    if (w) return w;
    const wallet = { userId, address: `0x${Array.from({length:40},()=>'0123456789abcdef'[Math.floor(Math.random()*16)]).join('')}`, balance: 0, transactions: [] };
    DB.set(key, wallet);
    return wallet;
  },
  addTransaction: async (userId, tx) => {
    const key = `wallet_${userId}`;
    const wallet = await walletAPI.getWallet(userId);
    wallet.transactions = [{ ...tx, id: `tx_${Date.now()}`, timestamp: new Date().toISOString() }, ...wallet.transactions];
    wallet.balance = wallet.transactions.reduce((s, t) => s + (t.type === 'credit' ? t.amount : -t.amount), 0);
    DB.set(key, wallet);
    return wallet;
  },
};

// ─── WORLD MAP / TOUR ────────────────────────────────────────────
export const tourAPI = {
  getLiveRaceLocations: async () => {
    // Seeded live race locations worldwide
    return [
      { id: 'loc1', lat: 29.7604, lng: -95.3698, city: 'Houston, TX', racers: 8, type: 'sprint' },
      { id: 'loc2', lat: 34.0522, lng: -118.2437, city: 'Los Angeles, CA', racers: 12, type: 'circuit' },
      { id: 'loc3', lat: 40.7128, lng: -74.0060, city: 'New York, NY', racers: 4, type: 'top_speed' },
      { id: 'loc4', lat: 51.5074, lng: -0.1278, city: 'London, UK', racers: 6, type: 'sprint' },
      { id: 'loc5', lat: 48.8566, lng: 2.3522, city: 'Paris, France', racers: 3, type: 'slalom' },
      { id: 'loc6', lat: 35.6762, lng: 139.6503, city: 'Tokyo, Japan', racers: 9, type: 'circuit' },
      { id: 'loc7', lat: -23.5505, lng: -46.6333, city: 'São Paulo, Brazil', racers: 5, type: 'sprint' },
      { id: 'loc8', lat: 25.2048, lng: 55.2708, city: 'Dubai, UAE', racers: 11, type: 'top_speed' },
      { id: 'loc9', lat: -33.8688, lng: 151.2093, city: 'Sydney, Australia', racers: 7, type: 'circuit' },
      { id: 'loc10', lat: 55.7558, lng: 37.6173, city: 'Moscow, Russia', racers: 4, type: 'sprint' },
      { id: 'loc11', lat: 19.4326, lng: -99.1332, city: 'Mexico City, Mexico', racers: 6, type: 'sprint' },
      { id: 'loc12', lat: 1.3521, lng: 103.8198, city: 'Singapore', racers: 8, type: 'circuit' },
    ];
  },
};
