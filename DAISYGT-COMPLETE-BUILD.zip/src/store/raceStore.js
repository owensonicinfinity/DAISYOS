import { create } from 'zustand';

export const useRaceStore = create((set, get) => ({
  activeRace: null,
  raceHistory: [],
  ghostData: [],
  liveRacers: [],
  spectators: 0,
  myStats: {
    speed: 0,
    distance: 0,
    elevation: 0,
    grade: 0,
    lat: 0,
    lng: 0,
    heading: 0,
    gForce: 0,
    rpm: 0,
    throttle: 0,
  },

  startRace: (raceConfig) => {
    set({
      activeRace: {
        id: `race_${Date.now()}`,
        ...raceConfig,
        startTime: Date.now(),
        status: 'active',
      },
    });
  },

  endRace: () => {
    const { activeRace, myStats } = get();
    if (activeRace) {
      const result = {
        ...activeRace,
        endTime: Date.now(),
        finalStats: myStats,
        status: 'completed',
      };
      set((state) => ({
        activeRace: null,
        raceHistory: [result, ...state.raceHistory].slice(0, 50),
      }));
    }
  },

  updateMyStats: (stats) => {
    set((state) => ({ myStats: { ...state.myStats, ...stats } }));
  },

  addRacer: (racer) => {
    set((state) => ({
      liveRacers: [...state.liveRacers.filter((r) => r.id !== racer.id), racer],
    }));
  },

  setSpectators: (count) => set({ spectators: count }),

  addGhostPoint: (point) => {
    set((state) => ({ ghostData: [...state.ghostData.slice(-500), point] }));
  },

  clearRace: () => set({ activeRace: null, liveRacers: [], ghostData: [], spectators: 0 }),
}));
