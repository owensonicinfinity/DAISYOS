import { create } from 'zustand';
import { persist } from 'zustand/middleware';

const DEMO_NOTIFS = [
  { id: 'n1', type: 'race_invite', title: 'Race Invite', body: 'TurboQueen challenged you to a quarter mile!', icon: '🏁', read: false, createdAt: new Date(Date.now() - 300000).toISOString(), action: '/app/race' },
  { id: 'n2', type: 'leaderboard', title: 'New Leaderboard Record', body: 'You moved to #3 on Top Speed!', icon: '🏆', read: false, createdAt: new Date(Date.now() - 900000).toISOString(), action: '/app/leaderboards' },
  { id: 'n3', type: 'club', title: 'Club Message', body: 'Ghost Protocol Racing: Friday race night scheduled!', icon: '🔗', read: false, createdAt: new Date(Date.now() - 3600000).toISOString(), action: '/app/clubs' },
  { id: 'n4', type: 'social', title: 'New Like', body: 'RocketMike liked your race post', icon: '❤️', read: true, createdAt: new Date(Date.now() - 7200000).toISOString(), action: '/app/social' },
  { id: 'n5', type: 'system', title: 'Elite Trial Active', body: 'Your 14-day free trial has started. Enjoy full access!', icon: '⚡', read: true, createdAt: new Date(Date.now() - 86400000).toISOString(), action: '/app/profile' },
];

export const useNotifStore = create(
  persist(
    (set, get) => ({
      notifications: DEMO_NOTIFS,
      unreadCount: DEMO_NOTIFS.filter(n => !n.read).length,

      add: (notif) => {
        const n = { ...notif, id: `n_${Date.now()}`, read: false, createdAt: new Date().toISOString() };
        set(state => ({
          notifications: [n, ...state.notifications].slice(0, 50),
          unreadCount: state.unreadCount + 1,
        }));
      },

      markRead: (id) => {
        set(state => {
          const notifications = state.notifications.map(n => n.id === id ? { ...n, read: true } : n);
          return { notifications, unreadCount: notifications.filter(n => !n.read).length };
        });
      },

      markAllRead: () => {
        set(state => ({
          notifications: state.notifications.map(n => ({ ...n, read: true })),
          unreadCount: 0,
        }));
      },

      clear: () => set({ notifications: [], unreadCount: 0 }),
    }),
    { name: 'daisygt-notifications' }
  )
);
