import { create } from 'zustand';
import { persist } from 'zustand/middleware';

const TRIAL_DURATION_MS = 14 * 24 * 60 * 60 * 1000; // 14 days

export const useAuthStore = create(
  persist(
    (set, get) => ({
      user: null,
      token: null,
      trialActive: false,
      trialExpiry: null,
      subscription: 'free', // free | elite | pro

      login: (userData, token) => {
        set({ user: userData, token, subscription: userData.subscription || 'free' });
      },

      logout: () => {
        set({ user: null, token: null });
      },

      updateUser: (updates) => {
        set((state) => ({ user: { ...state.user, ...updates } }));
      },

      activateTrial: (code) => {
        if (code === 'DAISYGT-FREE-2025') {
          const expiry = Date.now() + TRIAL_DURATION_MS;
          set({ trialActive: true, trialExpiry: expiry, subscription: 'elite' });
          return true;
        }
        return false;
      },

      checkTrial: () => {
        const { trialActive, trialExpiry } = get();
        if (trialActive && trialExpiry && Date.now() > trialExpiry) {
          set({ trialActive: false, subscription: 'free' });
        }
      },

      isElite: () => {
        const { subscription, trialActive, trialExpiry } = get();
        if (trialActive && trialExpiry && Date.now() < trialExpiry) return true;
        return subscription === 'elite' || subscription === 'pro';
      },

      daysLeftInTrial: () => {
        const { trialActive, trialExpiry } = get();
        if (!trialActive || !trialExpiry) return 0;
        const ms = trialExpiry - Date.now();
        return Math.max(0, Math.ceil(ms / (24 * 60 * 60 * 1000)));
      },
    }),
    {
      name: 'daisygt-auth',
      partialize: (state) => ({
        user: state.user,
        token: state.token,
        trialActive: state.trialActive,
        trialExpiry: state.trialExpiry,
        subscription: state.subscription,
      }),
    }
  )
);
