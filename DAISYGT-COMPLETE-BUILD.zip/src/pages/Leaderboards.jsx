import React, { useState, useEffect } from 'react';
import { api } from '../services/api';

const CATEGORIES = [
  { id: 'top_speed', label: 'Top Speed', icon: '💨', unit: 'mph', tab: 'racing' },
  { id: 'most_wins', label: 'Most Wins', icon: '🏆', unit: 'wins', tab: 'racing' },
  { id: 'quarter_mile', label: 'Quarter Mile', icon: '⏱️', unit: 's (low wins)', tab: 'racing' },
  { id: 'distance', label: 'Total Distance', icon: '📍', unit: 'mi', tab: 'racing' },
  { id: 'bench_press', label: 'Bench Press', icon: '🏋️', unit: 'lbs', tab: 'strength' },
  { id: 'squat', label: 'Squat Max', icon: '🦵', unit: 'lbs', tab: 'strength' },
  { id: 'deadlift', label: 'Deadlift', icon: '💪', unit: 'lbs', tab: 'strength' },
  { id: 'pullups', label: 'Pull-Ups', icon: '🔝', unit: 'reps', tab: 'strength' },
  { id: 'punch_speed', label: 'Punch Speed', icon: '🥊', unit: 'mph', tab: 'combat' },
  { id: 'heavy_bag_power', label: 'Bag Power Score', icon: '💥', unit: '/100', tab: 'combat' },
  { id: 'speed_bag_rate', label: 'Speed Bag Rate', icon: '⚡', unit: 'hits/min', tab: 'combat' },
  { id: 'shuttle_run', label: 'Shuttle Run', icon: '🏃', unit: 's (low wins)', tab: 'agility' },
  { id: 'balance_board', label: 'Balance Board', icon: '⚖️', unit: 'seconds', tab: 'agility' },
  { id: 'jump_rope', label: 'Jump Rope', icon: '🪢', unit: 'reps', tab: 'agility' },
  { id: 'harvests', label: 'Hunting Harvests', icon: '🎯', unit: 'total', tab: 'hunting' },
  { id: 'clubs_won', label: 'Club Wins', icon: '🔗', unit: 'wins', tab: 'clubs' },
];

const TABS = ['racing','strength','combat','agility','hunting','clubs'];

function LeaderRow({ entry, category }) {
  const rankColor = entry.rank === 1 ? 'var(--yellow)' : entry.rank === 2 ? 'var(--chrome-bright)' : entry.rank === 3 ? '#cd7f32' : 'var(--chrome-dim)';
  const rankIcon = entry.rank === 1 ? '🥇' : entry.rank === 2 ? '🥈' : entry.rank === 3 ? '🥉' : `#${entry.rank}`;

  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '10px 0', borderBottom: 'var(--border)' }}>
      <span style={{ fontFamily: 'var(--font-mono)', fontSize: entry.rank <= 3 ? 18 : 12, color: rankColor, width: 32, textAlign: 'center' }}>{rankIcon}</span>
      <img src={entry.user?.avatar || `https://api.dicebear.com/7.x/avataaars/svg?seed=${entry.user?.username}`} alt="" style={{ width: 28, height: 28, borderRadius: '50%', border: `1px solid ${rankColor}` }} />
      <span style={{ flex: 1, fontFamily: 'var(--font-display)', fontSize: 13, fontWeight: 600, color: entry.rank <= 3 ? 'var(--chrome-bright)' : 'var(--chrome)', letterSpacing: '0.04em', textTransform: 'uppercase' }}>{entry.user?.username || 'Racer'}</span>
      <span style={{ fontFamily: 'var(--font-mono)', fontSize: 14, fontWeight: 700, color: entry.rank === 1 ? 'var(--red)' : 'var(--chrome)' }}>
        {typeof entry.value === 'number' ? entry.value.toFixed(category.unit?.includes('s') && !category.unit?.includes('seconds') ? 2 : 0) : entry.value}
      </span>
      <span style={{ fontFamily: 'var(--font-mono)', fontSize: 10, color: 'var(--chrome-dim)', width: 60 }}>{category.unit}</span>
    </div>
  );
}

function CategoryBoard({ category }) {
  const [entries, setEntries] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    setLoading(true);
    api.leaderboards.get(category.id, 10).then(e => { setEntries(e); setLoading(false); });
  }, [category.id]);

  // Generate realistic demo data if empty
  const displayEntries = entries.length > 0 ? entries : DEMO_DATA[category.id] || [];

  return (
    <div className="panel" style={{ padding: 16 }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 16 }}>
        <span style={{ fontSize: 20 }}>{category.icon}</span>
        <div>
          <div style={{ fontFamily: 'var(--font-display)', fontSize: 13, fontWeight: 700, letterSpacing: '0.08em', textTransform: 'uppercase', color: 'var(--chrome-bright)' }}>{category.label}</div>
          <div style={{ fontSize: 10, color: 'var(--chrome-dim)', fontFamily: 'var(--font-mono)' }}>Global ranking</div>
        </div>
      </div>
      {loading ? (
        <div style={{ display: 'flex', justifyContent: 'center', padding: 20 }}><div className="loading-spinner" /></div>
      ) : displayEntries.length === 0 ? (
        <p style={{ fontSize: 13, color: 'var(--chrome-dim)', textAlign: 'center', padding: '20px 0' }}>No entries yet. Be the first!</p>
      ) : (
        displayEntries.map(e => <LeaderRow key={e.rank} entry={e} category={category} />)
      )}
    </div>
  );
}

export default function Leaderboards() {
  const [tab, setTab] = useState('racing');

  const tabCategories = CATEGORIES.filter(c => c.tab === tab);

  return (
    <div style={{ padding: 16, maxWidth: 1000, margin: '0 auto' }}>
      <h2 style={{ marginBottom: 16 }}>GLOBAL <span style={{ color: 'var(--red)' }}>LEADERBOARDS</span></h2>

      <div className="tab-bar" style={{ marginBottom: 20 }}>
        {TABS.map(t => (
          <button key={t} onClick={() => setTab(t)} className={`tab-btn ${tab === t ? 'active' : ''}`}>
            {t.charAt(0).toUpperCase() + t.slice(1)}
          </button>
        ))}
      </div>

      <div className="grid-2" style={{ gap: 16 }}>
        {tabCategories.map(cat => <CategoryBoard key={cat.id} category={cat} />)}
      </div>
    </div>
  );
}

// Demo leaderboard data
const DEMO_USERS = [
  { username: 'TurboQueen', avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=queen' },
  { username: 'RocketMike', avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=mike' },
  { username: 'GhostRider_X', avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=ghost' },
  { username: 'DaisyRacer', avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=daisy' },
  { username: 'NightRunner', avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=night' },
  { username: 'IronFist_Z', avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=iron' },
  { username: 'V8_Demon', avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=v8' },
  { username: 'SkyRacer', avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=sky' },
];
const makeDemo = (vals) => vals.map((value, i) => ({ rank: i + 1, user: DEMO_USERS[i] || DEMO_USERS[0], value }));
const DEMO_DATA = {
  top_speed: makeDemo([212, 198, 187, 174, 168, 162, 158, 151]),
  most_wins: makeDemo([61, 47, 44, 38, 33, 29, 24, 22]),
  quarter_mile: makeDemo([9.8, 10.2, 10.6, 11.1, 11.4, 11.8, 12.0, 12.3]),
  distance: makeDemo([1842, 1247, 1098, 987, 823, 742, 694, 611]),
  bench_press: makeDemo([405, 385, 360, 340, 315, 295, 275, 260]),
  squat: makeDemo([495, 455, 425, 400, 375, 350, 335, 315]),
  deadlift: makeDemo([545, 505, 475, 450, 430, 405, 385, 365]),
  pullups: makeDemo([42, 38, 35, 32, 28, 25, 22, 20]),
  punch_speed: makeDemo([68, 65, 61, 58, 55, 52, 49, 47]),
  heavy_bag_power: makeDemo([94, 91, 88, 84, 80, 76, 73, 70]),
  speed_bag_rate: makeDemo([360, 340, 320, 295, 280, 260, 245, 230]),
  shuttle_run: makeDemo([9.2, 9.5, 9.8, 10.1, 10.4, 10.7, 11.0, 11.3]),
  balance_board: makeDemo([284, 261, 238, 215, 198, 182, 167, 154]),
  jump_rope: makeDemo([342, 318, 295, 271, 254, 237, 221, 208]),
  harvests: makeDemo([28, 24, 21, 18, 16, 14, 12, 10]),
  clubs_won: makeDemo([18, 15, 13, 11, 9, 8, 7, 6]),
};
