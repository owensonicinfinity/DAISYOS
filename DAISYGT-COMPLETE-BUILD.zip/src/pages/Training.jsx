import React, { useState, useEffect } from 'react';
import { api } from '../services/api';
import { useAuthStore } from '../store/authStore';
import { getSportsInsight } from '../services/gemini';
import toast from 'react-hot-toast';

const BOXING_FIELDS = [
  { key: 'punch_speed', label: 'Punch Speed', unit: 'mph', type: 'number' },
  { key: 'heavy_bag_power', label: 'Heavy Bag Power Score', unit: '/100', type: 'number', max: 100 },
  { key: 'speed_bag_rate', label: 'Speed Bag Rate', unit: 'hits/min', type: 'number' },
  { key: 'total_punches', label: 'Total Punch Count', unit: '', type: 'number' },
  { key: 'total_kicks', label: 'Total Kick Count', unit: '', type: 'number' },
  { key: 'combos', label: 'Combos Completed', unit: '', type: 'number' },
  { key: 'rounds', label: 'Rounds', unit: '', type: 'number' },
  { key: 'round_duration', label: 'Round Duration', unit: 'min', type: 'number' },
];

const LIFTING_FIELDS = [
  { key: 'bench_press', label: 'Bench Press', unit: 'lbs' },
  { key: 'squat', label: 'Squat', unit: 'lbs' },
  { key: 'deadlift', label: 'Deadlift', unit: 'lbs' },
  { key: 'ohp', label: 'Overhead Press', unit: 'lbs' },
  { key: 'clean_jerk', label: 'Clean & Jerk', unit: 'lbs' },
  { key: 'snatch', label: 'Snatch', unit: 'lbs' },
  { key: 'curl', label: 'Curl Max', unit: 'lbs' },
  { key: 'leg_press', label: 'Leg Press', unit: 'lbs' },
  { key: 'lat_pulldown', label: 'Lat Pulldown', unit: 'lbs' },
  { key: 'rowing', label: 'Rowing', unit: 'lbs' },
  { key: 'pullups', label: 'Pull-Ups', unit: 'reps' },
  { key: 'pushups', label: 'Push-Ups', unit: 'reps' },
  { key: 'situps', label: 'Sit-Ups', unit: 'reps' },
  { key: 'dips', label: 'Dips', unit: 'reps' },
  { key: 'plank', label: 'Plank Duration', unit: 'sec' },
  { key: 'box_jumps', label: 'Box Jumps', unit: 'reps' },
  { key: 'battle_ropes', label: 'Battle Ropes Duration', unit: 'sec' },
  { key: 'kettlebells', label: 'Kettlebell Swings', unit: 'reps' },
];

const AGILITY_FIELDS = [
  { key: 'balance_board', label: 'Balance Board', unit: 'sec' },
  { key: 'single_leg_stand', label: 'Single Leg Stand', unit: 'sec' },
  { key: 'agility_ladder', label: 'Agility Ladder', unit: 'sec' },
  { key: 'shuttle_run', label: 'Shuttle Run', unit: 'sec' },
  { key: 't_test', label: 'T-Test', unit: 'sec' },
  { key: 'reaction_drills', label: 'Reaction Drills Score', unit: '/100' },
  { key: 'jump_rope', label: 'Jump Rope Count', unit: 'reps' },
  { key: 'double_unders', label: 'Double Unders', unit: 'reps' },
  { key: 'cone_drills', label: 'Cone Drill Time', unit: 'sec' },
];

function FieldInput({ field, value, onChange }) {
  return (
    <div>
      <label>{field.label} {field.unit && <span style={{ color: 'var(--chrome-dim)' }}>({field.unit})</span>}</label>
      <input
        type={field.type || 'number'}
        value={value || ''}
        onChange={e => onChange(field.key, e.target.value)}
        placeholder={`Enter ${field.label.toLowerCase()}`}
        min={0}
        max={field.max}
      />
    </div>
  );
}

export default function Training() {
  const { user } = useAuthStore();
  const [tab, setTab] = useState('boxing');
  const [form, setForm] = useState({});
  const [sessions, setSessions] = useState([]);
  const [saving, setLoading] = useState(false);
  const [aiTip, setAiTip] = useState('');
  const [reps, setReps] = useState({});

  useEffect(() => {
    if (user?.id) api.training.getHistory(user.id).then(setSessions);
  }, [user]);

  const setField = (key, val) => setForm(f => ({ ...f, [key]: val }));

  const handleLog = async () => {
    const filled = Object.entries(form).filter(([, v]) => v !== '' && v !== undefined);
    if (filled.length === 0) { toast.error('Enter at least one metric'); return; }
    setLoading(true);
    const session = { userId: user?.id, category: tab, date: new Date().toISOString(), ...form };
    await api.training.logSession(session);
    setSessions(s => [session, ...s]);
    toast.success(`${tab} session logged! 💪`);

    // AI tip
    try {
      const tip = await getSportsInsight(tab, form);
      setAiTip(tip);
    } catch { /* silent */ }

    setForm({});
    setLoading(false);
  };

  const currentFields = tab === 'boxing' ? BOXING_FIELDS : tab === 'lifting' ? LIFTING_FIELDS : AGILITY_FIELDS;

  const recentByTab = sessions.filter(s => s.category === tab).slice(0, 3);

  return (
    <div style={{ padding: 16, maxWidth: 900, margin: '0 auto' }}>
      <h2 style={{ marginBottom: 16 }}>TRAINING <span style={{ color: 'var(--red)' }}>HUB</span></h2>

      <div className="tab-bar" style={{ marginBottom: 20 }}>
        {[['boxing','🥊 Boxing'],['lifting','🏋️ Lifting'],['agility','⚖️ Agility'],['history','📋 History'],['leaderboard','🏆 Leaderboard']].map(([val, label]) => (
          <button key={val} onClick={() => setTab(val)} className={`tab-btn ${tab === val ? 'active' : ''}`}>{label}</button>
        ))}
      </div>

      {(tab === 'boxing' || tab === 'lifting' || tab === 'agility') && (
        <div className="grid-2" style={{ gap: 16, alignItems: 'start' }}>
          {/* Form */}
          <div className="panel" style={{ padding: 20 }}>
            <div style={{ fontFamily: 'var(--font-display)', fontSize: 13, fontWeight: 700, letterSpacing: '0.08em', textTransform: 'uppercase', color: 'var(--chrome-bright)', marginBottom: 16 }}>
              Log {tab.charAt(0).toUpperCase() + tab.slice(1)} Session
            </div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 10, maxHeight: 420, overflowY: 'auto', paddingRight: 4 }}>
              {currentFields.map(f => (
                <FieldInput key={f.key} field={f} value={form[f.key]} onChange={setField} />
              ))}
              {tab === 'lifting' && (
                <div>
                  <label>Sets Completed</label>
                  <input type="number" value={form.sets || ''} onChange={e => setField('sets', e.target.value)} placeholder="Total sets" />
                </div>
              )}
              <div>
                <label>Notes</label>
                <textarea value={form.notes || ''} onChange={e => setField('notes', e.target.value)} rows={2} placeholder="How did it feel? Any PRs?" style={{ resize: 'none' }} />
              </div>
            </div>
            <button onClick={handleLog} disabled={saving} className="btn btn-primary" style={{ width: '100%', justifyContent: 'center', marginTop: 14 }}>
              {saving ? 'Logging...' : '💪 Log Session'}
            </button>
          </div>

          {/* Side: Recent + AI */}
          <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
            {aiTip && (
              <div style={{ background: 'rgba(0,229,255,0.05)', border: '1px solid rgba(0,229,255,0.2)', borderRadius: 2, padding: 14 }}>
                <div style={{ fontFamily: 'var(--font-display)', fontSize: 11, fontWeight: 600, letterSpacing: '0.08em', textTransform: 'uppercase', color: 'var(--cyan)', marginBottom: 6 }}>⚡ DaisyAI Tip</div>
                <p style={{ fontSize: 12, lineHeight: 1.7, color: 'var(--chrome)' }}>{aiTip}</p>
              </div>
            )}

            <div className="panel" style={{ padding: 14 }}>
              <div style={{ fontFamily: 'var(--font-display)', fontSize: 12, fontWeight: 600, letterSpacing: '0.08em', textTransform: 'uppercase', color: 'var(--chrome-dim)', marginBottom: 12 }}>Recent Sessions</div>
              {recentByTab.length === 0 ? (
                <p style={{ fontSize: 12, color: 'var(--chrome-dim)' }}>No {tab} sessions logged yet.</p>
              ) : recentByTab.map((s, i) => (
                <div key={i} style={{ padding: '8px 0', borderBottom: 'var(--border)' }}>
                  <div style={{ fontSize: 11, color: 'var(--chrome-dim)', fontFamily: 'var(--font-mono)', marginBottom: 4 }}>{new Date(s.date).toLocaleDateString()}</div>
                  <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8 }}>
                    {Object.entries(s).filter(([k, v]) => !['userId','category','date','notes','id','createdAt'].includes(k) && v).slice(0, 4).map(([k, v]) => (
                      <span key={k} style={{ fontFamily: 'var(--font-mono)', fontSize: 10, color: 'var(--red)' }}>{k.replace('_',' ')}: <strong>{v}</strong></span>
                    ))}
                  </div>
                  {s.notes && <p style={{ fontSize: 11, color: 'var(--chrome-dim)', marginTop: 4 }}>{s.notes}</p>}
                </div>
              ))}
            </div>

            {/* Quick PRs */}
            <div className="panel" style={{ padding: 14 }}>
              <div style={{ fontFamily: 'var(--font-display)', fontSize: 12, fontWeight: 600, letterSpacing: '0.08em', textTransform: 'uppercase', color: 'var(--chrome-dim)', marginBottom: 10 }}>Personal Bests</div>
              {tab === 'boxing' && [
                ['Punch Speed', '68 mph'], ['Bag Power', '91/100'], ['Rounds', '12'],
              ].map(([label, val]) => (
                <div key={label} style={{ display: 'flex', justifyContent: 'space-between', padding: '6px 0', borderBottom: 'var(--border)', fontSize: 12 }}>
                  <span style={{ color: 'var(--chrome-dim)' }}>{label}</span>
                  <span style={{ fontFamily: 'var(--font-mono)', color: 'var(--yellow)' }}>🏆 {val}</span>
                </div>
              ))}
              {tab === 'lifting' && [
                ['Bench Press', '315 lbs'], ['Squat', '405 lbs'], ['Deadlift', '455 lbs'], ['Pull-Ups', '28 reps'],
              ].map(([label, val]) => (
                <div key={label} style={{ display: 'flex', justifyContent: 'space-between', padding: '6px 0', borderBottom: 'var(--border)', fontSize: 12 }}>
                  <span style={{ color: 'var(--chrome-dim)' }}>{label}</span>
                  <span style={{ fontFamily: 'var(--font-mono)', color: 'var(--yellow)' }}>🏆 {val}</span>
                </div>
              ))}
              {tab === 'agility' && [
                ['Shuttle Run', '9.8s'], ['Balance Board', '214s'], ['Jump Rope', '287 reps'],
              ].map(([label, val]) => (
                <div key={label} style={{ display: 'flex', justifyContent: 'space-between', padding: '6px 0', borderBottom: 'var(--border)', fontSize: 12 }}>
                  <span style={{ color: 'var(--chrome-dim)' }}>{label}</span>
                  <span style={{ fontFamily: 'var(--font-mono)', color: 'var(--yellow)' }}>🏆 {val}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {tab === 'history' && (
        <div className="panel" style={{ padding: 16 }}>
          <div style={{ fontFamily: 'var(--font-display)', fontSize: 13, fontWeight: 700, letterSpacing: '0.08em', textTransform: 'uppercase', color: 'var(--chrome-dim)', marginBottom: 16 }}>All Training Sessions</div>
          {sessions.length === 0 ? (
            <div style={{ textAlign: 'center', padding: '40px 0', color: 'var(--chrome-dim)' }}>
              <div style={{ fontSize: 40, marginBottom: 12 }}>💪</div>
              <p>No sessions logged yet. Start training!</p>
            </div>
          ) : sessions.map((s, i) => (
            <div key={i} style={{ padding: '12px 0', borderBottom: 'var(--border)' }}>
              <div style={{ display: 'flex', gap: 10, marginBottom: 6 }}>
                <span className={`badge badge-${s.category === 'boxing' ? 'red' : s.category === 'lifting' ? 'cyan' : 'yellow'}`}>{s.category}</span>
                <span style={{ fontFamily: 'var(--font-mono)', fontSize: 11, color: 'var(--chrome-dim)' }}>{new Date(s.date).toLocaleString()}</span>
              </div>
              <div style={{ display: 'flex', flexWrap: 'wrap', gap: 12 }}>
                {Object.entries(s).filter(([k, v]) => !['userId','category','date','notes','id','createdAt'].includes(k) && v).map(([k, v]) => (
                  <span key={k} style={{ fontFamily: 'var(--font-mono)', fontSize: 11, color: 'var(--chrome)' }}>
                    {k.replace(/_/g,' ')}: <strong style={{ color: 'var(--red)' }}>{v}</strong>
                  </span>
                ))}
              </div>
              {s.notes && <p style={{ fontSize: 12, color: 'var(--chrome-dim)', marginTop: 6 }}>{s.notes}</p>}
            </div>
          ))}
        </div>
      )}

      {tab === 'leaderboard' && (
        <div className="grid-3" style={{ gap: 14 }}>
          {[
            { title: '🥊 Boxing — Punch Speed', entries: [['TurboQueen','68 mph'],['RocketMike','65 mph'],['GhostRider_X','61 mph']] },
            { title: '🏋️ Lifting — Bench Press', entries: [['V8_Demon','405 lbs'],['IronFist_Z','385 lbs'],['NightRunner','360 lbs']] },
            { title: '⚖️ Agility — Shuttle Run', entries: [['SkyRacer','9.2s'],['TurboQueen','9.5s'],['DaisyRacer','9.8s']] },
            { title: '💪 Deadlift', entries: [['IronFist_Z','545 lbs'],['V8_Demon','505 lbs'],['RocketMike','475 lbs']] },
            { title: '🪢 Jump Rope', entries: [['GhostRider_X','342'],['TurboQueen','318'],['SkyRacer','295']] },
            { title: '🔝 Pull-Ups', entries: [['SkyRacer','42'],['NightRunner','38'],['RocketMike','35']] },
          ].map(board => (
            <div key={board.title} className="panel" style={{ padding: 14 }}>
              <div style={{ fontFamily: 'var(--font-display)', fontSize: 12, fontWeight: 700, letterSpacing: '0.06em', textTransform: 'uppercase', color: 'var(--chrome-bright)', marginBottom: 12 }}>{board.title}</div>
              {board.entries.map(([name, val], i) => (
                <div key={name} style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '7px 0', borderBottom: 'var(--border)' }}>
                  <span style={{ fontFamily: 'var(--font-mono)', fontSize: 14 }}>{i === 0 ? '🥇' : i === 1 ? '🥈' : '🥉'}</span>
                  <span style={{ fontFamily: 'var(--font-display)', fontSize: 12, color: 'var(--chrome)', flex: 1, letterSpacing: '0.04em' }}>{name}</span>
                  <span style={{ fontFamily: 'var(--font-mono)', fontSize: 12, color: 'var(--red)', fontWeight: 700 }}>{val}</span>
                </div>
              ))}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
