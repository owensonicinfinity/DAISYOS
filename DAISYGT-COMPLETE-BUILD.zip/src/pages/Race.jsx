import React, { useState, useEffect, useRef, useCallback } from 'react';
import { Link } from 'react-router-dom';
import { useRaceStore } from '../store/raceStore';
import { useAuthStore } from '../store/authStore';
import { startGPS, stopGPS, startSimulation, stopSimulation, onTelemetryUpdate } from '../services/gps';
import { api } from '../services/api';
import { analyzeRaceTelemetry } from '../services/gemini';
import toast from 'react-hot-toast';

const VEHICLE_ICONS = { Car: '🏎️', Motorcycle: '🏍️', Truck: '🚚', Boat: '🚤', Aircraft: '✈️', 'ATV/UTV': '🏋️', Scooter: '🛵', Other: '🚗' };

export default function Race() {
  const { user, isElite } = useAuthStore();
  const { activeRace, myStats, startRace, endRace, updateMyStats, liveRacers, addRacer } = useRaceStore();

  const [phase, setPhase] = useState('setup'); // setup | countdown | racing | finished
  const [config, setConfig] = useState({ name: 'Street Race', type: 'sprint', vehicle: user?.primaryVehicle || 'Car', mode: 'gps', distance: 0.25 });
  const [countdown, setCountdown] = useState(3);
  const [elapsed, setElapsed] = useState(0);
  const [topSpeed, setTopSpeed] = useState(0);
  const [distance, setDistance] = useState(0);
  const [aiAnalysis, setAiAnalysis] = useState('');
  const [simMode, setSimMode] = useState(false);
  const [ghostRacers, setGhostRacers] = useState([]);

  const raceStartRef = useRef(null);
  const telemetryRef = useRef([]);
  const elapsedRef = useRef(null);

  // Simulate ghost opponents
  const spawnGhostRacers = useCallback(() => {
    const ghosts = [
      { id: 'ghost1', username: 'TurboQueen', vehicle: 'Car', speed: 0, color: '#00e5ff', icon: '🏎️', position: 1 },
      { id: 'ghost2', username: 'RocketMike', vehicle: 'Car', speed: 0, color: '#ff6b00', icon: '🏍️', position: 2 },
    ];
    ghosts.forEach(g => addRacer(g));
    setGhostRacers(ghosts);

    // Simulate ghost movement
    let t = 0;
    const ghostInterval = setInterval(() => {
      t += 0.5;
      ghosts.forEach((g, i) => {
        g.speed = 55 + Math.sin(t * 0.4 + i) * 25 + Math.random() * 8;
        g.distance = (t * g.speed) / 7200;
        addRacer({ ...g });
      });
    }, 500);
    return () => clearInterval(ghostInterval);
  }, [addRacer]);

  const startRaceFlow = () => {
    setPhase('countdown');
    setCountdown(3);
    let c = 3;
    const cd = setInterval(() => {
      c--;
      setCountdown(c);
      if (c <= 0) {
        clearInterval(cd);
        beginRace();
      }
    }, 1000);
  };

  const beginRace = () => {
    raceStartRef.current = Date.now();
    startRace({ ...config, userId: user?.id });
    setPhase('racing');

    // Start elapsed timer
    elapsedRef.current = setInterval(() => {
      setElapsed(Math.floor((Date.now() - raceStartRef.current) / 1000));
    }, 1000);

    // Start GPS or simulation
    const cleanup = onTelemetryUpdate((data) => {
      updateMyStats({ speed: data.speed, lat: data.lat, lng: data.lng, heading: data.heading, gForce: data.gForce, altitude: data.altitude });
      setTopSpeed(prev => Math.max(prev, data.speed));
      setDistance(prev => {
        const newDist = prev + (data.speed * 0.5 / 3600);
        return Math.round(newDist * 1000) / 1000;
      });
      telemetryRef.current.push({ ...data, elapsed: Date.now() - raceStartRef.current });
      setSimMode(data.simulated || false);
    });

    startGPS();
    const cleanupGhost = spawnGhostRacers();

    // Store cleanup refs
    raceStartRef.cleanup = () => {
      cleanup();
      cleanupGhost?.();
      stopGPS();
      stopSimulation();
      clearInterval(elapsedRef.current);
    };
  };

  const finishRace = async () => {
    raceStartRef.cleanup?.();
    endRace();
    setPhase('finished');

    // Save result
    const result = {
      userId: user?.id,
      name: config.name,
      type: config.type,
      position: 1,
      topSpeed,
      distance,
      elapsed,
      quarterMile: distance >= 0.25 ? elapsed : null,
      telemetryPoints: telemetryRef.current.length,
    };
    await api.races.saveResult(result);
    await api.telemetry.save({ userId: user?.id, ...result, points: telemetryRef.current.slice(-100) });

    // AI Analysis
    if (isElite()) {
      try {
        const analysis = await analyzeRaceTelemetry({ topSpeed, distance, elapsed, avgSpeed: distance > 0 ? (distance / elapsed * 3600) : 0 });
        setAiAnalysis(analysis);
      } catch { /* silent */ }
    }

    toast.success('Race complete! Results saved. 🏁');
  };

  useEffect(() => {
    return () => raceStartRef.cleanup?.();
  }, []);

  const formatTime = (s) => `${Math.floor(s / 60).toString().padStart(2,'0')}:${(s % 60).toString().padStart(2,'0')}`;

  return (
    <div style={{ padding: 16, maxWidth: 900, margin: '0 auto' }}>
      <h2 style={{ marginBottom: 16 }}>RACE <span style={{ color: 'var(--red)' }}>CONTROL</span></h2>

      {/* ─── SETUP PHASE ─── */}
      {phase === 'setup' && (
        <div className="grid-2" style={{ gap: 16 }}>
          <div className="panel" style={{ padding: 20 }}>
            <div style={{ fontFamily: 'var(--font-display)', fontSize: 13, fontWeight: 700, letterSpacing: '0.08em', textTransform: 'uppercase', color: 'var(--chrome-dim)', marginBottom: 16 }}>Race Setup</div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
              <div>
                <label>Race Name</label>
                <input value={config.name} onChange={e => setConfig(c => ({ ...c, name: e.target.value }))} />
              </div>
              <div>
                <label>Race Type</label>
                <select value={config.type} onChange={e => setConfig(c => ({ ...c, type: e.target.value }))}>
                  <option value="sprint">Sprint (1/4 Mile)</option>
                  <option value="mile">Full Mile</option>
                  <option value="circuit">Circuit (Laps)</option>
                  <option value="endurance">Endurance</option>
                  <option value="top_speed">Top Speed Run</option>
                  <option value="slalom">Slalom</option>
                </select>
              </div>
              <div>
                <label>Your Vehicle</label>
                <select value={config.vehicle} onChange={e => setConfig(c => ({ ...c, vehicle: e.target.value }))}>
                  {Object.keys(VEHICLE_ICONS).map(v => <option key={v}>{v}</option>)}
                </select>
              </div>
              <div>
                <label>Race Mode</label>
                <select value={config.mode} onChange={e => setConfig(c => ({ ...c, mode: e.target.value }))}>
                  <option value="gps">GPS Live Race</option>
                  <option value="ghost">Ghost Replay Race</option>
                  <option value="solo">Solo Dyno Run</option>
                  <option value="spectator">Spectator Event</option>
                </select>
              </div>
            </div>
            <button onClick={startRaceFlow} className="btn btn-primary" style={{ width: '100%', justifyContent: 'center', marginTop: 20, fontSize: '1rem', padding: '14px' }}>
              🏁 READY — START RACE
            </button>
          </div>

          <div>
            <div className="panel" style={{ padding: 16, marginBottom: 12 }}>
              <div style={{ fontFamily: 'var(--font-display)', fontSize: 12, fontWeight: 600, letterSpacing: '0.08em', textTransform: 'uppercase', color: 'var(--chrome-dim)', marginBottom: 12 }}>Race Info</div>
              <div className="grid-2" style={{ gap: 8 }}>
                <div className="stat-box" style={{ background: 'var(--bg-surface)', padding: 10 }}>
                  <div className="stat-label">Mode</div>
                  <div style={{ fontFamily: 'var(--font-display)', fontSize: '1rem', color: 'var(--chrome)', fontWeight: 700 }}>GPS LIVE</div>
                </div>
                <div className="stat-box" style={{ background: 'var(--bg-surface)', padding: 10 }}>
                  <div className="stat-label">Vehicle</div>
                  <div style={{ fontSize: '1.5rem' }}>{VEHICLE_ICONS[config.vehicle] || '🏎️'}</div>
                </div>
              </div>
            </div>

            <div className="panel" style={{ padding: 16, marginBottom: 12 }}>
              <div style={{ fontFamily: 'var(--font-display)', fontSize: 12, fontWeight: 600, letterSpacing: '0.08em', textTransform: 'uppercase', color: 'var(--chrome-dim)', marginBottom: 10 }}>Ghost Opponents</div>
              <div style={{ fontSize: 12, color: 'var(--chrome-dim)', marginBottom: 10 }}>Simulated racers will appear as ghost overlays.</div>
              {[
                { name: 'TurboQueen', icon: '🏎️', color: 'var(--cyan)' },
                { name: 'RocketMike', icon: '🏍️', color: 'var(--orange)' },
              ].map(r => (
                <div key={r.name} style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '6px 0', borderBottom: 'var(--border)' }}>
                  <span>{r.icon}</span>
                  <span style={{ fontFamily: 'var(--font-display)', fontSize: 12, color: r.color }}>{r.name}</span>
                  <span className="badge badge-cyan" style={{ marginLeft: 'auto' }}>GHOST</span>
                </div>
              ))}
            </div>

            <div className="panel" style={{ padding: 16 }}>
              <Link to="/app/race/split/demo" className="btn btn-cyan" style={{ width: '100%', justifyContent: 'center' }}>
                ⊡ Split-Screen View
              </Link>
            </div>
          </div>
        </div>
      )}

      {/* ─── COUNTDOWN ─── */}
      {phase === 'countdown' && (
        <div style={{ minHeight: '60vh', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center' }}>
          <div style={{ fontFamily: 'var(--font-display)', fontSize: '10rem', fontWeight: 700, color: countdown === 1 ? 'var(--green)' : countdown === 2 ? 'var(--yellow)' : 'var(--red)', textShadow: `0 0 80px currentColor`, lineHeight: 1, animation: 'fadeIn 0.2s ease' }}>
            {countdown || 'GO!'}
          </div>
          <p style={{ fontFamily: 'var(--font-display)', fontSize: '1.5rem', letterSpacing: '0.2em', textTransform: 'uppercase', color: 'var(--chrome-dim)', marginTop: 20 }}>
            {countdown > 0 ? 'GET READY' : 'FULL THROTTLE'}
          </p>
        </div>
      )}

      {/* ─── RACING PHASE ─── */}
      {phase === 'racing' && (
        <div>
          {simMode && (
            <div style={{ background: 'rgba(255,204,0,0.08)', border: '1px solid rgba(255,204,0,0.3)', borderRadius: 2, padding: '8px 14px', marginBottom: 12, fontSize: 11, color: 'var(--yellow)', fontFamily: 'var(--font-mono)' }}>
              ⚠️ SIMULATION MODE — Real GPS unavailable. Data is simulated for demonstration.
            </div>
          )}

          {/* Main Speedometer */}
          <div style={{ display: 'flex', justifyContent: 'center', marginBottom: 20 }}>
            <div style={{ position: 'relative', width: 220, height: 220, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', background: 'var(--bg-panel)', border: '1px solid rgba(224,0,32,0.3)', borderRadius: '50%', boxShadow: '0 0 60px rgba(224,0,32,0.15)' }}>
              <div style={{ fontFamily: 'var(--font-mono)', fontSize: '3.5rem', fontWeight: 700, color: 'var(--red)', lineHeight: 1 }}>
                {Math.round(myStats.speed)}
              </div>
              <div style={{ fontFamily: 'var(--font-mono)', fontSize: 12, color: 'var(--chrome-dim)', marginTop: 4 }}>MPH</div>
              <div style={{ position: 'absolute', bottom: 30, display: 'flex', gap: 16, alignItems: 'center' }}>
                <span className="live-dot" />
                <span style={{ fontFamily: 'var(--font-mono)', fontSize: 11, color: 'var(--red)', letterSpacing: '0.08em' }}>LIVE</span>
              </div>
            </div>
          </div>

          {/* Telemetry Grid */}
          <div className="grid-4" style={{ marginBottom: 16 }}>
            {[
              { label: 'Elapsed', value: formatTime(elapsed), unit: '' },
              { label: 'Distance', value: distance.toFixed(3), unit: 'mi' },
              { label: 'Top Speed', value: Math.round(topSpeed), unit: 'mph' },
              { label: 'G-Force', value: (myStats.gForce || 0).toFixed(2), unit: 'g' },
            ].map(s => (
              <div key={s.label} className="stat-box" style={{ background: 'var(--bg-panel)', border: 'var(--border)', padding: '12px 10px', textAlign: 'center' }}>
                <div className="stat-label">{s.label}</div>
                <div className="stat-value" style={{ fontSize: '1.6rem', color: 'var(--chrome-bright)' }}>{s.value}</div>
                {s.unit && <div className="stat-unit">{s.unit}</div>}
              </div>
            ))}
          </div>

          {/* Ghost Racers */}
          <div className="panel" style={{ padding: 14, marginBottom: 16 }}>
            <div style={{ fontFamily: 'var(--font-display)', fontSize: 11, fontWeight: 600, letterSpacing: '0.08em', textTransform: 'uppercase', color: 'var(--chrome-dim)', marginBottom: 10 }}>
              Ghost Overlay — Race Position
            </div>
            {[{ name: 'YOU', speed: Math.round(myStats.speed), dist: distance, color: 'var(--green)', icon: VEHICLE_ICONS[config.vehicle] }, ...ghostRacers.map(g => ({ name: g.username, speed: Math.round(g.speed || 0), dist: g.distance || 0, color: g.color, icon: g.icon }))].sort((a, b) => b.dist - a.dist).map((r, i) => (
              <div key={r.name} style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '8px 0', borderBottom: 'var(--border)' }}>
                <span style={{ fontFamily: 'var(--font-mono)', fontSize: 11, color: 'var(--chrome-dim)', width: 20 }}>P{i + 1}</span>
                <span>{r.icon}</span>
                <span style={{ fontFamily: 'var(--font-display)', fontSize: 13, fontWeight: 600, color: r.color, flex: 1 }}>{r.name}</span>
                <span style={{ fontFamily: 'var(--font-mono)', fontSize: 12, color: r.color }}>{r.speed} mph</span>
                <div style={{ width: 100, height: 4, background: 'var(--bg-elevated)', borderRadius: 2 }}>
                  <div style={{ height: '100%', background: r.color, borderRadius: 2, width: `${Math.min(100, r.dist * 400)}%` }} />
                </div>
              </div>
            ))}
          </div>

          <div style={{ display: 'flex', gap: 10 }}>
            <button onClick={finishRace} className="btn btn-primary btn-lg" style={{ flex: 1, justifyContent: 'center' }}>
              🏁 FINISH RACE
            </button>
            <Link to="/app/race/split/live" className="btn btn-cyan" style={{ justifyContent: 'center' }}>⊡ Split</Link>
          </div>
        </div>
      )}

      {/* ─── FINISHED PHASE ─── */}
      {phase === 'finished' && (
        <div className="panel" style={{ padding: 24, textAlign: 'center' }}>
          <div style={{ fontSize: 48, marginBottom: 16 }}>🏆</div>
          <h2 style={{ marginBottom: 8, color: 'var(--yellow)' }}>RACE COMPLETE</h2>
          <div className="grid-3" style={{ gap: 12, margin: '24px 0' }}>
            <div className="stat-box" style={{ background: 'var(--bg-surface)', padding: 16, textAlign: 'center' }}>
              <div className="stat-label">Time</div>
              <div className="stat-value" style={{ fontSize: '1.8rem', color: 'var(--red)' }}>{formatTime(elapsed)}</div>
            </div>
            <div className="stat-box" style={{ background: 'var(--bg-surface)', padding: 16, textAlign: 'center' }}>
              <div className="stat-label">Top Speed</div>
              <div className="stat-value" style={{ fontSize: '1.8rem', color: 'var(--red)' }}>{Math.round(topSpeed)}</div>
              <div className="stat-unit">MPH</div>
            </div>
            <div className="stat-box" style={{ background: 'var(--bg-surface)', padding: 16, textAlign: 'center' }}>
              <div className="stat-label">Distance</div>
              <div className="stat-value" style={{ fontSize: '1.8rem', color: 'var(--red)' }}>{distance.toFixed(3)}</div>
              <div className="stat-unit">MI</div>
            </div>
          </div>

          {aiAnalysis && (
            <div style={{ background: 'rgba(0,229,255,0.05)', border: '1px solid rgba(0,229,255,0.2)', borderRadius: 2, padding: 16, margin: '0 0 20px', textAlign: 'left' }}>
              <div style={{ fontFamily: 'var(--font-display)', fontSize: 11, fontWeight: 600, letterSpacing: '0.08em', textTransform: 'uppercase', color: 'var(--cyan)', marginBottom: 8 }}>⚡ DaisyAI Race Analysis</div>
              <p style={{ fontSize: 13, lineHeight: 1.7, color: 'var(--chrome)' }}>{aiAnalysis}</p>
            </div>
          )}

          <div style={{ display: 'flex', gap: 10, justifyContent: 'center', flexWrap: 'wrap' }}>
            <button onClick={() => { setPhase('setup'); setElapsed(0); setTopSpeed(0); setDistance(0); setAiAnalysis(''); }} className="btn btn-primary">
              🏁 Race Again
            </button>
            <Link to="/app/marketplace" className="btn btn-cyan">💎 Mint Race NFT</Link>
            <Link to="/app/analytics" className="btn btn-ghost">📈 View Analytics</Link>
          </div>
        </div>
      )}
    </div>
  );
}
