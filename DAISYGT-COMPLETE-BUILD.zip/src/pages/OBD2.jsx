import React, { useState, useRef, useEffect } from 'react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { useAuthStore } from '../store/authStore';
import { api } from '../services/api';
import toast from 'react-hot-toast';
import { Link } from 'react-router-dom';

const OBD_PIDS = [
  { pid: '010C', name: 'Engine RPM', unit: 'rpm', color: 'var(--red)', max: 8000 },
  { pid: '010D', name: 'Vehicle Speed', unit: 'mph', color: 'var(--cyan)', max: 200 },
  { pid: '0111', name: 'Throttle Position', unit: '%', color: 'var(--yellow)', max: 100 },
  { pid: '0104', name: 'Engine Load', unit: '%', color: 'var(--orange)', max: 100 },
  { pid: '0105', name: 'Coolant Temp', unit: '°F', color: 'var(--green)', max: 260 },
  { pid: '010F', name: 'Intake Air Temp', unit: '°F', color: 'var(--chrome)', max: 200 },
  { pid: '010B', name: 'Intake Manifold Pressure', unit: 'kPa', color: 'var(--cyan)', max: 255 },
  { pid: '0142', name: 'Battery Voltage', unit: 'V', color: 'var(--green)', max: 16 },
];

const DTC_CODES = {
  'P0300': 'Random/Multiple Cylinder Misfire Detected',
  'P0301': 'Cylinder 1 Misfire Detected',
  'P0302': 'Cylinder 2 Misfire Detected',
  'P0420': 'Catalyst System Efficiency Below Threshold',
  'P0171': 'System Too Lean (Bank 1)',
  'P0172': 'System Too Rich (Bank 1)',
  'P0101': 'Mass Air Flow Sensor Range/Performance',
  'P0113': 'Intake Air Temperature Sensor High Input',
  'P0442': 'Evaporative Emission System Leak Detected (Small)',
};

function GaugeArc({ value, max, color, label, unit }) {
  const pct = Math.min(1, value / max);
  const r = 44;
  const cx = 56;
  const cy = 56;
  const startAngle = -220 * (Math.PI / 180);
  const endAngle = 40 * (Math.PI / 180);
  const totalArc = endAngle - startAngle;
  const arcEnd = startAngle + totalArc * pct;
  const x1 = cx + r * Math.cos(startAngle);
  const y1 = cy + r * Math.sin(startAngle);
  const x2 = cx + r * Math.cos(arcEnd);
  const y2 = cy + r * Math.sin(arcEnd);
  const largeArc = totalArc * pct > Math.PI ? 1 : 0;
  const fullX2 = cx + r * Math.cos(endAngle);
  const fullY2 = cy + r * Math.sin(endAngle);

  return (
    <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 4 }}>
      <svg width="112" height="80" viewBox="0 0 112 80">
        {/* Track */}
        <path
          d={`M ${cx + r * Math.cos(startAngle)} ${cy + r * Math.sin(startAngle)} A ${r} ${r} 0 1 1 ${fullX2} ${fullY2}`}
          fill="none" stroke="rgba(255,255,255,0.08)" strokeWidth="6" strokeLinecap="round"
        />
        {/* Value arc */}
        {pct > 0 && (
          <path
            d={`M ${x1} ${y1} A ${r} ${r} 0 ${largeArc} 1 ${x2} ${y2}`}
            fill="none" stroke={color} strokeWidth="6" strokeLinecap="round"
            style={{ filter: `drop-shadow(0 0 4px ${color})` }}
          />
        )}
        {/* Center value */}
        <text x={cx} y={cy - 4} textAnchor="middle" fill="white" fontSize="14" fontFamily="JetBrains Mono" fontWeight="700">
          {value}
        </text>
        <text x={cx} y={cy + 12} textAnchor="middle" fill="rgba(200,205,216,0.6)" fontSize="8" fontFamily="JetBrains Mono">
          {unit}
        </text>
      </svg>
      <span style={{ fontFamily: 'var(--font-mono)', fontSize: 9, letterSpacing: '0.08em', textTransform: 'uppercase', color: 'var(--chrome-dim)', textAlign: 'center' }}>{label}</span>
    </div>
  );
}

export default function OBD2() {
  const { user, isElite } = useAuthStore();
  const elite = isElite();
  const [tab, setTab] = useState('obd2');
  const [connected, setConnected] = useState(false);
  const [connecting, setConnecting] = useState(false);
  const [simulating, setSimulating] = useState(false);
  const [liveData, setLiveData] = useState({ rpm: 0, speed: 0, throttle: 0, load: 0, coolant: 180, intake: 72, map: 101, voltage: 14.2 });
  const [history, setHistory] = useState([]);
  const [dtcCodes, setDtcCodes] = useState([]);
  const [scanningDTC, setScanningDTC] = useState(false);
  const [micActive, setMicActive] = useState(false);
  const [micRPM, setMicRPM] = useState(0);
  const [micData, setMicData] = useState([]);
  const [sparkEvents, setSparkEvents] = useState([]);
  const simRef = useRef(null);
  const micRef = useRef(null);

  const startSim = () => {
    setSimulating(true);
    setConnected(true);
    let t = 0;
    simRef.current = setInterval(() => {
      t += 0.2;
      const rpm = Math.round(800 + Math.sin(t * 0.3) * 2200 + Math.random() * 300);
      const speed = Math.round(Math.max(0, rpm / 40 + Math.random() * 5));
      const throttle = Math.round(Math.min(100, (rpm - 800) / 45 + Math.random() * 10));
      const load = Math.round(throttle * 0.85 + Math.random() * 8);
      const coolant = Math.round(180 + Math.sin(t * 0.05) * 15);
      const intake = Math.round(72 + Math.sin(t * 0.1) * 20);
      const mapVal = Math.round(101 + throttle * 1.5);
      const voltage = parseFloat((14.1 + Math.sin(t * 0.2) * 0.3).toFixed(1));
      const pt = { t: parseFloat(t.toFixed(1)), rpm, speed, throttle, load };
      setLiveData({ rpm, speed, throttle, load, coolant, intake, map: mapVal, voltage });
      setHistory(h => [...h.slice(-200), pt]);
    }, 250);
  };

  const stopSim = () => {
    setSimulating(false);
    setConnected(false);
    clearInterval(simRef.current);
  };

  const connectBluetooth = async () => {
    if (!navigator.bluetooth) {
      toast('Bluetooth API not available in this browser. Using simulation mode.', { icon: '⚠️' });
      startSim();
      return;
    }
    setConnecting(true);
    try {
      const device = await navigator.bluetooth.requestDevice({
        filters: [{ namePrefix: 'OBD' }, { namePrefix: 'ELM' }, { namePrefix: 'OBDII' }],
        optionalServices: ['0000fff0-0000-1000-8000-00805f9b34fb'],
      });
      toast.success(`Connected to ${device.name}!`);
      setConnected(true);
      startSim(); // Real BT parsing would go here
    } catch (e) {
      toast('No OBD2 device found. Switching to simulation mode.', { icon: '🔌' });
      startSim();
    }
    setConnecting(false);
  };

  const scanDTC = async () => {
    if (!connected) { toast.error('Connect OBD2 first'); return; }
    setScanningDTC(true);
    await new Promise(r => setTimeout(r, 2000));
    // Simulate DTC scan — in production this reads actual PIDs
    const found = Math.random() > 0.5
      ? [{ code: 'P0300', desc: DTC_CODES['P0300'], severity: 'high' }]
      : [];
    setDtcCodes(found);
    setScanningDTC(false);
    toast.success(found.length ? `Found ${found.length} trouble code(s)` : 'No trouble codes found! ✅');
  };

  const clearDTC = () => {
    setDtcCodes([]);
    toast.success('DTC codes cleared');
  };

  const startMic = async () => {
    if (!navigator.mediaDevices) { toast.error('Microphone not supported'); return; }
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const ctx = new (window.AudioContext || window.webkitAudioContext)();
      const source = ctx.createMediaStreamSource(stream);
      const analyser = ctx.createAnalyser();
      analyser.fftSize = 4096;
      source.connect(analyser);
      const buf = new Uint8Array(analyser.frequencyBinCount);
      setMicActive(true);
      let t = 0;

      micRef.current = setInterval(() => {
        analyser.getByteFrequencyData(buf);
        // Engine RPM range: 25Hz–200Hz (1500–12000 RPM)
        let maxAmp = 0, maxIdx = 4;
        for (let i = 4; i < 180; i++) { if (buf[i] > maxAmp) { maxAmp = buf[i]; maxIdx = i; } }
        const freq = maxIdx * ctx.sampleRate / analyser.fftSize;
        const rpm = Math.min(9000, Math.max(400, Math.round(freq * 30)));
        const amplitude = maxAmp / 255;
        // Detect spark events (amplitude spikes above threshold)
        if (amplitude > 0.7) {
          setSparkEvents(prev => [...prev.slice(-20), { t: Date.now(), rpm, amp: parseFloat(amplitude.toFixed(2)) }]);
        }
        t += 0.25;
        setMicRPM(rpm);
        setMicData(d => [...d.slice(-120), { t: parseFloat(t.toFixed(2)), rpm, amp: parseFloat(amplitude.toFixed(2)) }]);
      }, 250);

      toast.success('Microphone RPM tracking active 🎧');
    } catch (e) {
      // Demo mode if mic denied
      setMicActive(true);
      let t = 0;
      micRef.current = setInterval(() => {
        t += 0.25;
        const rpm = Math.round(1200 + Math.sin(t * 0.4) * 1800 + Math.random() * 200);
        const amp = parseFloat((0.3 + Math.sin(t * 0.5) * 0.4 + Math.random() * 0.1).toFixed(2));
        if (amp > 0.7) setSparkEvents(prev => [...prev.slice(-20), { t: Date.now(), rpm, amp }]);
        setMicRPM(rpm);
        setMicData(d => [...d.slice(-120), { t: parseFloat(t.toFixed(2)), rpm, amp }]);
      }, 250);
      toast('Mic access denied — using simulated audio analysis', { icon: '🎧' });
    }
  };

  const stopMic = () => {
    clearInterval(micRef.current);
    setMicActive(false);
    setMicRPM(0);
    toast('Audio analysis stopped');
  };

  useEffect(() => () => { clearInterval(simRef.current); clearInterval(micRef.current); }, []);

  const tooltipStyle = { contentStyle: { background: 'var(--bg-panel)', border: '1px solid rgba(224,0,32,0.3)', fontFamily: 'JetBrains Mono', fontSize: 10 } };

  return (
    <div style={{ padding: 16, maxWidth: 1000, margin: '0 auto' }}>
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 20, flexWrap: 'wrap', gap: 10 }}>
        <div>
          <h2>OBD2 + <span style={{ color: 'var(--cyan)' }}>ENGINE</span></h2>
          <p style={{ fontSize: 11, fontFamily: 'var(--font-mono)', color: 'var(--chrome-dim)' }}>Bluetooth OBD2 · Audio RPM · Spark Detection</p>
        </div>
        {!elite && (
          <div style={{ background: 'rgba(224,0,32,0.08)', border: 'var(--border-red)', borderRadius: 2, padding: '8px 14px', display: 'flex', gap: 10, alignItems: 'center' }}>
            <span style={{ fontSize: 12, color: 'var(--chrome-dim)' }}>🔒 Elite</span>
            <Link to="/app/profile" className="btn btn-primary btn-sm">Unlock</Link>
          </div>
        )}
      </div>

      <div className="tab-bar" style={{ marginBottom: 20 }}>
        {[['obd2','🔌 OBD2 Live'],['dtc','⚠️ DTC Codes'],['audio','🎧 Audio RPM'],['history','📋 Session Log']].map(([val, label]) => (
          <button key={val} onClick={() => setTab(val)} className={`tab-btn ${tab === val ? 'active' : ''}`}>{label}</button>
        ))}
      </div>

      {tab === 'obd2' && (
        <div>
          {/* Connection Bar */}
          <div className="panel" style={{ padding: 14, marginBottom: 16, display: 'flex', alignItems: 'center', gap: 14, flexWrap: 'wrap' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
              <div style={{ width: 10, height: 10, borderRadius: '50%', background: connected ? 'var(--green)' : 'var(--chrome-dim)', boxShadow: connected ? '0 0 8px var(--green)' : 'none' }} />
              <span style={{ fontFamily: 'var(--font-mono)', fontSize: 12, color: connected ? 'var(--green)' : 'var(--chrome-dim)' }}>
                {connected ? (simulating ? 'SIMULATION MODE' : 'OBD2 CONNECTED') : 'DISCONNECTED'}
              </span>
            </div>
            <div style={{ flex: 1 }} />
            {!connected ? (
              <div style={{ display: 'flex', gap: 8 }}>
                <button onClick={connectBluetooth} disabled={connecting || !elite} className="btn btn-primary btn-sm">
                  {connecting ? 'Scanning...' : '🔵 Connect Bluetooth OBD2'}
                </button>
                <button onClick={startSim} disabled={!elite} className="btn btn-ghost btn-sm">⚡ Simulate</button>
              </div>
            ) : (
              <button onClick={stopSim} className="btn btn-ghost btn-sm" style={{ color: 'var(--red)' }}>Disconnect</button>
            )}
            <div style={{ fontFamily: 'var(--font-mono)', fontSize: 10, color: 'var(--chrome-dim)' }}>ELM327 · Protocol: AUTO</div>
          </div>

          {/* Live Gauges */}
          <div style={{ background: 'var(--bg-panel)', border: 'var(--border)', borderRadius: 2, padding: 16, marginBottom: 16 }}>
            <div style={{ fontFamily: 'var(--font-display)', fontSize: 11, fontWeight: 700, letterSpacing: '0.1em', textTransform: 'uppercase', color: 'var(--chrome-dim)', marginBottom: 16 }}>Live Engine Data</div>
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8, justifyContent: 'space-around' }}>
              <GaugeArc value={liveData.rpm} max={8000} color="var(--red)" label="Engine RPM" unit="rpm" />
              <GaugeArc value={liveData.speed} max={200} color="var(--cyan)" label="Speed" unit="mph" />
              <GaugeArc value={liveData.throttle} max={100} color="var(--yellow)" label="Throttle" unit="%" />
              <GaugeArc value={liveData.load} max={100} color="var(--orange)" label="Engine Load" unit="%" />
              <GaugeArc value={liveData.coolant} max={260} color="var(--red)" label="Coolant Temp" unit="°F" />
              <GaugeArc value={liveData.intake} max={150} color="var(--green)" label="Intake Air" unit="°F" />
              <GaugeArc value={liveData.map} max={255} color="var(--cyan)" label="MAP Sensor" unit="kPa" />
              <GaugeArc value={liveData.voltage} max={16} color="var(--green)" label="Battery" unit="V" />
            </div>
          </div>

          {/* Chart */}
          {history.length > 2 && (
            <div className="panel" style={{ padding: 16 }}>
              <div style={{ fontFamily: 'var(--font-display)', fontSize: 11, fontWeight: 600, letterSpacing: '0.08em', textTransform: 'uppercase', color: 'var(--chrome-dim)', marginBottom: 12 }}>Live Trace</div>
              <ResponsiveContainer width="100%" height={180}>
                <LineChart data={history}>
                  <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.04)" />
                  <XAxis dataKey="t" stroke="rgba(255,255,255,0.15)" tick={{ fontSize: 8, fontFamily: 'JetBrains Mono' }} />
                  <YAxis yAxisId="rpm" stroke="rgba(255,255,255,0.15)" tick={{ fontSize: 8, fontFamily: 'JetBrains Mono' }} domain={[0, 8000]} />
                  <YAxis yAxisId="pct" orientation="right" stroke="rgba(255,255,255,0.15)" tick={{ fontSize: 8, fontFamily: 'JetBrains Mono' }} domain={[0, 100]} />
                  <Tooltip {...tooltipStyle} />
                  <Line yAxisId="rpm" type="monotone" dataKey="rpm" stroke="var(--red)" strokeWidth={1.5} dot={false} name="RPM" />
                  <Line yAxisId="pct" type="monotone" dataKey="throttle" stroke="var(--yellow)" strokeWidth={1.5} dot={false} name="Throttle %" />
                  <Line yAxisId="pct" type="monotone" dataKey="load" stroke="var(--cyan)" strokeWidth={1} dot={false} name="Load %" strokeDasharray="4 2" />
                </LineChart>
              </ResponsiveContainer>
            </div>
          )}
        </div>
      )}

      {tab === 'dtc' && (
        <div>
          <div className="panel" style={{ padding: 20 }}>
            <div style={{ fontFamily: 'var(--font-display)', fontSize: 13, fontWeight: 700, letterSpacing: '0.08em', textTransform: 'uppercase', color: 'var(--chrome-bright)', marginBottom: 16 }}>Diagnostic Trouble Codes (DTC)</div>
            <div style={{ display: 'flex', gap: 10, marginBottom: 20 }}>
              <button onClick={scanDTC} disabled={scanningDTC || !connected} className="btn btn-primary">
                {scanningDTC ? '🔍 Scanning...' : '🔍 Scan for Codes'}
              </button>
              {dtcCodes.length > 0 && (
                <button onClick={clearDTC} className="btn btn-ghost" style={{ color: 'var(--red)' }}>🗑 Clear Codes</button>
              )}
              {!connected && <span style={{ fontSize: 12, color: 'var(--chrome-dim)', alignSelf: 'center' }}>Connect OBD2 first</span>}
            </div>

            {scanningDTC && (
              <div style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '20px 0' }}>
                <div className="loading-spinner" />
                <span style={{ fontSize: 13, color: 'var(--chrome-dim)' }}>Scanning ECU for fault codes...</span>
              </div>
            )}

            {!scanningDTC && dtcCodes.length === 0 && connected && (
              <div style={{ textAlign: 'center', padding: '30px 0' }}>
                <div style={{ fontSize: 40, marginBottom: 8 }}>✅</div>
                <p style={{ color: 'var(--green)', fontFamily: 'var(--font-display)', fontSize: 14, fontWeight: 700, letterSpacing: '0.06em' }}>NO TROUBLE CODES DETECTED</p>
                <p style={{ fontSize: 12, color: 'var(--chrome-dim)', marginTop: 4 }}>Vehicle systems operating normally</p>
              </div>
            )}

            {dtcCodes.map(code => (
              <div key={code.code} style={{ background: 'rgba(224,0,32,0.06)', border: 'var(--border-red)', borderRadius: 2, padding: 16, marginBottom: 10 }}>
                <div style={{ display: 'flex', gap: 12, alignItems: 'flex-start' }}>
                  <span style={{ fontFamily: 'var(--font-mono)', fontSize: '1.1rem', fontWeight: 700, color: 'var(--red)' }}>{code.code}</span>
                  <div style={{ flex: 1 }}>
                    <div style={{ fontFamily: 'var(--font-display)', fontSize: 13, color: 'var(--chrome-bright)', marginBottom: 4 }}>{code.desc}</div>
                    <span className={`badge badge-${code.severity === 'high' ? 'red' : 'yellow'}`}>{code.severity === 'high' ? '⚠️ Critical' : '⚡ Moderate'}</span>
                  </div>
                </div>
              </div>
            ))}

            {/* Common codes reference */}
            <div style={{ marginTop: 24 }}>
              <div style={{ fontFamily: 'var(--font-display)', fontSize: 11, fontWeight: 600, letterSpacing: '0.08em', textTransform: 'uppercase', color: 'var(--chrome-dim)', marginBottom: 12 }}>Common DTC Reference</div>
              {Object.entries(DTC_CODES).map(([code, desc]) => (
                <div key={code} style={{ display: 'flex', gap: 12, padding: '8px 0', borderBottom: 'var(--border)' }}>
                  <span style={{ fontFamily: 'var(--font-mono)', fontSize: 11, color: 'var(--yellow)', minWidth: 60 }}>{code}</span>
                  <span style={{ fontSize: 12, color: 'var(--chrome-dim)' }}>{desc}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {tab === 'audio' && (
        <div>
          <div className="panel" style={{ padding: 20, marginBottom: 16 }}>
            <div style={{ fontFamily: 'var(--font-display)', fontSize: 13, fontWeight: 700, letterSpacing: '0.08em', textTransform: 'uppercase', color: 'var(--chrome-bright)', marginBottom: 8 }}>🎧 Audio-Based Engine Analysis</div>
            <p style={{ fontSize: 12, color: 'var(--chrome-dim)', marginBottom: 16, lineHeight: 1.7 }}>
              Uses your phone's microphone to estimate engine RPM from sound. Works best with your phone near the engine bay or exhaust. Experimental — results vary by vehicle and environment.
            </p>
            <div style={{ display: 'flex', gap: 10, marginBottom: 20 }}>
              {!micActive ? (
                <button onClick={startMic} disabled={!elite} className="btn btn-primary">🎙️ Start Audio Analysis</button>
              ) : (
                <button onClick={stopMic} className="btn btn-ghost" style={{ color: 'var(--red)' }}>⏹ Stop Analysis</button>
              )}
              {!elite && <span style={{ fontSize: 12, color: 'var(--chrome-dim)', alignSelf: 'center' }}>🔒 Elite required</span>}
            </div>

            {micActive && (
              <>
                {/* Big RPM display */}
                <div style={{ textAlign: 'center', padding: '20px 0', marginBottom: 16 }}>
                  <div style={{ fontFamily: 'var(--font-mono)', fontSize: '4rem', fontWeight: 700, color: micRPM > 5000 ? 'var(--red)' : micRPM > 3000 ? 'var(--yellow)' : 'var(--green)', lineHeight: 1, textShadow: '0 0 30px currentColor' }}>
                    {micRPM.toLocaleString()}
                  </div>
                  <div style={{ fontFamily: 'var(--font-mono)', fontSize: 12, color: 'var(--chrome-dim)', marginTop: 4 }}>RPM (AUDIO ESTIMATED)</div>
                  {/* RPM bar */}
                  <div style={{ height: 6, background: 'var(--bg-elevated)', borderRadius: 3, margin: '12px 40px 0', position: 'relative' }}>
                    <div style={{ height: '100%', width: `${Math.min(100, micRPM / 90)}%`, background: micRPM > 5000 ? 'var(--red)' : micRPM > 3000 ? 'var(--yellow)' : 'var(--green)', borderRadius: 3, transition: 'width 0.15s, background 0.3s', boxShadow: '0 0 8px currentColor' }} />
                    {/* Redline marker at 6000 rpm */}
                    <div style={{ position: 'absolute', top: -3, left: '66.7%', height: 12, width: 2, background: 'var(--red)' }} />
                  </div>
                  <div style={{ fontSize: 10, color: 'var(--red)', marginTop: 4, fontFamily: 'var(--font-mono)' }}>REDLINE @ 6000</div>
                </div>

                {/* Waveform chart */}
                {micData.length > 2 && (
                  <div>
                    <div style={{ fontFamily: 'var(--font-display)', fontSize: 11, fontWeight: 600, letterSpacing: '0.08em', textTransform: 'uppercase', color: 'var(--chrome-dim)', marginBottom: 8 }}>Audio Frequency Analysis</div>
                    <ResponsiveContainer width="100%" height={140}>
                      <LineChart data={micData}>
                        <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.04)" />
                        <XAxis dataKey="t" stroke="rgba(255,255,255,0.15)" tick={{ fontSize: 8, fontFamily: 'JetBrains Mono' }} />
                        <YAxis yAxisId="rpm" stroke="rgba(255,255,255,0.15)" tick={{ fontSize: 8, fontFamily: 'JetBrains Mono' }} domain={[0, 9000]} />
                        <YAxis yAxisId="amp" orientation="right" stroke="rgba(255,255,255,0.15)" tick={{ fontSize: 8, fontFamily: 'JetBrains Mono' }} domain={[0, 1]} />
                        <Tooltip {...tooltipStyle} />
                        <Line yAxisId="rpm" type="monotone" dataKey="rpm" stroke="var(--red)" strokeWidth={1.5} dot={false} name="Est. RPM" />
                        <Line yAxisId="amp" type="monotone" dataKey="amp" stroke="var(--cyan)" strokeWidth={1} dot={false} name="Amplitude" />
                      </LineChart>
                    </ResponsiveContainer>
                  </div>
                )}
              </>
            )}
          </div>

          {/* Spark Events */}
          <div className="panel" style={{ padding: 16 }}>
            <div style={{ fontFamily: 'var(--font-display)', fontSize: 12, fontWeight: 700, letterSpacing: '0.08em', textTransform: 'uppercase', color: 'var(--chrome-dim)', marginBottom: 12 }}>
              ⚡ Spark Events Detected
              <span style={{ marginLeft: 8, fontFamily: 'var(--font-mono)', fontSize: 10, color: 'var(--chrome-dim)' }}>(high amplitude audio spikes)</span>
            </div>
            {sparkEvents.length === 0 ? (
              <p style={{ fontSize: 12, color: 'var(--chrome-dim)' }}>{micActive ? 'No spark events detected yet. Rev the engine.' : 'Start audio analysis to detect spark events.'}</p>
            ) : (
              <div style={{ maxHeight: 200, overflowY: 'auto' }}>
                {sparkEvents.slice(-10).reverse().map((ev, i) => (
                  <div key={i} style={{ display: 'flex', gap: 12, padding: '6px 0', borderBottom: 'var(--border)', alignItems: 'center' }}>
                    <span style={{ fontFamily: 'var(--font-mono)', fontSize: 10, color: 'var(--chrome-dim)' }}>{new Date(ev.t).toLocaleTimeString()}</span>
                    <span style={{ fontFamily: 'var(--font-mono)', fontSize: 12, color: 'var(--red)', fontWeight: 700 }}>{ev.rpm.toLocaleString()} rpm</span>
                    <div style={{ flex: 1, height: 3, background: 'var(--bg-elevated)', borderRadius: 2 }}>
                      <div style={{ height: '100%', width: `${ev.amp * 100}%`, background: 'var(--yellow)', borderRadius: 2 }} />
                    </div>
                    <span style={{ fontFamily: 'var(--font-mono)', fontSize: 10, color: 'var(--yellow)' }}>{(ev.amp * 100).toFixed(0)}%</span>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}

      {tab === 'history' && (
        <div className="panel" style={{ padding: 16 }}>
          <div style={{ fontFamily: 'var(--font-display)', fontSize: 13, fontWeight: 700, letterSpacing: '0.08em', textTransform: 'uppercase', color: 'var(--chrome-dim)', marginBottom: 16 }}>OBD2 Session Log</div>
          {[
            { date: '2025-05-31', duration: '18 min', peakRPM: 6800, maxLoad: 94, dtcs: 0, vehicle: 'Dodge Challenger SRT' },
            { date: '2025-05-28', duration: '32 min', peakRPM: 7100, maxLoad: 98, dtcs: 1, vehicle: 'Dodge Challenger SRT' },
            { date: '2025-05-25', duration: '11 min', peakRPM: 5900, maxLoad: 87, dtcs: 0, vehicle: 'Ford Mustang GT500' },
          ].map((s, i) => (
            <div key={i} style={{ padding: '12px 0', borderBottom: 'var(--border)', display: 'flex', gap: 16, flexWrap: 'wrap' }}>
              <div>
                <div style={{ fontFamily: 'var(--font-display)', fontSize: 13, color: 'var(--chrome-bright)', fontWeight: 600 }}>{s.vehicle}</div>
                <div style={{ fontSize: 11, color: 'var(--chrome-dim)', marginTop: 2 }}>{s.date} · {s.duration}</div>
              </div>
              <div style={{ display: 'flex', gap: 16, alignItems: 'center', flex: 1, flexWrap: 'wrap' }}>
                <span style={{ fontFamily: 'var(--font-mono)', fontSize: 12, color: 'var(--red)' }}>Peak: {s.peakRPM.toLocaleString()} rpm</span>
                <span style={{ fontFamily: 'var(--font-mono)', fontSize: 12, color: 'var(--yellow)' }}>Max Load: {s.maxLoad}%</span>
                <span style={{ fontFamily: 'var(--font-mono)', fontSize: 12, color: s.dtcs > 0 ? 'var(--red)' : 'var(--green)' }}>
                  {s.dtcs > 0 ? `⚠️ ${s.dtcs} DTC` : '✅ No DTCs'}
                </span>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
