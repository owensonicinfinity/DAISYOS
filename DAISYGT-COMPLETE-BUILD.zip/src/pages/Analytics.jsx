import React, { useState, useEffect } from 'react';
import { LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, RadarChart, Radar, PolarGrid, PolarAngleAxis } from 'recharts';
import { api } from '../services/api';
import { useAuthStore } from '../store/authStore';

export default function Analytics() {
  const { user, isElite } = useAuthStore();
  const [stats, setStats] = useState(null);
  const [telemetry, setTelemetry] = useState([]);
  const [tab, setTab] = useState('overview');

  // Demo chart data
  const speedHistory = [
    { date: 'May 25', top: 142, avg: 78 },
    { date: 'May 26', top: 155, avg: 82 },
    { date: 'May 27', top: 149, avg: 80 },
    { date: 'May 28', top: 162, avg: 85 },
    { date: 'May 29', top: 158, avg: 83 },
    { date: 'May 30', top: 171, avg: 88 },
    { date: 'May 31', top: 165, avg: 86 },
    { date: 'Jun 1', top: 178, avg: 91 },
  ];

  const quarterHistory = [
    { date: 'May 25', time: 12.4 },
    { date: 'May 26', time: 11.8 },
    { date: 'May 28', time: 11.5 },
    { date: 'May 29', time: 11.2 },
    { date: 'May 30', time: 10.9 },
    { date: 'Jun 1', time: 10.8 },
  ];

  const radarData = [
    { metric: 'Speed', value: 85 },
    { metric: 'Acceleration', value: 72 },
    { metric: 'Cornering', value: 68 },
    { metric: 'Braking', value: 79 },
    { metric: 'Launch', value: 81 },
    { metric: 'Consistency', value: 77 },
  ];

  const racesByType = [
    { type: 'Sprint', count: 24 },
    { type: 'Mile', count: 12 },
    { type: 'Circuit', count: 8 },
    { type: 'Top Speed', count: 15 },
    { type: 'Slalom', count: 5 },
  ];

  const gForceHistory = Array.from({ length: 20 }, (_, i) => ({
    t: i * 0.5,
    lateral: parseFloat((Math.sin(i * 0.6) * 0.8 + Math.random() * 0.2).toFixed(2)),
    longitudinal: parseFloat((Math.cos(i * 0.4) * 0.6 + Math.random() * 0.15).toFixed(2)),
  }));

  useEffect(() => {
    if (user?.id) {
      api.profile.getStats(user.id).then(setStats);
      api.telemetry.getHistory(user.id).then(setTelemetry);
    }
  }, [user]);

  const tooltipStyle = { contentStyle: { background: 'var(--bg-panel)', border: '1px solid rgba(224,0,32,0.3)', fontFamily: 'JetBrains Mono', fontSize: 11, color: 'var(--chrome)' } };

  return (
    <div style={{ padding: 16, maxWidth: 1000, margin: '0 auto' }}>
      <h2 style={{ marginBottom: 16 }}>RACE <span style={{ color: 'var(--red)' }}>ANALYTICS</span></h2>

      <div className="tab-bar" style={{ marginBottom: 20 }}>
        {[['overview','Overview'],['speed','Speed Trends'],['gforce','G-Force'],['comparisons','Comparisons']].map(([val, label]) => (
          <button key={val} onClick={() => setTab(val)} className={`tab-btn ${tab === val ? 'active' : ''}`}>{label}</button>
        ))}
      </div>

      {tab === 'overview' && (
        <>
          {/* Summary Cards */}
          <div className="grid-4" style={{ marginBottom: 20 }}>
            {[
              { label: 'Total Races', value: stats?.totalRaces || 64, color: 'var(--red)' },
              { label: 'Win Rate', value: `${stats?.winRate || 73}%`, color: 'var(--green)' },
              { label: 'Best Speed', value: `${Math.round(stats?.bestSpeed || 178)} mph`, color: 'var(--cyan)' },
              { label: 'Best ¼ Mile', value: '10.8s', color: 'var(--yellow)' },
            ].map(s => (
              <div key={s.label} className="panel" style={{ padding: 16, textAlign: 'center' }}>
                <div style={{ fontFamily: 'var(--font-mono)', fontSize: 9, letterSpacing: '0.12em', textTransform: 'uppercase', color: 'var(--chrome-dim)', marginBottom: 8 }}>{s.label}</div>
                <div style={{ fontFamily: 'var(--font-mono)', fontSize: '1.8rem', fontWeight: 700, color: s.color }}>{s.value}</div>
              </div>
            ))}
          </div>

          {/* Speed History Chart */}
          <div className="panel" style={{ padding: 16, marginBottom: 16 }}>
            <div style={{ fontFamily: 'var(--font-display)', fontSize: 12, fontWeight: 600, letterSpacing: '0.08em', textTransform: 'uppercase', color: 'var(--chrome-dim)', marginBottom: 16 }}>Speed Trends — Last 8 Sessions</div>
            <ResponsiveContainer width="100%" height={200}>
              <LineChart data={speedHistory}>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.04)" />
                <XAxis dataKey="date" stroke="rgba(255,255,255,0.2)" tick={{ fontSize: 9, fontFamily: 'JetBrains Mono' }} />
                <YAxis stroke="rgba(255,255,255,0.2)" tick={{ fontSize: 9, fontFamily: 'JetBrains Mono' }} />
                <Tooltip {...tooltipStyle} />
                <Line type="monotone" dataKey="top" stroke="var(--red)" strokeWidth={2} dot={{ fill: 'var(--red)', r: 3 }} name="Top Speed" />
                <Line type="monotone" dataKey="avg" stroke="var(--cyan)" strokeWidth={2} dot={{ fill: 'var(--cyan)', r: 3 }} name="Avg Speed" strokeDasharray="5 5" />
              </LineChart>
            </ResponsiveContainer>
          </div>

          {/* Two columns */}
          <div className="grid-2" style={{ gap: 16 }}>
            {/* Quarter Mile Improvement */}
            <div className="panel" style={{ padding: 16 }}>
              <div style={{ fontFamily: 'var(--font-display)', fontSize: 12, fontWeight: 600, letterSpacing: '0.08em', textTransform: 'uppercase', color: 'var(--chrome-dim)', marginBottom: 16 }}>¼ Mile Progress</div>
              <ResponsiveContainer width="100%" height={150}>
                <LineChart data={quarterHistory}>
                  <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.04)" />
                  <XAxis dataKey="date" stroke="rgba(255,255,255,0.2)" tick={{ fontSize: 8, fontFamily: 'JetBrains Mono' }} />
                  <YAxis domain={[9.5, 13]} stroke="rgba(255,255,255,0.2)" tick={{ fontSize: 8, fontFamily: 'JetBrains Mono' }} />
                  <Tooltip {...tooltipStyle} />
                  <Line type="monotone" dataKey="time" stroke="var(--yellow)" strokeWidth={2} dot={{ fill: 'var(--yellow)', r: 3 }} name="Time (s)" />
                </LineChart>
              </ResponsiveContainer>
              <p style={{ fontSize: 11, color: 'var(--green)', textAlign: 'center', marginTop: 8, fontFamily: 'var(--font-mono)' }}>▲ Improved 1.6s in 6 sessions</p>
            </div>

            {/* Races by Type */}
            <div className="panel" style={{ padding: 16 }}>
              <div style={{ fontFamily: 'var(--font-display)', fontSize: 12, fontWeight: 600, letterSpacing: '0.08em', textTransform: 'uppercase', color: 'var(--chrome-dim)', marginBottom: 16 }}>Races by Type</div>
              <ResponsiveContainer width="100%" height={150}>
                <BarChart data={racesByType} barSize={20}>
                  <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.04)" />
                  <XAxis dataKey="type" stroke="rgba(255,255,255,0.2)" tick={{ fontSize: 8, fontFamily: 'JetBrains Mono' }} />
                  <YAxis stroke="rgba(255,255,255,0.2)" tick={{ fontSize: 8, fontFamily: 'JetBrains Mono' }} />
                  <Tooltip {...tooltipStyle} />
                  <Bar dataKey="count" fill="var(--red)" name="Races" radius={[2, 2, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>
        </>
      )}

      {tab === 'speed' && (
        <div>
          <div className="panel" style={{ padding: 16, marginBottom: 16 }}>
            <div style={{ fontFamily: 'var(--font-display)', fontSize: 12, fontWeight: 600, letterSpacing: '0.08em', textTransform: 'uppercase', color: 'var(--chrome-dim)', marginBottom: 16 }}>Full Speed History</div>
            <ResponsiveContainer width="100%" height={280}>
              <LineChart data={speedHistory}>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.04)" />
                <XAxis dataKey="date" stroke="rgba(255,255,255,0.2)" tick={{ fontSize: 9, fontFamily: 'JetBrains Mono' }} />
                <YAxis stroke="rgba(255,255,255,0.2)" tick={{ fontSize: 9, fontFamily: 'JetBrains Mono' }} label={{ value: 'mph', angle: -90, position: 'insideLeft', fill: 'rgba(255,255,255,0.3)', fontSize: 10 }} />
                <Tooltip {...tooltipStyle} />
                <Line type="monotone" dataKey="top" stroke="var(--red)" strokeWidth={2.5} dot={{ fill: 'var(--red)', r: 4 }} name="Top Speed (mph)" />
                <Line type="monotone" dataKey="avg" stroke="var(--cyan)" strokeWidth={2} strokeDasharray="6 3" dot={{ fill: 'var(--cyan)', r: 3 }} name="Avg Speed (mph)" />
              </LineChart>
            </ResponsiveContainer>
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 12 }}>
            {[{ label: 'All-Time Top Speed', value: '178 mph', detail: 'Jun 1 · Ford Mustang' }, { label: 'Avg Top Speed', value: '160 mph', detail: 'Across all sessions' }, { label: 'Top Speed Trend', value: '+12%', detail: 'vs last month', color: 'var(--green)' }].map(s => (
              <div key={s.label} className="panel" style={{ padding: 16, textAlign: 'center' }}>
                <div style={{ fontFamily: 'var(--font-mono)', fontSize: 9, letterSpacing: '0.1em', textTransform: 'uppercase', color: 'var(--chrome-dim)', marginBottom: 8 }}>{s.label}</div>
                <div style={{ fontFamily: 'var(--font-mono)', fontSize: '1.6rem', fontWeight: 700, color: s.color || 'var(--red)' }}>{s.value}</div>
                <div style={{ fontSize: 11, color: 'var(--chrome-dim)', marginTop: 4 }}>{s.detail}</div>
              </div>
            ))}
          </div>
        </div>
      )}

      {tab === 'gforce' && (
        <div>
          <div className="panel" style={{ padding: 16, marginBottom: 16 }}>
            <div style={{ fontFamily: 'var(--font-display)', fontSize: 12, fontWeight: 600, letterSpacing: '0.08em', textTransform: 'uppercase', color: 'var(--chrome-dim)', marginBottom: 16 }}>G-Force Recording — Last Run</div>
            <ResponsiveContainer width="100%" height={220}>
              <LineChart data={gForceHistory}>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.04)" />
                <XAxis dataKey="t" stroke="rgba(255,255,255,0.2)" tick={{ fontSize: 9, fontFamily: 'JetBrains Mono' }} label={{ value: 'seconds', position: 'insideBottom', offset: -3, fontSize: 9, fill: 'rgba(255,255,255,0.3)' }} />
                <YAxis stroke="rgba(255,255,255,0.2)" tick={{ fontSize: 9, fontFamily: 'JetBrains Mono' }} label={{ value: 'g', angle: -90, position: 'insideLeft', fill: 'rgba(255,255,255,0.3)', fontSize: 10 }} domain={[-1.2, 1.2]} />
                <Tooltip {...tooltipStyle} />
                <Line type="monotone" dataKey="lateral" stroke="var(--cyan)" strokeWidth={2} dot={false} name="Lateral G" />
                <Line type="monotone" dataKey="longitudinal" stroke="var(--yellow)" strokeWidth={2} dot={false} name="Longitudinal G" />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>
      )}

      {tab === 'comparisons' && (
        <div className="grid-2" style={{ gap: 16 }}>
          <div className="panel" style={{ padding: 16 }}>
            <div style={{ fontFamily: 'var(--font-display)', fontSize: 12, fontWeight: 600, letterSpacing: '0.08em', textTransform: 'uppercase', color: 'var(--chrome-dim)', marginBottom: 16 }}>Performance Radar</div>
            <ResponsiveContainer width="100%" height={250}>
              <RadarChart data={radarData}>
                <PolarGrid stroke="rgba(255,255,255,0.08)" />
                <PolarAngleAxis dataKey="metric" tick={{ fill: 'rgba(255,255,255,0.4)', fontSize: 11, fontFamily: 'JetBrains Mono' }} />
                <Radar name="You" dataKey="value" stroke="var(--red)" fill="var(--red)" fillOpacity={0.15} strokeWidth={2} />
              </RadarChart>
            </ResponsiveContainer>
          </div>
          <div className="panel" style={{ padding: 16 }}>
            <div style={{ fontFamily: 'var(--font-display)', fontSize: 12, fontWeight: 600, letterSpacing: '0.08em', textTransform: 'uppercase', color: 'var(--chrome-dim)', marginBottom: 16 }}>vs Platform Average</div>
            {radarData.map(m => (
              <div key={m.metric} style={{ marginBottom: 12 }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 4 }}>
                  <span style={{ fontFamily: 'var(--font-mono)', fontSize: 11, color: 'var(--chrome)' }}>{m.metric}</span>
                  <span style={{ fontFamily: 'var(--font-mono)', fontSize: 11, color: m.value >= 75 ? 'var(--green)' : m.value >= 60 ? 'var(--yellow)' : 'var(--red)' }}>{m.value}/100</span>
                </div>
                <div style={{ height: 4, background: 'var(--bg-elevated)', borderRadius: 2, position: 'relative' }}>
                  <div style={{ height: '100%', width: `${m.value}%`, background: 'var(--red)', borderRadius: 2 }} />
                  {/* Platform average marker at 65 */}
                  <div style={{ position: 'absolute', top: -2, left: '65%', height: 8, width: 2, background: 'var(--chrome-dim)' }} />
                </div>
                <div style={{ fontSize: 9, color: 'var(--chrome-dim)', marginTop: 2, fontFamily: 'var(--font-mono)' }}>Platform avg: 65</div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
