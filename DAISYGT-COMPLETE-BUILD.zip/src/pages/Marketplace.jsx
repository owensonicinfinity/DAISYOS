import React, { useState, useEffect } from 'react';
import { api } from '../services/api';
import { useAuthStore } from '../store/authStore';
import toast from 'react-hot-toast';

const MOCK_LISTINGS = [
  { id: 'nft1', title: '10.8s Quarter Mile — TurboQueen', description: 'Verified 10.8-second quarter mile run. Full telemetry + front cam POV included. Personal best record.', price: 24.99, owner: 'TurboQueen', avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=queen', type: 'quarter_mile', topSpeed: 162, raceDate: '2025-05-30', views: 847, bids: 12, rarity: 'Legendary' },
  { id: 'nft2', title: '212 MPH Top Speed Run', description: 'Highest verified speed on the DaisyGT platform. GPS authenticated. Both front and rear camera angles.', price: 149.99, owner: 'RocketMike', avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=mike', type: 'top_speed', topSpeed: 212, raceDate: '2025-05-28', views: 3241, bids: 44, rarity: 'Mythic' },
  { id: 'nft3', title: 'Ghost Race Comeback Victory', description: 'Down 0.8s at the halfway mark, won by 0.2s. Full race replay with ghost overlay data.', price: 12.99, owner: 'GhostRider_X', avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=ghost', type: 'race', topSpeed: 148, raceDate: '2025-05-29', views: 412, bids: 7, rarity: 'Rare' },
  { id: 'nft4', title: 'Club Championship Race Pack', description: 'Full 12-racer club event. All POVs, all telemetry, race master data bundle.', price: 39.99, owner: 'DaisyRacer', avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=daisy', type: 'bundle', topSpeed: 155, raceDate: '2025-05-27', views: 1089, bids: 21, rarity: 'Epic' },
  { id: 'nft5', title: 'Boat vs Car vs Motorcycle — Multi-Class', description: 'Rare multi-class race featuring boat, car, and motorcycle. Unique GPS paths synchronized.', price: 89.99, owner: 'NightRunner', avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=night', type: 'multi', topSpeed: 98, raceDate: '2025-05-26', views: 2187, bids: 33, rarity: 'Epic' },
  { id: 'nft6', title: 'Perfect Launch Data Pack', description: '0-60 in 2.9s. Full launch telemetry: G-force curve, throttle position, wheel spin detection.', price: 8.99, owner: 'V8_Demon', avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=v8', type: 'dyno', topSpeed: 185, raceDate: '2025-05-31', views: 567, bids: 9, rarity: 'Uncommon' },
];

const RARITY_COLORS = { Mythic: 'var(--red)', Legendary: 'var(--yellow)', Epic: 'var(--cyan)', Rare: '#9f7aea', Uncommon: 'var(--green)' };

export default function Marketplace() {
  const { user } = useAuthStore();
  const [listings, setListings] = useState(MOCK_LISTINGS);
  const [filter, setFilter] = useState('all');
  const [sort, setSort] = useState('newest');
  const [selected, setSelected] = useState(null);
  const [tab, setTab] = useState('buy'); // buy | sell | owned

  const filters = ['all','quarter_mile','top_speed','race','bundle','dyno'];

  const filtered = listings.filter(l => filter === 'all' || l.type === filter)
    .sort((a, b) => sort === 'price_asc' ? a.price - b.price : sort === 'price_desc' ? b.price - a.price : sort === 'popular' ? b.views - a.views : b.bids - a.bids);

  const handlePurchase = (listing) => {
    toast.success(`🎉 You purchased "${listing.title}" for $${listing.price}!\n\nRace data and POV footage are now in your collection.`);
    setSelected(null);
  };

  return (
    <div style={{ padding: 16, maxWidth: 1000, margin: '0 auto' }}>
      <div style={{ marginBottom: 20 }}>
        <h2>RACE <span style={{ color: 'var(--cyan)' }}>MARKETPLACE</span></h2>
        <p style={{ fontSize: 12, color: 'var(--chrome-dim)', marginTop: 4 }}>Buy and collect verified race records, telemetry data, and POV footage as digital race assets.</p>
      </div>

      <div className="tab-bar" style={{ marginBottom: 16 }}>
        {[['buy','Buy Collectibles'],['sell','Sell My Race'],['owned','My Collection']].map(([val, label]) => (
          <button key={val} onClick={() => setTab(val)} className={`tab-btn ${tab === val ? 'active' : ''}`}>{label}</button>
        ))}
      </div>

      {tab === 'buy' && (
        <>
          {/* Filters */}
          <div style={{ display: 'flex', gap: 8, marginBottom: 16, flexWrap: 'wrap', alignItems: 'center' }}>
            <div style={{ display: 'flex', gap: 4, flex: 1, flexWrap: 'wrap' }}>
              {filters.map(f => (
                <button key={f} onClick={() => setFilter(f)} className={`badge ${filter === f ? 'badge-red' : ''}`}
                  style={{ cursor: 'pointer', background: filter !== f ? 'var(--bg-surface)' : undefined, border: filter !== f ? 'var(--border)' : undefined, color: filter !== f ? 'var(--chrome-dim)' : undefined, padding: '6px 12px' }}>
                  {f === 'all' ? 'All' : f.replace('_', ' ')}
                </button>
              ))}
            </div>
            <select value={sort} onChange={e => setSort(e.target.value)} style={{ width: 'auto', padding: '6px 10px', fontSize: 12 }}>
              <option value="popular">Most Popular</option>
              <option value="price_asc">Price: Low → High</option>
              <option value="price_desc">Price: High → Low</option>
              <option value="newest">Newest</option>
            </select>
          </div>

          {/* Listings Grid */}
          <div className="grid-3" style={{ gap: 14 }}>
            {filtered.map(listing => (
              <div key={listing.id} className="card" onClick={() => setSelected(listing)} style={{ cursor: 'pointer' }}>
                {/* Rarity Banner */}
                <div style={{ background: `${RARITY_COLORS[listing.rarity]}20`, border: `1px solid ${RARITY_COLORS[listing.rarity]}`, borderRadius: 1, padding: '3px 8px', display: 'inline-block', marginBottom: 10 }}>
                  <span style={{ fontFamily: 'var(--font-mono)', fontSize: 9, fontWeight: 700, letterSpacing: '0.1em', textTransform: 'uppercase', color: RARITY_COLORS[listing.rarity] }}>{listing.rarity}</span>
                </div>
                <div style={{ fontFamily: 'var(--font-display)', fontSize: 13, fontWeight: 700, letterSpacing: '0.04em', color: 'var(--chrome-bright)', marginBottom: 6, textTransform: 'uppercase', lineHeight: 1.3 }}>{listing.title}</div>
                <p style={{ fontSize: 12, color: 'var(--chrome-dim)', lineHeight: 1.5, marginBottom: 12 }}>{listing.description.slice(0, 80)}...</p>
                <div style={{ display: 'flex', gap: 8, marginBottom: 12 }}>
                  <span style={{ fontFamily: 'var(--font-mono)', fontSize: 10, color: 'var(--chrome-dim)' }}>🔥 {listing.views} views</span>
                  <span style={{ fontFamily: 'var(--font-mono)', fontSize: 10, color: 'var(--chrome-dim)' }}>💬 {listing.bids} bids</span>
                </div>
                <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                    <img src={listing.avatar} alt="" style={{ width: 20, height: 20, borderRadius: '50%' }} />
                    <span style={{ fontSize: 11, color: 'var(--chrome-dim)' }}>{listing.owner}</span>
                  </div>
                  <div style={{ fontFamily: 'var(--font-mono)', fontSize: '1rem', fontWeight: 700, color: 'var(--cyan)' }}>${listing.price}</div>
                </div>
              </div>
            ))}
          </div>
        </>
      )}

      {tab === 'sell' && (
        <div className="panel" style={{ padding: 24, maxWidth: 500 }}>
          <div style={{ fontFamily: 'var(--font-display)', fontSize: 14, fontWeight: 700, letterSpacing: '0.08em', textTransform: 'uppercase', color: 'var(--chrome-bright)', marginBottom: 20 }}>Mint Your Race as a Collectible</div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
            <div><label>Select Race</label><select><option>2025-05-30 — 162 mph run</option><option>2025-05-28 — Quarter mile 11.2s</option></select></div>
            <div><label>Listing Title</label><input placeholder="My Personal Best Quarter Mile" /></div>
            <div><label>Description</label><textarea rows={3} placeholder="Describe this race, conditions, vehicle..." style={{ resize: 'none' }} /></div>
            <div className="grid-2"><div><label>Price ($)</label><input type="number" placeholder="9.99" /></div><div><label>Include</label><select><option>Front cam + telemetry</option><option>All cameras + full data</option><option>Telemetry only</option></select></div></div>
            <div style={{ background: 'rgba(0,229,255,0.05)', border: '1px solid rgba(0,229,255,0.2)', borderRadius: 2, padding: 12, fontSize: 12, color: 'var(--chrome-dim)', lineHeight: 1.6 }}>
              ⚡ <strong style={{ color: 'var(--cyan)' }}>How it works:</strong> Your race data is cryptographically verified and listed as a digital collectible. Buyers receive permanent access to the race data, POV footage, and telemetry. DaisyGT takes 5% on each sale.
            </div>
            <button className="btn btn-cyan" style={{ justifyContent: 'center' }}>💎 Mint Race Collectible</button>
          </div>
        </div>
      )}

      {tab === 'owned' && (
        <div style={{ textAlign: 'center', padding: '60px 20px', color: 'var(--chrome-dim)' }}>
          <div style={{ fontSize: 48, marginBottom: 12 }}>💎</div>
          <h3 style={{ marginBottom: 8, color: 'var(--chrome-dim)' }}>Your Collection</h3>
          <p style={{ fontSize: 13 }}>Race collectibles you've purchased will appear here. Start collecting today!</p>
          <button onClick={() => setTab('buy')} className="btn btn-primary" style={{ marginTop: 20 }}>Browse Marketplace</button>
        </div>
      )}

      {/* Detail Modal */}
      {selected && (
        <div style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.85)', zIndex: 500, display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 16 }}>
          <div style={{ background: 'var(--bg-panel)', border: `1px solid ${RARITY_COLORS[selected.rarity]}`, borderRadius: 2, padding: 24, width: '100%', maxWidth: 480, maxHeight: '85vh', overflowY: 'auto' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 16 }}>
              <span className="badge" style={{ background: `${RARITY_COLORS[selected.rarity]}20`, border: `1px solid ${RARITY_COLORS[selected.rarity]}`, color: RARITY_COLORS[selected.rarity] }}>{selected.rarity}</span>
              <button onClick={() => setSelected(null)} style={{ background: 'none', border: 'none', color: 'var(--chrome-dim)', cursor: 'pointer', fontSize: 20 }}>×</button>
            </div>
            <h3 style={{ fontSize: '1.1rem', marginBottom: 8, color: 'var(--chrome-bright)', textTransform: 'uppercase' }}>{selected.title}</h3>
            <p style={{ fontSize: 13, color: 'var(--chrome-dim)', marginBottom: 16, lineHeight: 1.7 }}>{selected.description}</p>
            <div className="grid-3" style={{ gap: 8, marginBottom: 16 }}>
              <div className="stat-box" style={{ background: 'var(--bg-surface)', padding: 10 }}><div className="stat-label">Top Speed</div><div style={{ fontFamily: 'var(--font-mono)', fontSize: '1.2rem', fontWeight: 700, color: 'var(--red)' }}>{selected.topSpeed}</div><div className="stat-unit">mph</div></div>
              <div className="stat-box" style={{ background: 'var(--bg-surface)', padding: 10 }}><div className="stat-label">Views</div><div style={{ fontFamily: 'var(--font-mono)', fontSize: '1.2rem', fontWeight: 700, color: 'var(--cyan)' }}>{selected.views}</div></div>
              <div className="stat-box" style={{ background: 'var(--bg-surface)', padding: 10 }}><div className="stat-label">Bids</div><div style={{ fontFamily: 'var(--font-mono)', fontSize: '1.2rem', fontWeight: 700, color: 'var(--yellow)' }}>{selected.bids}</div></div>
            </div>
            <div style={{ fontFamily: 'var(--font-mono)', fontSize: '1.8rem', fontWeight: 700, color: 'var(--cyan)', textAlign: 'center', marginBottom: 16 }}>${selected.price}</div>
            <div style={{ display: 'flex', gap: 10 }}>
              <button onClick={() => handlePurchase(selected)} className="btn btn-cyan btn-lg" style={{ flex: 1, justifyContent: 'center' }}>💎 Purchase Now</button>
              <button className="btn btn-ghost">Place Bid</button>
            </div>
            <p style={{ fontSize: 10, color: 'rgba(255,255,255,0.25)', textAlign: 'center', marginTop: 12 }}>Digital race asset. All sales final. Not financial advice. Not gambling.</p>
          </div>
        </div>
      )}
    </div>
  );
}
