import React, { useState, useEffect, useRef } from 'react';
import { tourAPI } from '../services/api';
import { Link } from 'react-router-dom';

// Pure CSS world map with dot overlays — no external map dependency
const WORLD_W = 800;
const WORLD_H = 400;

function latLngToXY(lat, lng) {
  const x = ((lng + 180) / 360) * WORLD_W;
  const y = ((90 - lat) / 180) * WORLD_H;
  return { x, y };
}

const RACE_TYPE_COLORS = {
  sprint: 'var(--red)',
  circuit: 'var(--cyan)',
  top_speed: 'var(--yellow)',
  slalom: 'var(--green)',
  endurance: 'var(--orange)',
};

export default function WorldTour() {
  const [locations, setLocations] = useState([]);
  const [selected, setSelected] = useState(null);
  const [tab, setTab] = useState('map');
  const [totalSpectators] = useState(Math.floor(Math.random() * 50000 + 100000));
  const [pulsePhase, setPulsePhase] = useState(0);

  useEffect(() => {
    tourAPI.getLiveRaceLocations().then(setLocations);
    const pulse = setInterval(() => setPulsePhase(p => (p + 1) % 60), 50);
    return () => clearInterval(pulse);
  }, []);

  const totalRacers = locations.reduce((s, l) => s + l.racers, 0);

  return (
    <div style={{ padding: 16, maxWidth: 1000, margin: '0 auto' }}>
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 20, flexWrap: 'wrap', gap: 10 }}>
        <div>
          <h2>WORLD <span style={{ color: 'var(--red)' }}>TOUR MAP</span></h2>
          <p style={{ fontSize: 11, fontFamily: 'var(--font-mono)', color: 'var(--chrome-dim)' }}>Live races happening right now across the globe</p>
        </div>
        <div style={{ display: 'flex', gap: 16 }}>
          <div className="stat-box" style={{ textAlign: 'right' }}>
            <div className="stat-label">Live Racers</div>
            <div style={{ fontFamily: 'var(--font-mono)', fontSize: '1.3rem', fontWeight: 700, color: 'var(--red)' }}>{totalRacers}</div>
          </div>
          <div className="stat-box" style={{ textAlign: 'right' }}>
            <div className="stat-label">Spectators</div>
            <div style={{ fontFamily: 'var(--font-mono)', fontSize: '1.3rem', fontWeight: 700, color: 'var(--cyan)' }}>{totalSpectators.toLocaleString()}</div>
          </div>
        </div>
      </div>

      <div className="tab-bar" style={{ marginBottom: 16 }}>
        {[['map','🌍 World Map'],['list','📋 Race List'],['stats','📊 Global Stats']].map(([val, label]) => (
          <button key={val} onClick={() => setTab(val)} className={`tab-btn ${tab === val ? 'active' : ''}`}>{label}</button>
        ))}
      </div>

      {tab === 'map' && (
        <div>
          {/* SVG World Map */}
          <div className="panel" style={{ padding: 0, overflow: 'hidden', position: 'relative', marginBottom: 16 }}>
            <div style={{ position: 'relative', width: '100%', paddingBottom: '50%', background: 'var(--bg-void)' }}>
              <svg
                viewBox={`0 0 ${WORLD_W} ${WORLD_H}`}
                style={{ position: 'absolute', inset: 0, width: '100%', height: '100%' }}
              >
                {/* Grid lines */}
                <defs>
                  <pattern id="grid" width="40" height="40" patternUnits="userSpaceOnUse">
                    <path d="M 40 0 L 0 0 0 40" fill="none" stroke="rgba(255,255,255,0.03)" strokeWidth="0.5" />
                  </pattern>
                  <radialGradient id="pulseGrad" cx="50%" cy="50%" r="50%">
                    <stop offset="0%" stopColor="var(--red)" stopOpacity="0.6" />
                    <stop offset="100%" stopColor="var(--red)" stopOpacity="0" />
                  </radialGradient>
                </defs>
                <rect width={WORLD_W} height={WORLD_H} fill="url(#grid)" />

                {/* Equator & Prime Meridian */}
                <line x1="0" y1={WORLD_H / 2} x2={WORLD_W} y2={WORLD_H / 2} stroke="rgba(255,255,255,0.05)" strokeWidth="1" />
                <line x1={WORLD_W / 2} y1="0" x2={WORLD_W / 2} y2={WORLD_H} stroke="rgba(255,255,255,0.05)" strokeWidth="1" />

                {/* Continent outlines (simplified SVG paths) */}
                {/* North America */}
                <path d="M 95 60 L 240 60 L 240 200 L 160 220 L 130 200 L 95 160 Z" fill="rgba(255,255,255,0.04)" stroke="rgba(255,255,255,0.08)" strokeWidth="0.5" />
                {/* South America */}
                <path d="M 170 220 L 230 220 L 230 360 L 180 370 L 155 320 L 160 260 Z" fill="rgba(255,255,255,0.04)" stroke="rgba(255,255,255,0.08)" strokeWidth="0.5" />
                {/* Europe */}
                <path d="M 380 50 L 460 50 L 470 120 L 420 130 L 380 110 Z" fill="rgba(255,255,255,0.04)" stroke="rgba(255,255,255,0.08)" strokeWidth="0.5" />
                {/* Africa */}
                <path d="M 390 130 L 460 130 L 470 280 L 420 310 L 380 280 L 380 160 Z" fill="rgba(255,255,255,0.04)" stroke="rgba(255,255,255,0.08)" strokeWidth="0.5" />
                {/* Asia */}
                <path d="M 460 50 L 700 50 L 720 180 L 600 200 L 500 180 L 460 130 Z" fill="rgba(255,255,255,0.04)" stroke="rgba(255,255,255,0.08)" strokeWidth="0.5" />
                {/* Australia */}
                <path d="M 620 260 L 720 260 L 730 340 L 650 350 L 610 310 Z" fill="rgba(255,255,255,0.04)" stroke="rgba(255,255,255,0.08)" strokeWidth="0.5" />

                {/* Race Location Dots */}
                {locations.map((loc) => {
                  const { x, y } = latLngToXY(loc.lat, loc.lng);
                  const color = RACE_TYPE_COLORS[loc.type] || 'var(--red)';
                  const pulseR = 8 + Math.sin(pulsePhase * 0.2 + loc.lat) * 4;
                  const isSelected = selected?.id === loc.id;
                  return (
                    <g key={loc.id} onClick={() => setSelected(isSelected ? null : loc)} style={{ cursor: 'pointer' }}>
                      {/* Pulse ring */}
                      <circle cx={x} cy={y} r={pulseR} fill="none" stroke={color} strokeWidth="1" opacity={0.3} />
                      {/* Core dot */}
                      <circle
                        cx={x} cy={y} r={isSelected ? 7 : 5}
                        fill={color}
                        stroke={isSelected ? 'white' : 'rgba(0,0,0,0.5)'}
                        strokeWidth={isSelected ? 2 : 1}
                        style={{ filter: `drop-shadow(0 0 6px ${color})` }}
                      />
                      {/* Racer count badge */}
                      <text x={x + 7} y={y - 6} fontSize="7" fill={color} fontFamily="JetBrains Mono" fontWeight="700">
                        {loc.racers}
                      </text>
                    </g>
                  );
                })}
              </svg>

              {/* Legend */}
              <div style={{ position: 'absolute', bottom: 8, left: 8, display: 'flex', gap: 8, flexWrap: 'wrap' }}>
                {Object.entries(RACE_TYPE_COLORS).map(([type, color]) => (
                  <div key={type} style={{ display: 'flex', alignItems: 'center', gap: 4 }}>
                    <div style={{ width: 8, height: 8, borderRadius: '50%', background: color, boxShadow: `0 0 4px ${color}` }} />
                    <span style={{ fontFamily: 'var(--font-mono)', fontSize: 8, color: 'rgba(200,205,216,0.6)', textTransform: 'uppercase' }}>{type}</span>
                  </div>
                ))}
              </div>

              {/* Live indicator */}
              <div style={{ position: 'absolute', top: 8, right: 8, display: 'flex', alignItems: 'center', gap: 6, background: 'rgba(10,10,12,0.8)', padding: '4px 10px', borderRadius: 2, border: '1px solid rgba(224,0,32,0.3)' }}>
                <span className="live-dot" style={{ width: 6, height: 6 }} />
                <span style={{ fontFamily: 'var(--font-mono)', fontSize: 9, color: 'var(--red)', letterSpacing: '0.1em' }}>LIVE WORLDWIDE</span>
              </div>
            </div>
          </div>

          {/* Selected Location Detail */}
          {selected && (
            <div className="panel" style={{ padding: 16, marginBottom: 16, border: `1px solid ${RACE_TYPE_COLORS[selected.type]}` }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
                <div>
                  <div style={{ fontFamily: 'var(--font-display)', fontSize: '1.1rem', fontWeight: 700, letterSpacing: '0.06em', color: 'var(--chrome-bright)', textTransform: 'uppercase', marginBottom: 4 }}>{selected.city}</div>
                  <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
                    <span className="live-dot" />
                    <span style={{ fontFamily: 'var(--font-mono)', fontSize: 12, color: 'var(--red)' }}>{selected.racers} racers live</span>
                    <span className={`badge badge-cyan`}>{selected.type}</span>
                  </div>
                  <div style={{ fontFamily: 'var(--font-mono)', fontSize: 10, color: 'var(--chrome-dim)', marginTop: 8 }}>
                    {selected.lat.toFixed(4)}°N · {selected.lng.toFixed(4)}°
                  </div>
                </div>
                <div style={{ display: 'flex', gap: 8 }}>
                  <Link to={`/spectator/${selected.id}`} className="btn btn-cyan btn-sm">👁️ Watch Live</Link>
                  <button onClick={() => setSelected(null)} style={{ background: 'none', border: 'none', color: 'var(--chrome-dim)', cursor: 'pointer', fontSize: 18 }}>×</button>
                </div>
              </div>
            </div>
          )}

          {/* Location grid */}
          <div className="grid-3" style={{ gap: 10 }}>
            {locations.map(loc => (
              <button key={loc.id} onClick={() => setSelected(loc)}
                style={{ background: selected?.id === loc.id ? 'rgba(224,0,32,0.08)' : 'var(--bg-panel)', border: selected?.id === loc.id ? 'var(--border-red)' : 'var(--border)', borderRadius: 2, padding: '10px 12px', cursor: 'pointer', textAlign: 'left', transition: 'all 0.15s' }}>
                <div style={{ fontFamily: 'var(--font-display)', fontSize: 12, fontWeight: 700, color: 'var(--chrome)', letterSpacing: '0.04em', textTransform: 'uppercase', marginBottom: 4 }}>{loc.city}</div>
                <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                  <div style={{ width: 6, height: 6, borderRadius: '50%', background: RACE_TYPE_COLORS[loc.type], boxShadow: `0 0 4px ${RACE_TYPE_COLORS[loc.type]}` }} />
                  <span style={{ fontFamily: 'var(--font-mono)', fontSize: 10, color: 'var(--chrome-dim)' }}>{loc.racers} racers · {loc.type}</span>
                </div>
              </button>
            ))}
          </div>
        </div>
      )}

      {tab === 'list' && (
        <div className="panel" style={{ padding: 16 }}>
          <div style={{ fontFamily: 'var(--font-display)', fontSize: 13, fontWeight: 700, letterSpacing: '0.08em', textTransform: 'uppercase', color: 'var(--chrome-dim)', marginBottom: 16 }}>All Live Races</div>
          {locations.sort((a, b) => b.racers - a.racers).map((loc, i) => (
            <div key={loc.id} style={{ display: 'flex', alignItems: 'center', gap: 14, padding: '12px 0', borderBottom: 'var(--border)' }}>
              <span style={{ fontFamily: 'var(--font-mono)', fontSize: 11, color: 'var(--chrome-dim)', width: 24, textAlign: 'right' }}>{i + 1}</span>
              <div style={{ flex: 1 }}>
                <div style={{ fontFamily: 'var(--font-display)', fontSize: 14, fontWeight: 700, color: 'var(--chrome-bright)', letterSpacing: '0.04em' }}>{loc.city}</div>
                <div style={{ fontFamily: 'var(--font-mono)', fontSize: 10, color: 'var(--chrome-dim)', marginTop: 2 }}>{loc.lat.toFixed(2)}°, {loc.lng.toFixed(2)}°</div>
              </div>
              <span className={`badge badge-${loc.type === 'circuit' ? 'cyan' : loc.type === 'top_speed' ? 'yellow' : 'red'}`}>{loc.type}</span>
              <div style={{ textAlign: 'right' }}>
                <div style={{ fontFamily: 'var(--font-mono)', fontSize: 14, fontWeight: 700, color: 'var(--red)' }}>{loc.racers}</div>
                <div style={{ fontFamily: 'var(--font-mono)', fontSize: 9, color: 'var(--chrome-dim)' }}>racers</div>
              </div>
              <Link to={`/spectator/${loc.id}`} className="btn btn-cyan btn-sm">Watch</Link>
            </div>
          ))}
        </div>
      )}

      {tab === 'stats' && (
        <div className="grid-2" style={{ gap: 16 }}>
          <div className="panel" style={{ padding: 16 }}>
            <div style={{ fontFamily: 'var(--font-display)', fontSize: 12, fontWeight: 700, letterSpacing: '0.08em', textTransform: 'uppercase', color: 'var(--chrome-dim)', marginBottom: 16 }}>Races by Type</div>
            {Object.entries(RACE_TYPE_COLORS).map(([type, color]) => {
              const count = locations.filter(l => l.type === type).length;
              return (
                <div key={type} style={{ marginBottom: 12 }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 4 }}>
                    <span style={{ fontFamily: 'var(--font-mono)', fontSize: 11, color, textTransform: 'uppercase', letterSpacing: '0.06em' }}>{type}</span>
                    <span style={{ fontFamily: 'var(--font-mono)', fontSize: 11, color: 'var(--chrome-dim)' }}>{count} events</span>
                  </div>
                  <div style={{ height: 4, background: 'var(--bg-elevated)', borderRadius: 2 }}>
                    <div style={{ height: '100%', width: `${(count / locations.length) * 100}%`, background: color, borderRadius: 2, boxShadow: `0 0 6px ${color}` }} />
                  </div>
                </div>
              );
            })}
          </div>

          <div className="panel" style={{ padding: 16 }}>
            <div style={{ fontFamily: 'var(--font-display)', fontSize: 12, fontWeight: 700, letterSpacing: '0.08em', textTransform: 'uppercase', color: 'var(--chrome-dim)', marginBottom: 16 }}>Global Platform Stats</div>
            {[
              { label: 'Active Countries', value: '94', color: 'var(--red)' },
              { label: 'Races This Week', value: '26,847', color: 'var(--cyan)' },
              { label: 'Total Racers', value: '48,291', color: 'var(--yellow)' },
              { label: 'Live Spectators', value: totalSpectators.toLocaleString(), color: 'var(--green)' },
              { label: 'Race NFTs Minted', value: '3,412', color: 'var(--orange)' },
              { label: 'Clubs Active', value: '1,847', color: 'var(--chrome)' },
            ].map(s => (
              <div key={s.label} style={{ display: 'flex', justifyContent: 'space-between', padding: '8px 0', borderBottom: 'var(--border)' }}>
                <span style={{ fontSize: 12, color: 'var(--chrome-dim)' }}>{s.label}</span>
                <span style={{ fontFamily: 'var(--font-mono)', fontSize: 13, fontWeight: 700, color: s.color }}>{s.value}</span>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
