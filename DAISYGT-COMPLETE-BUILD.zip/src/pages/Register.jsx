import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { api, seedDemoData } from '../services/api';
import { useAuthStore } from '../store/authStore';
import toast from 'react-hot-toast';

const VEHICLE_TYPES = ['Car', 'Motorcycle', 'Truck', 'Boat', 'Aircraft', 'ATV/UTV', 'Scooter', 'Other'];

export default function Register() {
  const [form, setForm] = useState({ username: '', email: '', password: '', vehicle: 'Car' });
  const [loading, setLoading] = useState(false);
  const { login, activateTrial } = useAuthStore();
  const navigate = useNavigate();

  seedDemoData();

  const set = (field, val) => setForm(f => ({ ...f, [field]: val }));

  const handleSubmit = async () => {
    if (!form.username || !form.email || !form.password) { toast.error('Fill in all fields'); return; }
    if (form.password.length < 6) { toast.error('Password must be 6+ characters'); return; }
    setLoading(true);
    try {
      const { user, token } = await api.auth.register(form);
      login(user, token);
      // Auto-activate trial for new users
      activateTrial('DAISYGT-FREE-2025');
      toast.success(`Welcome to Daisy GT, ${user.username}! 2-week Elite trial activated! 🏁`);
      navigate('/app');
    } catch (e) {
      toast.error(e.message);
    }
    setLoading(false);
  };

  return (
    <div style={{ minHeight: '100vh', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', padding: 24, position: 'relative', zIndex: 1 }}>
      <Link to="/" style={{ position: 'fixed', top: 20, left: 20, color: 'var(--chrome-dim)', textDecoration: 'none', fontFamily: 'var(--font-display)', fontSize: 12, letterSpacing: '0.06em', textTransform: 'uppercase' }}>← Back</Link>

      <div style={{ width: '100%', maxWidth: 420 }}>
        <div style={{ textAlign: 'center', marginBottom: 36 }}>
          <div style={{ fontFamily: 'var(--font-display)', fontSize: '2rem', fontWeight: 700, letterSpacing: '0.1em' }}>
            <span style={{ color: 'var(--chrome-bright)' }}>DAISY</span><span style={{ color: 'var(--red)' }}>GT</span>
          </div>
          <p style={{ fontSize: 13, color: 'var(--chrome-dim)', marginTop: 4 }}>Create your racing account</p>
          <div style={{ marginTop: 10, background: 'rgba(0,229,255,0.06)', border: '1px solid rgba(0,229,255,0.2)', borderRadius: 2, padding: '6px 16px', display: 'inline-block' }}>
            <span style={{ fontFamily: 'var(--font-mono)', fontSize: 11, color: 'var(--cyan)' }}>⚡ Free 2-week Elite trial included</span>
          </div>
        </div>

        <div className="panel" style={{ padding: 24 }}>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
            <div>
              <label>Race Name / Username</label>
              <input value={form.username} onChange={e => set('username', e.target.value)} placeholder="TurboRacer99" />
            </div>
            <div>
              <label>Email</label>
              <input type="email" value={form.email} onChange={e => set('email', e.target.value)} placeholder="you@example.com" />
            </div>
            <div>
              <label>Password</label>
              <input type="password" value={form.password} onChange={e => set('password', e.target.value)} placeholder="Min 6 characters" onKeyDown={e => e.key === 'Enter' && handleSubmit()} />
            </div>
            <div>
              <label>Primary Vehicle Type</label>
              <select value={form.vehicle} onChange={e => set('vehicle', e.target.value)}>
                {VEHICLE_TYPES.map(v => <option key={v}>{v}</option>)}
              </select>
            </div>

            <button onClick={handleSubmit} disabled={loading} className="btn btn-primary" style={{ width: '100%', justifyContent: 'center', marginTop: 4 }}>
              {loading ? 'Creating account...' : '🏁 Start Racing Free'}
            </button>
          </div>

          <p style={{ fontSize: 10, color: 'rgba(255,255,255,0.3)', textAlign: 'center', marginTop: 16, lineHeight: 1.6 }}>
            By creating an account you agree to racing responsibly and legally. Daisy GT is for entertainment and tracking purposes only. Race only on private property or designated tracks.
          </p>

          <p style={{ textAlign: 'center', fontSize: 12, color: 'var(--chrome-dim)', marginTop: 16 }}>
            Have an account? <Link to="/login" style={{ color: 'var(--red)', textDecoration: 'none' }}>Sign in →</Link>
          </p>
        </div>
      </div>
    </div>
  );
}
