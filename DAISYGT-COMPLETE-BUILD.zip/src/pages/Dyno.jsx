import React, { useState, useEffect, useRef } from 'react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { useAuthStore } from '../store/authStore';
import { onTelemetryUpdate, startSimulation, stopSimulation } from '../services/gps';
import { api } from '../services/api';
import { analyzeRaceTelemetry } from '../services/gemini';
import toast from 'react-hot-toast';
import { Link } from 'react-router-dom';

export default function Dyno() {
  const { user, isElite } = useAuthStore();
  const elite = isElite();
  const [running, setRunning] = useState(false);
  const [mode, setMode] = useState('quarter'); // quarter | halfmile | mile | topspeed | slalom
  const [data, setData] = useState({ speed: 0, gForce: 0, altitude: 0, heading: 0, distance: 0, rpm: 600, throttle: 0 });
  const [history, setHistory] = useState([]);
  const [sessions, setSessions] = useState([]);
  const [milestone, setMilestone] = useState({});
  const [aiAnalysis, setAiAnalysis] = useState('');
  const [elapsed, setElapsed] = useState(0);
  const [micRPM, setMicRPM] = useState(null);
  const startRef = useRef(null);
  const timerRef = useRef(null);
  const peaksRef = useRef({ topSpeed: 0, maxG: 0, dist: 0 });

  useEffect(() => {
    if (user?.id) api.telemetry.getHistory(user.id).then(setSessions);
  }, [user]);

  const startDyno = () => {
    if (!elite) { toast.error('Upgrade to Elite to use the Dyno! 🔒'); return; }
    setRunning(true);
    setHistory([]);
    setMilestone({});
    setAiAnalysis('');
    peaksRef.current = { topSpeed: 0, maxG: 0, dist: 0 };
    startRef.current = Date.now();

    timerRef.current = setInterval(() => setElapsed(Math.floor((Date.now() - startRef.current) / 1000)), 1000);

    const cleanup = onTelemetryUpdate((d) => {
      const elapsed = (Date.now() - startRef.current) / 1000;
      const dist = peaksRef.current.dist + (d.speed * 0.5 / 3600);
      peaksRef.current.dist = dist;
      if (d.speed > peaksRef.current.topSpeed) peaksRef.current.topSpeed = d.speed;
      if ((d.gForce || 0) > peaksRef.current.maxG) peaksRef.current.maxG = d.gForce || 0;

      setData({ speed: d.speed, gForce: d.gForce || 0, altitude: d.altitude || 0, heading: d.heading || 0, distance: dist, rpm: 600 + d.speed * 30 + Math.random() * 200, throttle: Math.min(100, d.speed * 1.2) });

      const point = { t: parseFloat(elapsed.toFixed(1)), speed: Math.round(d.speed), gForce: parseFloat((d.gForce || 0).toFixed(2)), dist: parseFloat(dist.toFixed(4)) };
      setHistory(h => [...h.slice(-300), point]);

      // Milestones
      setMilestone(prev => {
        const m = { ...prev };
        if (!m.sixty && d.speed >= 60) m.sixty = elapsed;
        if (!m.eighth && dist >= 0.125) m.eighth = elapsed;
        if (!m.quarter && dist >= 0.25) m.quarter = elapsed;
        if (!m.half && dist >= 0.5) m.half = elapsed;
        if (!m.mile && dist >= 1.0) m.mile = elapsed;
        return m;
      });
    });

    startSimulation();
    timerRef.current.cleanup = cleanup;
  };

  const stopDyno = async () => {
    setRunning(false);
    stopSimulation();
    if (timerRef.current) { clearInterval(timerRef.current); timerRef.current.cleanup?.(); }

    const result = { userId: user?.id, topSpeed: peaksRef.current.topSpeed, maxG: peaksRef.current.maxG, distance: peaksRef.current.dist, elapsed, ...milestone };
    await api.telemetry.save(result);
    toast.success('Dyno session saved! 📊');

    try {
      const analysis = await analyzeRaceTelemetry({ ...result, mode, dataPoints: history.length });
      setAiAnalysis(analysis);
    } catch { /* silent */ }
  };

  const formatT = (s) => s ? `${s.toFixed(2)}s` : '—';
  const formatTime = (s) => `${String(Math.floor(s / 60)).padStart(2,'0')}:${String(s % 60).padStart(2,'0')}`;

  return (
    <div style={{ padding: 16, maxWidth: 1000, margin: '0 auto' }}>
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 20, flexWrap: 'wrap', gap: 10 }}>
        <div>
          <h2>DAISY <span style={{ color: 'var(--cyan)' }}>DYNO</span></h2>
          <p style={{ fontSize: 11, color: 'var(--chrome-dim)', fontFamily: 'var(--font-mono)' }}>Professional Telemetry — DDG System</p>
        </div>
        {!elite && (
          <div style={{ background: 'rgba(224,0,32,0.08)', border: 'var(--border-red)', borderRadius: 2, padding: '10px 16px', display: 'flex', alignItems: 'center', gap: 12 }}>
            <span style={{ fontSize: 12, color: 'var(--chrome-dim)' }}>🔒 Elite feature</span>
            <Link to="/app/profile" className="btn btn-primary btn-sm">Unlock $4.99</Link>
          </div>
        )}
      </div>

      {/* ─── Mode Select ─── */}
      <div className="tab-bar" style={{ marginBottom: 16 }}>
        {[['quarter','¼ Mile'],['halfmile','½ Mile'],['mile','Full Mile'],['topspeed','Top Speed'],['slalom','Slalom'],['launch','Launch']].map(([val, label]) => (
          <button key={val} onClick={() => setMode(val)} className={`tab-btn ${mode === val ? 'active' : ''}`}>{label}</button>
        ))}
      </div>

      {/* ─── Live Gauges ─── */}
      <div className="grid-4" style={{ marginBottom: 16 }}>
        {[
          { label: 'Speed', value: Math.round(data.speed), unit: 'MPH', color: 'var(--red)' },
          { label: 'G-Force', value: data.gForce.toFixed(2), unit: 'g', color: 'var(--cyan)' },
          { label: 'Simulated RPM', value: Math.round(data.rpm), unit: 'rpm', color: 'var(--yellow)' },
          { label: 'Distance', value: data.distance.toFixed(3), unit: 'mi', color: 'var(--green)' },
        ].map(g => (
          <div key={g.label} style={{ background: 'var(--bg-panel)', border: `1px solid ${running ? g.color.replace(')', ', 0.4)').replace('var(', 'rgba(').replace('--red', '224,0,32').replace('--cyan', '0,229,255').replace('--yellow', '255,204,0').replace('--green', '0,255,136') : 'rgba(255,255,255,0.06)'}`, borderRadius: 2, padding: 14, textAlign: 'center', transition: 'border-color 0.3s' }}>
            <div style={{ fontFamily: 'var(--font-mono)', fontSize: 9, letterSpacing: '0.12em', textTransform: 'uppercase', color: 'var(--chrome-dim)', marginBottom: 6 }}>{g.label}</div>
            <div style={{ fontFamily: 'var(--font-mono)', fontSize: '2rem', fontWeight: 700, color: running ? g.color : 'var(--chrome-dim)', lineHeight: 1, transition: 'color 0.3s' }}>{g.value}</div>
            <div style={{ fontFamily: 'var(--font-mono)', fontSize: 10, color: 'var(--chrome-dim)', marginTop: 4 }}>{g.unit}</div>
          </div>
        ))}
      </div>

      {/* ─── Milestones ─── */}
      <div className="panel" style={{ padding: 14, marginBottom: 16 }}>
        <div style={{ fontFamily: 'var(--font-display)', fontSize: 11, fontWeight: 700, letterSpacing: '0.1em', textTransform: 'uppercase', color: 'var(--chrome-dim)', marginBottom: 12 }}>Performance Milestones</div>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(100px, 1fr))', gap: 10 }}>
          {[
            { label: '0–60 mph', val: milestone.sixty },
            { label: '⅛ Mile', val: milestone.eighth },
            { label: '¼ Mile', val: milestone.quarter },
            { label: '½ Mile', val: milestone.half },
            { label: '1 Mile', val: milestone.mile },
            { label: 'Top Speed', val: peaksRef.current.topSpeed ? `${Math.round(peaksRef.current.topSpeed)} mph` : null, noSuffix: true },
            { label: 'Max G', val: peaksRef.current.maxG ? `${peaksRef.current.maxG.toFixed(2)}g` : null, noSuffix: true },
            { label: 'Session', val: running ? formatTime(elapsed) : '—', noSuffix: true },
          ].map(m => (
            <div key={m.label} style={{ background: m.val ? 'rgba(224,0,32,0.06)' : 'var(--bg-surface)', border: m.val ? 'var(--border-red)' : 'var(--border)', borderRadius: 2, padding: '10px 8px', textAlign: 'center' }}>
              <div style={{ fontFamily: 'var(--font-mono)', fontSize: 8, letterSpacing: '0.1em', textTransform: 'uppercase', color: 'var(--chrome-dim)', marginBottom: 4 }}>{m.label}</div>
              <div style={{ fontFamily: 'var(--font-mono)', fontSize: '1rem', fontWeight: 700, color: m.val ? 'var(--red)' : 'var(--bg-elevated)' }}>
                {m.val ? (m.noSuffix ? m.val : formatT(m.val)) : '——'}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* ─── Speed Chart ─── */}
      {history.length > 1 && (
        <div className="panel" style={{ padding: 16, marginBottom: 16 }}>
          <div style={{ fontFamily: 'var(--font-display)', fontSize: 11, fontWeight: 600, letterSpacing: '0.08em', textTransform: 'uppercase', color: 'var(--chrome-dim)', marginBottom: 12 }}>Speed Curve</div>
          <ResponsiveContainer width="100%" height={160}>
            <LineChart data={history}>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.04)" />
              <XAxis dataKey="t" stroke="rgba(255,255,255,0.2)" tick={{ fontSize: 9, fontFamily: 'JetBrains Mono' }} label={{ value: 'seconds', position: 'insideBottom', offset: -2, fontSize: 9, fill: 'rgba(255,255,255,0.3)' }} />
              <YAxis stroke="rgba(255,255,255,0.2)" tick={{ fontSize: 9, fontFamily: 'JetBrains Mono' }} />
              <Tooltip contentStyle={{ background: 'var(--bg-panel)', border: '1px solid rgba(224,0,32,0.3)', fontFamily: 'JetBrains Mono', fontSize: 11 }} />
              <Line type="monotone" dataKey="speed" stroke="var(--red)" strokeWidth={2} dot={false} name="MPH" />
              <Line type="monotone" dataKey="gForce" stroke="var(--cyan)" strokeWidth={1.5} dot={false} name="G-Force" />
            </LineChart>
          </ResponsiveContainer>
        </div>
      )}

      {/* ─── Controls ─── */}
      <div style={{ display: 'flex', gap: 10, marginBottom: 16 }}>
        {!running ? (
          <button onClick={startDyno} className="btn btn-primary btn-lg" style={{ flex: 1, justifyContent: 'center' }} disabled={!elite}>
            📊 {elite ? 'START DYNO RUN' : '🔒 Elite Required'}
          </button>
        ) : (
          <button onClick={stopDyno} className="btn btn-ghost btn-lg" style={{ flex: 1, justifyContent: 'center', borderColor: 'var(--red)', color: 'var(--red)' }}>
            ⏹ STOP & SAVE SESSION
          </button>
        )}
      </div>

      {/* ─── AI Analysis ─── */}
      {aiAnalysis && (
        <div style={{ background: 'rgba(0,229,255,0.05)', border: '1px solid rgba(0,229,255,0.2)', borderRadius: 2, padding: 16, marginBottom: 16 }}>
          <div style={{ fontFamily: 'var(--font-display)', fontSize: 11, fontWeight: 600, letterSpacing: '0.08em', textTransform: 'uppercase', color: 'var(--cyan)', marginBottom: 8 }}>⚡ DaisyAI Dyno Analysis</div>
          <p style={{ fontSize: 13, lineHeight: 1.7, color: 'var(--chrome)' }}>{aiAnalysis}</p>
        </div>
      )}

      {/* ─── Session History ─── */}
      {sessions.length > 0 && (
        <div className="panel" style={{ padding: 16 }}>
          <div style={{ fontFamily: 'var(--font-display)', fontSize: 11, fontWeight: 600, letterSpacing: '0.08em', textTransform: 'uppercase', color: 'var(--chrome-dim)', marginBottom: 12 }}>Previous Sessions</div>
          {sessions.slice(0, 5).map((s, i) => (
            <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '10px 0', borderBottom: 'var(--border)' }}>
              <span style={{ fontFamily: 'var(--font-mono)', fontSize: 10, color: 'var(--chrome-dim)' }}>{new Date(s.createdAt).toLocaleDateString()}</span>
              <span style={{ fontFamily: 'var(--font-mono)', fontSize: 12, color: 'var(--red)' }}>{Math.round(s.topSpeed || 0)} mph top</span>
              {s.quarter && <span style={{ fontFamily: 'var(--font-mono)', fontSize: 12, color: 'var(--cyan)' }}>¼mi: {formatT(s.quarter)}</span>}
              {s.sixty && <span style={{ fontFamily: 'var(--font-mono)', fontSize: 12, color: 'var(--yellow)' }}>0-60: {formatT(s.sixty)}</span>}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
