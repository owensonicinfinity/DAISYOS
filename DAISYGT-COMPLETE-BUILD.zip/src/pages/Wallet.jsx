import React, { useState, useEffect } from 'react';
import { disputeAPI, walletAPI } from '../services/api';
import { useAuthStore } from '../store/authStore';
import toast from 'react-hot-toast';

export default function Wallet() {
  const { user } = useAuthStore();
  const [tab, setTab] = useState('wallet');
  const [wallet, setWallet] = useState(null);
  const [disputes, setDisputes] = useState([]);
  const [disputeForm, setDisputeForm] = useState({ reportedUsername: '', raceId: '', amount: '', description: '', evidence: '' });
  const [showDisputeForm, setShowDisputeForm] = useState(false);
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    if (user?.id) {
      walletAPI.getWallet(user.id).then(setWallet);
      disputeAPI.getAll(user.id).then(setDisputes);
    }
  }, [user]);

  const setD = (k, v) => setDisputeForm(f => ({ ...f, [k]: v }));

  const fileDispute = async () => {
    if (!disputeForm.reportedUsername || !disputeForm.description) { toast.error('Fill in required fields'); return; }
    setSubmitting(true);
    await disputeAPI.file({ ...disputeForm, reporterId: user.id, createdAt: new Date().toISOString() });
    const updated = await disputeAPI.getAll(user.id);
    setDisputes(updated);
    setShowDisputeForm(false);
    setDisputeForm({ reportedUsername: '', raceId: '', amount: '', description: '', evidence: '' });
    toast.success('Dispute filed. Review team will respond within 48 hours.');
    setSubmitting(false);
  };

  const mockTransactions = [
    { id: 'tx1', type: 'credit', amount: 12.99, label: 'Race NFT Sale — Ghost Comeback', timestamp: '2025-05-30T18:22:00Z' },
    { id: 'tx2', type: 'debit', amount: 24.99, label: 'Purchased: 10.8s Quarter Mile NFT', timestamp: '2025-05-28T14:10:00Z' },
    { id: 'tx3', type: 'credit', amount: 4.99, label: 'Elite Upgrade Refund', timestamp: '2025-05-25T09:00:00Z' },
  ];

  return (
    <div style={{ padding: 16, maxWidth: 900, margin: '0 auto' }}>
      <h2 style={{ marginBottom: 20 }}>WALLET & <span style={{ color: 'var(--cyan)' }}>DISPUTES</span></h2>

      <div className="tab-bar" style={{ marginBottom: 20 }}>
        {[['wallet','💎 Wallet'],['disputes','⚖️ Disputes'],['agreements','🤝 Race Agreements']].map(([val, label]) => (
          <button key={val} onClick={() => setTab(val)} className={`tab-btn ${tab === val ? 'active' : ''}`}>{label}</button>
        ))}
      </div>

      {tab === 'wallet' && (
        <div>
          {/* Balance Card */}
          <div className="panel" style={{ padding: 24, marginBottom: 16 }}>
            <div style={{ fontFamily: 'var(--font-display)', fontSize: 12, fontWeight: 600, letterSpacing: '0.1em', textTransform: 'uppercase', color: 'var(--chrome-dim)', marginBottom: 8 }}>DaisyOS Wallet</div>
            <div style={{ fontFamily: 'var(--font-mono)', fontSize: '2.5rem', fontWeight: 700, color: 'var(--cyan)', marginBottom: 4 }}>
              ${mockTransactions.reduce((s, t) => s + (t.type === 'credit' ? t.amount : -t.amount), 0).toFixed(2)}
            </div>
            <div style={{ fontFamily: 'var(--font-mono)', fontSize: 10, color: 'var(--chrome-dim)', marginBottom: 20 }}>
              {wallet?.address ? `${wallet.address.slice(0, 10)}...${wallet.address.slice(-6)}` : 'Generating wallet...'}
            </div>
            <div style={{ display: 'flex', gap: 10 }}>
              <button className="btn btn-primary btn-sm" onClick={() => toast('Coming soon — connect external wallet like MetaMask')}>💳 Add Funds</button>
              <button className="btn btn-ghost btn-sm" onClick={() => toast('Withdrawals sent via PayPal or Cash App — contact support')}>↑ Withdraw</button>
              <button className="btn btn-cyan btn-sm" onClick={() => { navigator.clipboard?.writeText(wallet?.address || ''); toast.success('Address copied!'); }}>📋 Copy Address</button>
            </div>
          </div>

          {/* Transactions */}
          <div className="panel" style={{ padding: 16 }}>
            <div style={{ fontFamily: 'var(--font-display)', fontSize: 12, fontWeight: 700, letterSpacing: '0.08em', textTransform: 'uppercase', color: 'var(--chrome-dim)', marginBottom: 14 }}>Transaction History</div>
            {mockTransactions.map(tx => (
              <div key={tx.id} style={{ display: 'flex', alignItems: 'center', gap: 14, padding: '12px 0', borderBottom: 'var(--border)' }}>
                <div style={{ width: 36, height: 36, borderRadius: '50%', background: tx.type === 'credit' ? 'rgba(0,255,136,0.1)' : 'rgba(224,0,32,0.1)', border: `1px solid ${tx.type === 'credit' ? 'rgba(0,255,136,0.3)' : 'rgba(224,0,32,0.3)'}`, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 16 }}>
                  {tx.type === 'credit' ? '↓' : '↑'}
                </div>
                <div style={{ flex: 1 }}>
                  <div style={{ fontSize: 13, color: 'var(--chrome)', marginBottom: 2 }}>{tx.label}</div>
                  <div style={{ fontFamily: 'var(--font-mono)', fontSize: 10, color: 'var(--chrome-dim)' }}>{new Date(tx.timestamp).toLocaleString()}</div>
                </div>
                <div style={{ fontFamily: 'var(--font-mono)', fontSize: '1.1rem', fontWeight: 700, color: tx.type === 'credit' ? 'var(--green)' : 'var(--red)' }}>
                  {tx.type === 'credit' ? '+' : '-'}${tx.amount.toFixed(2)}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {tab === 'disputes' && (
        <div>
          <div style={{ background: 'rgba(255,204,0,0.05)', border: '1px solid rgba(255,204,0,0.2)', borderRadius: 2, padding: '10px 14px', marginBottom: 16, fontSize: 12, color: 'var(--yellow)', lineHeight: 1.7 }}>
            ⚖️ <strong>Dispute System:</strong> Use this to report unpaid race agreements. Daisy GT tracks dispute history and flags repeat offenders. Repeat violations result in suspension. All agreements are private — Daisy GT does not facilitate betting or gambling.
          </div>

          <div style={{ display: 'flex', justifyContent: 'flex-end', marginBottom: 16 }}>
            <button onClick={() => setShowDisputeForm(true)} className="btn btn-primary">+ File Dispute</button>
          </div>

          {disputes.length === 0 ? (
            <div style={{ textAlign: 'center', padding: '40px 20px', color: 'var(--chrome-dim)' }}>
              <div style={{ fontSize: 40, marginBottom: 12 }}>⚖️</div>
              <p>No disputes filed. Keep racing clean!</p>
            </div>
          ) : (
            <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
              {disputes.map((d, i) => (
                <div key={i} className="panel" style={{ padding: 16 }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 8 }}>
                    <span className={`badge badge-${d.status === 'resolved' ? 'green' : 'yellow'}`}>{d.status?.toUpperCase()}</span>
                    <span style={{ fontFamily: 'var(--font-mono)', fontSize: 10, color: 'var(--chrome-dim)' }}>{new Date(d.createdAt).toLocaleDateString()}</span>
                  </div>
                  <div style={{ fontSize: 13, color: 'var(--chrome)', marginBottom: 4 }}><strong>Against:</strong> {d.reportedUsername}</div>
                  {d.amount && <div style={{ fontFamily: 'var(--font-mono)', fontSize: 12, color: 'var(--red)', marginBottom: 4 }}>Amount: ${d.amount}</div>}
                  <p style={{ fontSize: 12, color: 'var(--chrome-dim)', lineHeight: 1.6 }}>{d.description}</p>
                  {d.resolution && <div style={{ marginTop: 8, padding: '8px 10px', background: 'rgba(0,255,136,0.05)', border: '1px solid rgba(0,255,136,0.2)', borderRadius: 2, fontSize: 12, color: 'var(--green)' }}>Resolution: {d.resolution}</div>}
                </div>
              ))}
            </div>
          )}

          {/* Reputation system */}
          <div className="panel" style={{ padding: 16, marginTop: 16 }}>
            <div style={{ fontFamily: 'var(--font-display)', fontSize: 12, fontWeight: 700, letterSpacing: '0.08em', textTransform: 'uppercase', color: 'var(--chrome-dim)', marginBottom: 12 }}>Reputation System</div>
            <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 12 }}>
              <div style={{ fontFamily: 'var(--font-mono)', fontSize: '2rem', fontWeight: 700, color: 'var(--green)' }}>98</div>
              <div>
                <div style={{ fontFamily: 'var(--font-display)', fontSize: 13, fontWeight: 700, color: 'var(--green)', letterSpacing: '0.04em' }}>EXCELLENT STANDING</div>
                <div style={{ fontSize: 11, color: 'var(--chrome-dim)' }}>0 disputes filed against you · 0 warnings</div>
              </div>
            </div>
            <div style={{ height: 6, background: 'var(--bg-elevated)', borderRadius: 3 }}>
              <div style={{ height: '100%', width: '98%', background: 'var(--green)', borderRadius: 3, boxShadow: '0 0 8px var(--green)' }} />
            </div>
          </div>
        </div>
      )}

      {tab === 'agreements' && (
        <div>
          <div style={{ background: 'rgba(0,229,255,0.04)', border: '1px solid rgba(0,229,255,0.2)', borderRadius: 2, padding: '12px 16px', marginBottom: 16, fontSize: 12, color: 'var(--cyan)', lineHeight: 1.7 }}>
            🤝 <strong>Race Agreements:</strong> Log your private race arrangements here. The app tracks the result and agreement for your records. All payments are made externally (Cash App, Venmo, PayPal). Daisy GT does not process payments or facilitate gambling.
          </div>

          <div className="panel" style={{ padding: 20 }}>
            <div style={{ fontFamily: 'var(--font-display)', fontSize: 13, fontWeight: 700, letterSpacing: '0.08em', textTransform: 'uppercase', color: 'var(--chrome-bright)', marginBottom: 16 }}>Log a Race Agreement</div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
              <div className="grid-2">
                <div><label>Opponent Username</label><input placeholder="GhostRider_X" /></div>
                <div><label>Race Type</label><select><option>Quarter Mile</option><option>Half Mile</option><option>Full Mile</option><option>Top Speed</option><option>Other</option></select></div>
              </div>
              <div className="grid-2">
                <div><label>Race Date</label><input type="date" /></div>
                <div><label>Agreed Prize</label><input placeholder="$50 cash or describe..." /></div>
              </div>
              <div><label>Payment Method</label><select><option>Cash App</option><option>Venmo</option><option>PayPal</option><option>Cash</option><option>Other</option></select></div>
              <div><label>Terms / Notes</label><textarea rows={2} placeholder="Winner takes all, loser pays..." style={{ resize: 'none' }} /></div>
              <button onClick={() => toast.success('Agreement logged! Both parties see this in their records.')} className="btn btn-primary" style={{ justifyContent: 'center' }}>✓ Log Agreement</button>
            </div>
          </div>

          <div className="panel" style={{ padding: 16, marginTop: 14 }}>
            <div style={{ fontFamily: 'var(--font-display)', fontSize: 12, fontWeight: 600, letterSpacing: '0.08em', textTransform: 'uppercase', color: 'var(--chrome-dim)', marginBottom: 12 }}>Agreement History</div>
            {[
              { opponent: 'TurboQueen', type: 'Quarter Mile', date: '2025-05-28', result: 'Won', prize: '$100', paid: true },
              { opponent: 'NightRunner', type: 'Top Speed', date: '2025-05-15', result: 'Lost', prize: '$50', paid: true },
            ].map((a, i) => (
              <div key={i} style={{ display: 'flex', gap: 14, padding: '10px 0', borderBottom: 'var(--border)', alignItems: 'center', flexWrap: 'wrap' }}>
                <div style={{ flex: 1 }}>
                  <div style={{ fontFamily: 'var(--font-display)', fontSize: 13, fontWeight: 600, color: 'var(--chrome-bright)' }}>vs {a.opponent}</div>
                  <div style={{ fontSize: 11, color: 'var(--chrome-dim)' }}>{a.type} · {a.date}</div>
                </div>
                <span className={`badge badge-${a.result === 'Won' ? 'green' : 'red'}`}>{a.result}</span>
                <span style={{ fontFamily: 'var(--font-mono)', fontSize: 12, color: a.result === 'Won' ? 'var(--green)' : 'var(--red)' }}>{a.prize}</span>
                <span className={`badge badge-${a.paid ? 'green' : 'yellow'}`}>{a.paid ? '✓ Settled' : 'Pending'}</span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Dispute Form Modal */}
      {showDisputeForm && (
        <div style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.85)', zIndex: 500, display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 16 }}>
          <div style={{ background: 'var(--bg-panel)', border: 'var(--border-red)', borderRadius: 2, padding: 24, width: '100%', maxWidth: 460 }}>
            <div style={{ fontFamily: 'var(--font-display)', fontSize: '1rem', fontWeight: 700, letterSpacing: '0.08em', textTransform: 'uppercase', marginBottom: 20, color: 'var(--chrome-bright)', display: 'flex', justifyContent: 'space-between' }}>
              File a Dispute
              <button onClick={() => setShowDisputeForm(false)} style={{ background: 'none', border: 'none', color: 'var(--chrome-dim)', cursor: 'pointer', fontSize: 20 }}>×</button>
            </div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
              <div><label>Opponent Username *</label><input value={disputeForm.reportedUsername} onChange={e => setD('reportedUsername', e.target.value)} placeholder="Username of person you're reporting" /></div>
              <div className="grid-2">
                <div><label>Race ID (if known)</label><input value={disputeForm.raceId} onChange={e => setD('raceId', e.target.value)} placeholder="race_..." /></div>
                <div><label>Amount Owed</label><input value={disputeForm.amount} onChange={e => setD('amount', e.target.value)} placeholder="$50" /></div>
              </div>
              <div><label>Description *</label><textarea value={disputeForm.description} onChange={e => setD('description', e.target.value)} rows={3} placeholder="Describe what happened — the agreement, outcome, and why this is being reported..." style={{ resize: 'none' }} /></div>
              <div><label>Evidence (screenshots, links)</label><textarea value={disputeForm.evidence} onChange={e => setD('evidence', e.target.value)} rows={2} placeholder="Paste any links to screenshots or race data..." style={{ resize: 'none' }} /></div>
              <div style={{ fontSize: 10, color: 'var(--chrome-dim)', lineHeight: 1.6 }}>
                ⚠️ False disputes will negatively impact YOUR reputation score. Only file genuine disputes.
              </div>
              <div style={{ display: 'flex', gap: 10 }}>
                <button onClick={fileDispute} disabled={submitting} className="btn btn-primary" style={{ flex: 1, justifyContent: 'center' }}>{submitting ? 'Filing...' : '⚖️ File Dispute'}</button>
                <button onClick={() => setShowDisputeForm(false)} className="btn btn-ghost">Cancel</button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
