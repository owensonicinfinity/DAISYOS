import React, { useState, useEffect } from 'react';
import { api } from '../services/api';
import { useAuthStore } from '../store/authStore';
import VehicleCustomizer from '../components/VehicleCustomizer';
import toast from 'react-hot-toast';

const VEHICLE_ICONS = { Car: '🏎️', Motorcycle: '🏍️', Truck: '🚚', Boat: '🚤', Aircraft: '✈️', 'ATV/UTV': '🏋️', Scooter: '🛵', Other: '🚗' };
const COLORS = ['#e00020','#0066ff','#00cc44','#ffcc00','#ff6600','#9900ff','#ffffff','#111111'];
const MAKES = ['Dodge','Ford','Chevrolet','Toyota','Honda','BMW','Mercedes','Nissan','Subaru','Porsche','Ferrari','Lamborghini','McLaren','Kawasaki','Harley-Davidson','Yamaha','Sea-Doo','Cessna','Other'];

const EMPTY_FORM = { name: '', make: '', model: '', year: new Date().getFullYear(), type: 'Car', color: '#e00020', horsepower: '', torque: '', weight: '', mods: '', notes: '' };

export default function Garage() {
  const { user } = useAuthStore();
  const [vehicles, setVehicles] = useState([]);
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState(EMPTY_FORM);
  const [editing, setEditing] = useState(null);
  const [customizing, setCustomizing] = useState(null);
  const [selected, setSelected] = useState(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (user?.id) api.garage.getVehicles(user.id).then(v => { setVehicles(v); if (v.length) setSelected(v[0].id); });
  }, [user]);

  const set = (k, v) => setForm(f => ({ ...f, [k]: v }));

  const handleSave = async () => {
    if (!form.name || !form.make || !form.model) { toast.error('Fill in name, make, and model'); return; }
    setLoading(true);
    try {
      if (editing) {
        const updated = await api.garage.updateVehicle(editing, { ...form, userId: user.id });
        setVehicles(vs => vs.map(v => v.id === editing ? updated : v));
        toast.success('Vehicle updated!');
      } else {
        const v = await api.garage.addVehicle({ ...form, userId: user.id });
        setVehicles(vs => [v, ...vs]);
        setSelected(v.id);
        toast.success(`${form.name} added to garage! 🔧`);
      }
      setShowForm(false); setEditing(null); setForm(EMPTY_FORM);
    } catch (e) { toast.error(e.message); }
    setLoading(false);
  };

  const handleDelete = async (id) => {
    if (!window.confirm('Remove this vehicle from your garage?')) return;
    await api.garage.deleteVehicle(id);
    const remaining = vehicles.filter(v => v.id !== id);
    setVehicles(remaining);
    setSelected(remaining[0]?.id || null);
    toast.success('Vehicle removed');
  };

  const editVehicle = (v) => {
    setForm({ name: v.name, make: v.make, model: v.model, year: v.year, type: v.type, color: v.color, horsepower: v.horsepower || '', torque: v.torque || '', weight: v.weight || '', mods: v.mods || '', notes: v.notes || '' });
    setEditing(v.id);
    setShowForm(true);
  };

  const selectedVehicle = vehicles.find(v => v.id === selected);

  return (
    <div style={{ padding: 16, maxWidth: 1000, margin: '0 auto' }}>
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 20 }}>
        <h2>MY <span style={{ color: 'var(--red)' }}>GARAGE</span></h2>
        <button onClick={() => { setShowForm(true); setEditing(null); setForm(EMPTY_FORM); }} className="btn btn-primary">+ Add Vehicle</button>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: vehicles.length ? '240px 1fr' : '1fr', gap: 16 }}>

        {/* ─── Vehicle List ─── */}
        {vehicles.length > 0 && (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
            {vehicles.map(v => (
              <button key={v.id} onClick={() => setSelected(v.id)}
                style={{ background: selected === v.id ? 'rgba(224,0,32,0.08)' : 'var(--bg-panel)', border: selected === v.id ? 'var(--border-red)' : 'var(--border)', borderRadius: 2, padding: '12px', cursor: 'pointer', textAlign: 'left', transition: 'all 0.15s', display: 'flex', alignItems: 'center', gap: 10 }}>
                <span style={{ fontSize: 24 }}>{VEHICLE_ICONS[v.type] || '🏎️'}</span>
                <div>
                  <div style={{ fontFamily: 'var(--font-display)', fontSize: 13, fontWeight: 700, color: selected === v.id ? 'var(--red)' : 'var(--chrome)', letterSpacing: '0.04em', textTransform: 'uppercase' }}>{v.name}</div>
                  <div style={{ fontSize: 11, color: 'var(--chrome-dim)' }}>{v.year} {v.make} {v.model}</div>
                </div>
                <div style={{ marginLeft: 'auto', width: 10, height: 10, borderRadius: '50%', background: v.color || '#e00020' }} />
              </button>
            ))}
          </div>
        )}

        {/* ─── Selected Vehicle Detail ─── */}
        {selectedVehicle ? (
          <div className="panel" style={{ padding: 20 }}>
            <div style={{ display: 'flex', alignItems: 'flex-start', gap: 16, marginBottom: 20 }}>
              <div style={{ fontSize: 56 }}>{VEHICLE_ICONS[selectedVehicle.type] || '🏎️'}</div>
              <div style={{ flex: 1 }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 4 }}>
                  <h2 style={{ fontSize: '1.4rem', color: 'var(--chrome-bright)' }}>{selectedVehicle.name}</h2>
                  <div style={{ width: 14, height: 14, borderRadius: '50%', background: selectedVehicle.color || '#e00020', border: '1px solid rgba(255,255,255,0.2)' }} />
                </div>
                <div style={{ fontFamily: 'var(--font-display)', fontSize: 13, color: 'var(--chrome-dim)', letterSpacing: '0.04em' }}>{selectedVehicle.year} {selectedVehicle.make} {selectedVehicle.model}</div>
                <div style={{ marginTop: 6 }}><span className={`badge badge-${selectedVehicle.type === 'Car' ? 'red' : 'cyan'}`}>{selectedVehicle.type}</span></div>
              </div>
              <div style={{ display: 'flex', gap: 8 }}>
                <button onClick={() => editVehicle(selectedVehicle)} className="btn btn-ghost btn-sm">Edit</button>
                <button onClick={() => setCustomizing(selectedVehicle)} className="btn btn-cyan btn-sm">🎨 Customize</button>
                <button onClick={() => handleDelete(selectedVehicle.id)} className="btn btn-ghost btn-sm" style={{ color: 'var(--red)' }}>Remove</button>
              </div>
            </div>

            {/* Specs */}
            <div className="grid-3" style={{ marginBottom: 16 }}>
              {[
                { label: 'Horsepower', value: selectedVehicle.horsepower || '—', unit: 'HP' },
                { label: 'Torque', value: selectedVehicle.torque || '—', unit: 'lb-ft' },
                { label: 'Weight', value: selectedVehicle.weight || '—', unit: 'lbs' },
              ].map(s => (
                <div key={s.label} className="stat-box" style={{ background: 'var(--bg-surface)', padding: 12 }}>
                  <div className="stat-label">{s.label}</div>
                  <div className="stat-value" style={{ fontSize: '1.5rem', color: 'var(--red)' }}>{s.value}</div>
                  <div className="stat-unit">{s.unit}</div>
                </div>
              ))}
            </div>

            {/* Power-to-Weight */}
            {selectedVehicle.horsepower && selectedVehicle.weight && (
              <div style={{ background: 'rgba(224,0,32,0.05)', border: '1px solid rgba(224,0,32,0.15)', borderRadius: 2, padding: 12, marginBottom: 16 }}>
                <div style={{ fontFamily: 'var(--font-mono)', fontSize: 10, color: 'var(--chrome-dim)', letterSpacing: '0.1em', textTransform: 'uppercase', marginBottom: 4 }}>Power-to-Weight Ratio</div>
                <div style={{ fontFamily: 'var(--font-mono)', fontSize: '1.6rem', fontWeight: 700, color: 'var(--red)' }}>
                  {(selectedVehicle.horsepower / (selectedVehicle.weight / 1000)).toFixed(1)} <span style={{ fontSize: 11, color: 'var(--chrome-dim)' }}>HP/1000 lbs</span>
                </div>
              </div>
            )}

            {selectedVehicle.mods && (
              <div style={{ marginBottom: 12 }}>
                <div style={{ fontFamily: 'var(--font-display)', fontSize: 11, fontWeight: 600, letterSpacing: '0.08em', textTransform: 'uppercase', color: 'var(--chrome-dim)', marginBottom: 6 }}>Modifications</div>
                <p style={{ fontSize: 13, color: 'var(--chrome)', lineHeight: 1.6, background: 'var(--bg-surface)', padding: 10, borderRadius: 2 }}>{selectedVehicle.mods}</p>
              </div>
            )}
            {selectedVehicle.notes && (
              <div>
                <div style={{ fontFamily: 'var(--font-display)', fontSize: 11, fontWeight: 600, letterSpacing: '0.08em', textTransform: 'uppercase', color: 'var(--chrome-dim)', marginBottom: 6 }}>Notes</div>
                <p style={{ fontSize: 13, color: 'var(--chrome-dim)', lineHeight: 1.6 }}>{selectedVehicle.notes}</p>
              </div>
            )}
          </div>
        ) : !showForm ? (
          <div style={{ textAlign: 'center', padding: '60px 20px', background: 'var(--bg-panel)', border: 'var(--border)', borderRadius: 2 }}>
            <div style={{ fontSize: 48, marginBottom: 12 }}>🔧</div>
            <h3 style={{ color: 'var(--chrome-dim)', marginBottom: 8 }}>Empty Garage</h3>
            <p style={{ fontSize: 13, color: 'var(--chrome-dim)', marginBottom: 20 }}>Add your first vehicle to start racing and tracking telemetry.</p>
            <button onClick={() => setShowForm(true)} className="btn btn-primary">+ Add Vehicle</button>
          </div>
        ) : null}
      </div>

      {/* ─── Add/Edit Form ─── */}
      {showForm && (
        <div style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.8)', zIndex: 500, display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 16 }}>
          <div style={{ background: 'var(--bg-panel)', border: 'var(--border-red)', borderRadius: 2, padding: 24, width: '100%', maxWidth: 520, maxHeight: '90vh', overflowY: 'auto' }}>
            <div style={{ fontFamily: 'var(--font-display)', fontSize: '1rem', fontWeight: 700, letterSpacing: '0.08em', textTransform: 'uppercase', marginBottom: 20, color: 'var(--chrome-bright)', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              {editing ? 'Edit Vehicle' : 'Add to Garage'}
              <button onClick={() => { setShowForm(false); setEditing(null); }} style={{ background: 'none', border: 'none', color: 'var(--chrome-dim)', cursor: 'pointer', fontSize: 20 }}>×</button>
            </div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
              <div className="grid-2"><div><label>Vehicle Nickname</label><input value={form.name} onChange={e => set('name', e.target.value)} placeholder="Turbo Beast" /></div>
              <div><label>Type</label><select value={form.type} onChange={e => set('type', e.target.value)}>{Object.keys(VEHICLE_ICONS).map(t => <option key={t}>{t}</option>)}</select></div></div>
              <div className="grid-2"><div><label>Make</label><select value={form.make} onChange={e => set('make', e.target.value)}><option value="">Select Make</option>{MAKES.map(m => <option key={m}>{m}</option>)}</select></div>
              <div><label>Model</label><input value={form.model} onChange={e => set('model', e.target.value)} placeholder="Challenger SRT" /></div></div>
              <div className="grid-2"><div><label>Year</label><input type="number" value={form.year} onChange={e => set('year', e.target.value)} min={1900} max={2030} /></div>
              <div><label>Color</label><div style={{ display: 'flex', gap: 6, flexWrap: 'wrap', marginTop: 6 }}>{COLORS.map(c => <button key={c} onClick={() => set('color', c)} style={{ width: 24, height: 24, background: c, border: form.color === c ? '2px solid var(--chrome-bright)' : '1px solid rgba(255,255,255,0.1)', borderRadius: '50%', cursor: 'pointer', padding: 0 }} />)}</div></div></div>
              <div className="grid-3"><div><label>HP</label><input type="number" value={form.horsepower} onChange={e => set('horsepower', e.target.value)} placeholder="450" /></div>
              <div><label>Torque (lb-ft)</label><input type="number" value={form.torque} onChange={e => set('torque', e.target.value)} placeholder="420" /></div>
              <div><label>Weight (lbs)</label><input type="number" value={form.weight} onChange={e => set('weight', e.target.value)} placeholder="3800" /></div></div>
              <div><label>Modifications</label><textarea value={form.mods} onChange={e => set('mods', e.target.value)} placeholder="Cold air intake, tune, exhaust, suspension..." rows={2} style={{ resize: 'vertical' }} /></div>
              <div><label>Notes</label><textarea value={form.notes} onChange={e => set('notes', e.target.value)} placeholder="Anything else about this vehicle..." rows={2} style={{ resize: 'vertical' }} /></div>
              <div style={{ display: 'flex', gap: 10, marginTop: 4 }}>
                <button onClick={handleSave} disabled={loading} className="btn btn-primary" style={{ flex: 1, justifyContent: 'center' }}>{loading ? 'Saving...' : editing ? '✓ Update Vehicle' : '+ Add to Garage'}</button>
                <button onClick={() => { setShowForm(false); setEditing(null); }} className="btn btn-ghost">Cancel</button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );

      {/* VehicleCustomizer Modal */}
      {customizing && (
        <VehicleCustomizer
          vehicle={customizing}
          onSave={async (updated) => {
            const saved = await api.garage.updateVehicle(customizing.id, updated);
            setVehicles(vs => vs.map(v => v.id === customizing.id ? saved : v));
            setCustomizing(null);
          }}
          onClose={() => setCustomizing(null)}
        />
      )}

}