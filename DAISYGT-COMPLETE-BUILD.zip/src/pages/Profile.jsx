import React, { useState, useEffect } from 'react';
import { api } from '../services/api';
import { useAuthStore } from '../store/authStore';
import toast from 'react-hot-toast';

const BADGES = [
  { id: 'first_race', icon: '🏁', label: 'First Race', desc: 'Complete your first race' },
  { id: 'speed_demon', icon: '💨', label: 'Speed Demon', desc: 'Hit 150+ mph' },
  { id: 'ghost_hunter', icon: '👻', label: 'Ghost Hunter', desc: 'Beat a ghost racer' },
  { id: 'quarter_king', icon: '⏱️', label: 'Quarter King', desc: 'Run sub-11s quarter mile' },
  { id: 'club_founder', icon: '🔗', label: 'Club Founder', desc: 'Create a racing club' },
  { id: 'social_star', icon: '📡', label: 'Social Star', desc: 'Get 50+ likes on a post' },
  { id: 'elite_member', icon: '⚡', label: 'Elite Member', desc: 'Upgrade to Elite' },
  { id: 'hunter', icon: '🎯', label: 'Hunter', desc: 'Log first harvest' },
  { id: 'iron_racer', icon: '💪', label: 'Iron Racer', desc: 'Log 10 training sessions' },
  { id: 'collector', icon: '💎', label: 'Collector', desc: 'Purchase a race NFT' },
];

export default function Profile() {
  const { user, updateUser, isElite, activateTrial } = useAuthStore();
  const [stats, setStats] = useState(null);
  const [tab, setTab] = useState('profile');
  const [editing, setEditing] = useState(false);
  const [form, setForm] = useState({ username: '', bio: '', location: '', primaryVehicle: 'Car' });
  const [trialCode, setTrialCode] = useState('');
  const [saving, setSaving] = useState(false);

  const elite = isElite();

  useEffect(() => {
    if (user) {
      setForm({ username: user.username || '', bio: user.bio || '', location: user.location || '', primaryVehicle: user.primaryVehicle || 'Car' });
    }
    if (user?.id) api.profile.getStats(user.id).then(setStats);
  }, [user]);

  const saveProfile = async () => {
    if (!form.username) { toast.error('Username is required'); return; }
    setSaving(true);
    try {
      const updated = await api.profile.update(user.id, form);
      updateUser(updated);
      setEditing(false);
      toast.success('Profile updated!');
    } catch (e) { toast.error(e.message); }
    setSaving(false);
  };

  const applyTrialCode = () => {
    if (activateTrial(trialCode.trim())) {
      toast.success('✅ 14-day Elite trial activated! Enjoy full access.');
      setTrialCode('');
    } else {
      toast.error('Invalid trial code. Try DAISYGT-FREE-2025');
    }
  };

  const levelProgress = ((user?.xp || 0) % 500) / 500 * 100;
  const nextLevelXP = Math.ceil((user?.xp || 0) / 500) * 500;

  return (
    <div style={{ padding: 16, maxWidth: 900, margin: '0 auto' }}>
      <h2 style={{ marginBottom: 16 }}>MY <span style={{ color: 'var(--red)' }}>PROFILE</span></h2>

      <div className="tab-bar" style={{ marginBottom: 20 }}>
        {[['profile','Profile'],['stats','Stats'],['badges','Badges'],['subscription','Subscription'],['settings','Settings']].map(([val, label]) => (
          <button key={val} onClick={() => setTab(val)} className={`tab-btn ${tab === val ? 'active' : ''}`}>{label}</button>
        ))}
      </div>

      {tab === 'profile' && (
        <div className="grid-2" style={{ gap: 16, alignItems: 'start' }}>
          {/* Profile Card */}
          <div className="panel" style={{ padding: 24 }}>
            <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 12, marginBottom: 24 }}>
              <div style={{ position: 'relative' }}>
                <img src={user?.avatar || `https://api.dicebear.com/7.x/avataaars/svg?seed=${user?.username}`} alt="" style={{ width: 80, height: 80, borderRadius: '50%', border: '2px solid var(--red)' }} />
                {elite && (
                  <div style={{ position: 'absolute', bottom: 0, right: 0, background: 'var(--cyan)', borderRadius: '50%', width: 22, height: 22, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 12 }}>⚡</div>
                )}
              </div>
              {!editing ? (
                <>
                  <div style={{ textAlign: 'center' }}>
                    <div style={{ fontFamily: 'var(--font-display)', fontSize: '1.4rem', fontWeight: 700, letterSpacing: '0.06em', color: 'var(--chrome-bright)', textTransform: 'uppercase' }}>{user?.username}</div>
                    {user?.location && <div style={{ fontSize: 12, color: 'var(--chrome-dim)', marginTop: 2 }}>📍 {user.location}</div>}
                    {user?.bio && <div style={{ fontSize: 13, color: 'var(--chrome)', marginTop: 8, lineHeight: 1.6 }}>{user.bio}</div>}
                  </div>
                  <div style={{ display: 'flex', gap: 8 }}>
                    {elite ? <span className="badge badge-cyan">⚡ ELITE</span> : <span className="badge badge-red">FREE</span>}
                    <span className="badge badge-yellow">LV.{user?.level || 1}</span>
                    <span className="badge">{user?.primaryVehicle || 'Car'}</span>
                  </div>
                  <button onClick={() => setEditing(true)} className="btn btn-ghost btn-sm">✏️ Edit Profile</button>
                </>
              ) : (
                <div style={{ width: '100%', display: 'flex', flexDirection: 'column', gap: 10 }}>
                  <div><label>Username</label><input value={form.username} onChange={e => setForm(f => ({ ...f, username: e.target.value }))} /></div>
                  <div><label>Bio</label><textarea value={form.bio} onChange={e => setForm(f => ({ ...f, bio: e.target.value }))} rows={2} placeholder="Racing enthusiast from..." style={{ resize: 'none' }} /></div>
                  <div><label>Location</label><input value={form.location} onChange={e => setForm(f => ({ ...f, location: e.target.value }))} placeholder="Houston, TX" /></div>
                  <div><label>Primary Vehicle</label>
                    <select value={form.primaryVehicle} onChange={e => setForm(f => ({ ...f, primaryVehicle: e.target.value }))}>
                      {['Car','Motorcycle','Truck','Boat','Aircraft','ATV/UTV','Scooter','Other'].map(v => <option key={v}>{v}</option>)}
                    </select>
                  </div>
                  <div style={{ display: 'flex', gap: 8 }}>
                    <button onClick={saveProfile} disabled={saving} className="btn btn-primary btn-sm" style={{ flex: 1, justifyContent: 'center' }}>{saving ? 'Saving...' : '✓ Save'}</button>
                    <button onClick={() => setEditing(false)} className="btn btn-ghost btn-sm">Cancel</button>
                  </div>
                </div>
              )}
            </div>

            {/* XP Bar */}
            <div>
              <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 6 }}>
                <span style={{ fontFamily: 'var(--font-mono)', fontSize: 10, color: 'var(--chrome-dim)', letterSpacing: '0.1em', textTransform: 'uppercase' }}>XP Progress</span>
                <span style={{ fontFamily: 'var(--font-mono)', fontSize: 10, color: 'var(--red)' }}>{user?.xp || 0} / {nextLevelXP}</span>
              </div>
              <div style={{ height: 6, background: 'var(--bg-elevated)', borderRadius: 3 }}>
                <div style={{ height: '100%', width: `${levelProgress}%`, background: 'linear-gradient(90deg, var(--red), var(--red-hot))', borderRadius: 3, boxShadow: '0 0 10px var(--red-glow)', transition: 'width 0.5s' }} />
              </div>
              <div style={{ fontFamily: 'var(--font-mono)', fontSize: 9, color: 'var(--chrome-dim)', marginTop: 4 }}>
                {nextLevelXP - (user?.xp || 0)} XP to Level {(user?.level || 1) + 1}
              </div>
            </div>
          </div>

          {/* Quick Stats */}
          <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
            <div className="panel" style={{ padding: 16 }}>
              <div style={{ fontFamily: 'var(--font-display)', fontSize: 12, fontWeight: 600, letterSpacing: '0.08em', textTransform: 'uppercase', color: 'var(--chrome-dim)', marginBottom: 14 }}>Racing Record</div>
              <div className="grid-3" style={{ gap: 10 }}>
                {[
                  { label: 'Races', value: stats?.totalRaces || user?.races || 0 },
                  { label: 'Wins', value: stats?.wins || user?.wins || 0, color: 'var(--green)' },
                  { label: 'Losses', value: stats?.losses || user?.losses || 0, color: 'var(--red)' },
                  { label: 'Win Rate', value: `${stats?.winRate || 0}%`, color: 'var(--cyan)' },
                  { label: 'Best Speed', value: `${Math.round(stats?.bestSpeed || 0)} mph` },
                  { label: 'Miles', value: Math.round(stats?.totalDistance || 0) },
                ].map(s => (
                  <div key={s.label} className="stat-box" style={{ background: 'var(--bg-surface)', padding: 10, textAlign: 'center' }}>
                    <div className="stat-label">{s.label}</div>
                    <div className="stat-value" style={{ fontSize: '1.3rem', color: s.color || 'var(--chrome-bright)' }}>{s.value}</div>
                  </div>
                ))}
              </div>
            </div>

            <div className="panel" style={{ padding: 16 }}>
              <div style={{ fontFamily: 'var(--font-display)', fontSize: 12, fontWeight: 600, letterSpacing: '0.08em', textTransform: 'uppercase', color: 'var(--chrome-dim)', marginBottom: 14 }}>Account Details</div>
              {[
                { label: 'Member Since', value: user?.joinedAt ? new Date(user.joinedAt).toLocaleDateString() : '2025' },
                { label: 'Email', value: user?.email || '—' },
                { label: 'Subscription', value: elite ? 'Elite' : 'Free', color: elite ? 'var(--cyan)' : 'var(--chrome-dim)' },
                { label: 'User ID', value: `#${(user?.id || '').slice(-6).toUpperCase()}` },
              ].map(item => (
                <div key={item.label} style={{ display: 'flex', justifyContent: 'space-between', padding: '8px 0', borderBottom: 'var(--border)' }}>
                  <span style={{ fontSize: 12, color: 'var(--chrome-dim)' }}>{item.label}</span>
                  <span style={{ fontFamily: 'var(--font-mono)', fontSize: 12, color: item.color || 'var(--chrome)' }}>{item.value}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {tab === 'stats' && (
        <div className="grid-3" style={{ gap: 14 }}>
          {[
            { label: 'Total Races', value: stats?.totalRaces || 0, icon: '🏁', color: 'var(--red)' },
            { label: 'Wins', value: stats?.wins || 0, icon: '🏆', color: 'var(--yellow)' },
            { label: 'Win Rate', value: `${stats?.winRate || 0}%`, icon: '📈', color: 'var(--green)' },
            { label: 'Best Speed', value: `${Math.round(stats?.bestSpeed || 0)} mph`, icon: '💨', color: 'var(--cyan)' },
            { label: 'Total Miles', value: `${Math.round(stats?.totalDistance || 0)} mi`, icon: '📍', color: 'var(--chrome)' },
            { label: 'Training Sessions', value: stats?.trainingSessions || 0, icon: '💪', color: 'var(--orange)' },
            { label: 'Level', value: user?.level || 1, icon: '⭐', color: 'var(--yellow)' },
            { label: 'Total XP', value: user?.xp || 0, icon: '⚡', color: 'var(--red)' },
            { label: 'Clubs Joined', value: 2, icon: '🔗', color: 'var(--cyan)' },
          ].map(s => (
            <div key={s.label} className="panel" style={{ padding: 20, textAlign: 'center' }}>
              <div style={{ fontSize: 28, marginBottom: 8 }}>{s.icon}</div>
              <div style={{ fontFamily: 'var(--font-mono)', fontSize: '1.8rem', fontWeight: 700, color: s.color, marginBottom: 4 }}>{s.value}</div>
              <div style={{ fontFamily: 'var(--font-mono)', fontSize: 9, letterSpacing: '0.1em', textTransform: 'uppercase', color: 'var(--chrome-dim)' }}>{s.label}</div>
            </div>
          ))}
        </div>
      )}

      {tab === 'badges' && (
        <div>
          <div style={{ fontFamily: 'var(--font-display)', fontSize: 12, fontWeight: 600, letterSpacing: '0.08em', textTransform: 'uppercase', color: 'var(--chrome-dim)', marginBottom: 16 }}>
            Earned {(user?.badges || []).length} / {BADGES.length} Badges
          </div>
          <div className="grid-4" style={{ gap: 12 }}>
            {BADGES.map(badge => {
              const earned = (user?.badges || []).includes(badge.id) || ['first_race','elite_member'].includes(badge.id) && (badge.id === 'elite_member' ? elite : true);
              return (
                <div key={badge.id} className="card" style={{ textAlign: 'center', opacity: earned ? 1 : 0.4, filter: earned ? 'none' : 'grayscale(1)' }}>
                  <div style={{ fontSize: 32, marginBottom: 8 }}>{badge.icon}</div>
                  <div style={{ fontFamily: 'var(--font-display)', fontSize: 11, fontWeight: 700, letterSpacing: '0.06em', textTransform: 'uppercase', color: earned ? 'var(--chrome-bright)' : 'var(--chrome-dim)', marginBottom: 4 }}>{badge.label}</div>
                  <div style={{ fontSize: 10, color: 'var(--chrome-dim)', lineHeight: 1.4 }}>{badge.desc}</div>
                  {earned && <div style={{ marginTop: 8, fontFamily: 'var(--font-mono)', fontSize: 9, color: 'var(--green)' }}>✓ EARNED</div>}
                </div>
              );
            })}
          </div>
        </div>
      )}

      {tab === 'subscription' && (
        <div style={{ maxWidth: 600 }}>
          <div className="panel" style={{ padding: 24, marginBottom: 16 }}>
            <div style={{ fontFamily: 'var(--font-display)', fontSize: 13, fontWeight: 700, letterSpacing: '0.08em', textTransform: 'uppercase', color: 'var(--chrome-bright)', marginBottom: 6 }}>Current Plan</div>
            <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 20 }}>
              <span style={{ fontFamily: 'var(--font-mono)', fontSize: '1.5rem', fontWeight: 700, color: elite ? 'var(--cyan)' : 'var(--chrome-dim)' }}>{elite ? '⚡ ELITE' : 'FREE'}</span>
              {elite && <span className="badge badge-cyan">Active</span>}
            </div>
            {elite ? (
              <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
                {['Ghost Racing Overlay','Daisy Dyno Full Access','OBD2 Integration','Race NFT Minting','Analytics Dashboard','Audio Engine Analysis','Priority Race Matching','Training Leaderboards'].map(f => (
                  <div key={f} style={{ display: 'flex', gap: 8, fontSize: 13, color: 'var(--chrome)' }}>
                    <span style={{ color: 'var(--green)' }}>✓</span> {f}
                  </div>
                ))}
              </div>
            ) : (
              <>
                <p style={{ fontSize: 13, color: 'var(--chrome-dim)', marginBottom: 20 }}>Upgrade to Elite for Ghost Racing, full Dyno, OBD2 integration, and more.</p>
                <button className="btn btn-primary btn-lg" style={{ width: '100%', justifyContent: 'center' }}>Upgrade to Elite — $4.99</button>
              </>
            )}
          </div>

          {/* Trial Code */}
          <div className="panel" style={{ padding: 20 }}>
            <div style={{ fontFamily: 'var(--font-display)', fontSize: 13, fontWeight: 700, letterSpacing: '0.08em', textTransform: 'uppercase', color: 'var(--chrome-bright)', marginBottom: 12 }}>Free Trial Code</div>
            <p style={{ fontSize: 13, color: 'var(--chrome-dim)', marginBottom: 16 }}>Have a 2-week free Elite trial code? Enter it below.</p>
            <div style={{ display: 'flex', gap: 10 }}>
              <input value={trialCode} onChange={e => setTrialCode(e.target.value.toUpperCase())} placeholder="DAISYGT-FREE-2025" style={{ fontFamily: 'var(--font-mono)', letterSpacing: '0.06em' }} />
              <button onClick={applyTrialCode} className="btn btn-cyan" style={{ whiteSpace: 'nowrap' }}>Apply Code</button>
            </div>
            <p style={{ fontSize: 11, color: 'var(--chrome-dim)', marginTop: 10 }}>
              Share code with friends: <span style={{ fontFamily: 'var(--font-mono)', color: 'var(--yellow)' }}>DAISYGT-FREE-2025</span>
            </p>
          </div>
        </div>
      )}

      {tab === 'settings' && (
        <div style={{ maxWidth: 500 }}>
          {[
            { group: 'Notifications', settings: [['Race invites','notifications_race',true],['Club messages','notifications_club',true],['Leaderboard updates','notifications_lb',false],['New followers','notifications_follow',true]] },
            { group: 'Privacy', settings: [['Public profile','privacy_public',true],['Show race history','privacy_races',true],['Show in leaderboards','privacy_lb',true]] },
            { group: 'Racing', settings: [['Auto-start GPS on race','gps_auto',true],['Simulation mode (no GPS)','sim_mode',false],['Ghost overlay enabled','ghost_enabled',true],['Share telemetry data','share_telemetry',false]] },
          ].map(group => (
            <div key={group.group} className="panel" style={{ padding: 16, marginBottom: 12 }}>
              <div style={{ fontFamily: 'var(--font-display)', fontSize: 12, fontWeight: 700, letterSpacing: '0.08em', textTransform: 'uppercase', color: 'var(--chrome-dim)', marginBottom: 12 }}>{group.group}</div>
              {group.settings.map(([label, key, defaultVal]) => (
                <div key={key} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '10px 0', borderBottom: 'var(--border)' }}>
                  <span style={{ fontSize: 13, color: 'var(--chrome)' }}>{label}</span>
                  <button
                    onClick={() => toast.success(`${label} updated`)}
                    style={{ width: 44, height: 24, background: defaultVal ? 'var(--red)' : 'var(--bg-elevated)', borderRadius: 12, border: 'none', cursor: 'pointer', position: 'relative', transition: 'background 0.2s' }}>
                    <div style={{ width: 18, height: 18, background: '#fff', borderRadius: '50%', position: 'absolute', top: 3, left: defaultVal ? 23 : 3, transition: 'left 0.2s' }} />
                  </button>
                </div>
              ))}
            </div>
          ))}

          <div className="panel" style={{ padding: 16 }}>
            <div style={{ fontFamily: 'var(--font-display)', fontSize: 12, fontWeight: 700, letterSpacing: '0.08em', textTransform: 'uppercase', color: 'var(--red)', marginBottom: 12 }}>Danger Zone</div>
            <button className="btn btn-ghost btn-sm" style={{ color: 'var(--red)', borderColor: 'rgba(224,0,32,0.3)', marginRight: 8 }} onClick={() => toast('Account deletion requires email confirmation')}>Delete Account</button>
            <button className="btn btn-ghost btn-sm" onClick={() => { localStorage.clear(); window.location.reload(); }}>Clear All Data</button>
          </div>
        </div>
      )}
    </div>
  );
}
