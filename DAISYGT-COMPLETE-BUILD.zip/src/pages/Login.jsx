import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { api, seedDemoData } from '../services/api';
import { useAuthStore } from '../store/authStore';
import toast from 'react-hot-toast';

export default function Login() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const { login } = useAuthStore();
  const navigate = useNavigate();

  seedDemoData();

  const handleSubmit = async () => {
    if (!email || !password) { toast.error('Fill in all fields'); return; }
    setLoading(true);
    try {
      const { user, token } = await api.auth.login({ email, password });
      login(user, token);
      toast.success(`Welcome back, ${user.username}!`);
      navigate('/app');
    } catch (e) {
      toast.error(e.message);
    }
    setLoading(false);
  };

  const demoLogin = async () => {
    setLoading(true);
    try {
      const { user, token } = await api.auth.login({ email: 'demo3@daisygt.com', password: 'demo' }).catch(() =>
        api.auth.googleLogin({ email: 'demo3@daisygt.com', name: 'TurboQueen', picture: 'https://api.dicebear.com/7.x/avataaars/svg?seed=queen' })
      );
      login(user, token);
      navigate('/app');
    } catch {
      // Create fresh demo user
      const { user, token } = await api.auth.register({ username: 'DemoRacer', email: `demo_${Date.now()}@daisygt.com`, password: 'demo123' });
      login(user, token);
      navigate('/app');
    }
    setLoading(false);
  };

  return (
    <div style={{ minHeight: '100vh', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', padding: 24, position: 'relative', zIndex: 1 }}>

      {/* Back */}
      <Link to="/" style={{ position: 'fixed', top: 20, left: 20, color: 'var(--chrome-dim)', textDecoration: 'none', fontFamily: 'var(--font-display)', fontSize: 12, letterSpacing: '0.06em', textTransform: 'uppercase' }}>← Back</Link>

      <div style={{ width: '100%', maxWidth: 400 }}>
        {/* Logo */}
        <div style={{ textAlign: 'center', marginBottom: 40 }}>
          <div style={{ fontFamily: 'var(--font-display)', fontSize: '2rem', fontWeight: 700, letterSpacing: '0.1em' }}>
            <span style={{ color: 'var(--chrome-bright)' }}>DAISY</span>
            <span style={{ color: 'var(--red)' }}>GT</span>
          </div>
          <p style={{ fontSize: 13, color: 'var(--chrome-dim)', marginTop: 4 }}>Sign in to your racing account</p>
        </div>

        <div className="panel" style={{ padding: 24 }}>
          {/* Google OAuth placeholder */}
          <button
            onClick={demoLogin}
            style={{ width: '100%', background: 'var(--bg-surface)', border: 'var(--border)', color: 'var(--chrome)', padding: '10px 16px', borderRadius: 2, cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 10, fontFamily: 'var(--font-body)', fontSize: 13, marginBottom: 20, transition: 'border-color 0.15s' }}
            onMouseEnter={e => e.currentTarget.style.borderColor = 'var(--red)'}
            onMouseLeave={e => e.currentTarget.style.borderColor = 'rgba(255,255,255,0.06)'}
          >
            <svg width="18" height="18" viewBox="0 0 48 48"><path fill="#EA4335" d="M24 9.5c3.6 0 6.6 1.3 9 3.4l6.7-6.7C35.5 2.5 30.2 0 24 0 14.7 0 6.8 5.5 2.9 13.5l7.8 6.1C12.4 13.5 17.8 9.5 24 9.5z"/><path fill="#4285F4" d="M46.6 24.5c0-1.6-.1-3.2-.4-4.7H24v8.9h12.7c-.5 2.9-2.2 5.3-4.7 6.9l7.3 5.7c4.3-4 6.8-9.9 6.8-16.8z"/><path fill="#FBBC05" d="M10.7 28.6A14.7 14.7 0 0 1 9.5 24c0-1.6.3-3.1.7-4.6L2.4 13.3A24 24 0 0 0 0 24c0 3.8.9 7.4 2.5 10.6l8.2-6z"/><path fill="#34A853" d="M24 48c6.2 0 11.4-2 15.2-5.5l-7.3-5.7c-2 1.4-4.6 2.2-7.9 2.2-6.2 0-11.5-4.2-13.4-9.9l-8 6.2C6.6 42.4 14.7 48 24 48z"/></svg>
            Continue with Google (Demo)
          </button>

          <div className="divider" style={{ textAlign: 'center', position: 'relative' }}>
            <span style={{ position: 'relative', zIndex: 1, background: 'var(--bg-panel)', padding: '0 10px', fontSize: 11, color: 'var(--chrome-dim)' }}>or email</span>
          </div>

          <div style={{ display: 'flex', flexDirection: 'column', gap: 14, marginTop: 16 }}>
            <div>
              <label>Email</label>
              <input type="email" value={email} onChange={e => setEmail(e.target.value)} placeholder="racer@daisygt.com" onKeyDown={e => e.key === 'Enter' && handleSubmit()} />
            </div>
            <div>
              <label>Password</label>
              <input type="password" value={password} onChange={e => setPassword(e.target.value)} placeholder="••••••••" onKeyDown={e => e.key === 'Enter' && handleSubmit()} />
            </div>

            <button onClick={handleSubmit} disabled={loading} className="btn btn-primary" style={{ width: '100%', justifyContent: 'center', marginTop: 4 }}>
              {loading ? 'Signing in...' : '🏁 Sign In'}
            </button>
          </div>

          <p style={{ textAlign: 'center', fontSize: 12, color: 'var(--chrome-dim)', marginTop: 20 }}>
            No account? <Link to="/register" style={{ color: 'var(--red)', textDecoration: 'none' }}>Create one free →</Link>
          </p>
        </div>

        <p style={{ textAlign: 'center', fontSize: 11, color: 'rgba(255,255,255,0.2)', marginTop: 20 }}>
          Free trial code: <span style={{ color: 'var(--yellow)', fontFamily: 'var(--font-mono)' }}>DAISYGT-FREE-2025</span>
        </p>
      </div>
    </div>
  );
}
