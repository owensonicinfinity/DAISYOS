import React, { useEffect, useRef } from 'react';
import { Link } from 'react-router-dom';

const VEHICLES = ['🏎️', '🏍️', '🚤', '✈️', '🚁', '🏁', '⚙️', '🔧'];

export default function Landing() {
  const scrollRef = useRef(null);

  useEffect(() => {
    let pos = 0;
    const interval = setInterval(() => {
      pos += 0.5;
      if (scrollRef.current) scrollRef.current.style.transform = `translateX(-${pos % 300}px)`;
    }, 16);
    return () => clearInterval(interval);
  }, []);

  return (
    <div style={{ minHeight: '100vh', background: 'var(--bg-void)', position: 'relative', overflowX: 'hidden' }}>

      {/* ─── Scrolling Vehicle Banner ─── */}
      <div style={{ position: 'fixed', top: 0, left: 0, right: 0, height: 40, background: 'rgba(10,10,12,0.95)', borderBottom: '1px solid rgba(224,0,32,0.3)', overflow: 'hidden', zIndex: 50, display: 'flex', alignItems: 'center' }}>
        <div ref={scrollRef} style={{ display: 'flex', gap: 40, whiteSpace: 'nowrap', fontSize: 18 }}>
          {[...Array(8)].fill(VEHICLES).flat().map((v, i) => (
            <span key={i} style={{ opacity: 0.7 }}>{v}</span>
          ))}
        </div>
      </div>

      {/* ─── Nav ─── */}
      <nav style={{ position: 'fixed', top: 40, left: 0, right: 0, height: 60, background: 'rgba(10,10,12,0.95)', borderBottom: '1px solid rgba(255,255,255,0.05)', backdropFilter: 'blur(10px)', display: 'flex', alignItems: 'center', padding: '0 24px', gap: 16, zIndex: 40 }}>
        <div style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: '1.5rem', letterSpacing: '0.1em', flex: 1 }}>
          <span style={{ color: 'var(--chrome-bright)' }}>DAISY</span>
          <span style={{ color: 'var(--red)' }}>GT</span>
          <span style={{ color: 'var(--chrome-dim)', fontSize: '0.75rem', verticalAlign: 'super', marginLeft: 4 }}>OS</span>
        </div>
        <Link to="/login" className="btn btn-ghost btn-sm">Sign In</Link>
        <Link to="/register" className="btn btn-primary btn-sm">Get Started Free</Link>
      </nav>

      {/* ─── Hero ─── */}
      <section style={{ minHeight: '100vh', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', padding: '140px 24px 80px', textAlign: 'center', position: 'relative' }}>

        {/* Background glow */}
        <div style={{ position: 'absolute', top: '30%', left: '50%', transform: 'translate(-50%,-50%)', width: 600, height: 600, background: 'radial-gradient(circle, rgba(224,0,32,0.12) 0%, transparent 70%)', pointerEvents: 'none' }} />

        <div style={{ marginBottom: 16, display: 'flex', alignItems: 'center', gap: 8, justifyContent: 'center' }}>
          <span className="live-dot" />
          <span style={{ fontFamily: 'var(--font-mono)', fontSize: 11, letterSpacing: '0.12em', textTransform: 'uppercase', color: 'var(--red)' }}>
            Live Global Racing Platform
          </span>
        </div>

        <h1 style={{ fontFamily: 'var(--font-display)', fontSize: 'clamp(3rem, 10vw, 7rem)', fontWeight: 700, letterSpacing: '0.06em', lineHeight: 0.9, textTransform: 'uppercase', marginBottom: 24, position: 'relative', zIndex: 1 }}>
          <span style={{ color: 'var(--chrome-bright)' }}>RACE</span>
          <br />
          <span style={{ color: 'var(--red)', textShadow: '0 0 60px rgba(224,0,32,0.5)' }}>ANYONE</span>
          <br />
          <span style={{ color: 'var(--chrome-dim)' }}>ANYWHERE</span>
        </h1>

        <p style={{ maxWidth: 560, fontSize: 16, color: 'var(--chrome-dim)', lineHeight: 1.7, marginBottom: 40, position: 'relative', zIndex: 1 }}>
          The world's most advanced multi-vehicle racing platform. Real-time GPS racing with ghost overlays, professional telemetry, social media integration, and global competition. Under the <strong style={{ color: 'var(--chrome)' }}>DaisyOS</strong> ecosystem.
        </p>

        <div style={{ display: 'flex', gap: 12, flexWrap: 'wrap', justifyContent: 'center', position: 'relative', zIndex: 1, marginBottom: 60 }}>
          <Link to="/register" className="btn btn-primary btn-lg">🏁 Start Racing Free</Link>
          <Link to="/spectator/demo" className="btn btn-cyan btn-lg">👁️ Watch Live Race</Link>
        </div>

        {/* Free trial callout */}
        <div style={{ background: 'rgba(0,229,255,0.06)', border: '1px solid rgba(0,229,255,0.2)', borderRadius: 2, padding: '12px 24px', fontFamily: 'var(--font-mono)', fontSize: 12, color: 'var(--cyan)', position: 'relative', zIndex: 1 }}>
          🎁 FREE 2-WEEK ELITE TRIAL — Code: <strong style={{ color: 'var(--yellow)' }}>DAISYGT-FREE-2025</strong>
        </div>
      </section>

      {/* ─── Stats Bar ─── */}
      <div style={{ background: 'var(--bg-panel)', borderTop: 'var(--border)', borderBottom: 'var(--border)', padding: '24px', display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(140px, 1fr))', gap: 24, textAlign: 'center' }}>
        {[
          { label: 'Active Racers', value: '48,291', unit: 'worldwide' },
          { label: 'Races Today', value: '3,847', unit: 'live & completed' },
          { label: 'Top Speed', value: '212', unit: 'mph recorded' },
          { label: 'Live Spectators', value: '124K', unit: 'watching now' },
          { label: 'Vehicle Types', value: '12+', unit: 'supported' },
          { label: 'Countries', value: '94', unit: 'active' },
        ].map(s => (
          <div key={s.label} className="stat-box" style={{ alignItems: 'center' }}>
            <div className="stat-value" style={{ fontSize: '2rem', color: 'var(--red)' }}>{s.value}</div>
            <div className="stat-label">{s.label}</div>
            <div className="stat-unit">{s.unit}</div>
          </div>
        ))}
      </div>

      {/* ─── Features ─── */}
      <section style={{ padding: '80px 24px', maxWidth: 1100, margin: '0 auto' }}>
        <h2 style={{ textAlign: 'center', marginBottom: 12 }}>Everything Racing <span style={{ color: 'var(--red)' }}>Needs</span></h2>
        <p style={{ textAlign: 'center', color: 'var(--chrome-dim)', marginBottom: 48 }}>All major racing apps. One ecosystem.</p>

        <div className="grid-3">
          {FEATURES.map((f, i) => (
            <div key={i} className="card" style={{ animationDelay: `${i * 0.05}s` }}>
              <div style={{ fontSize: 28, marginBottom: 12 }}>{f.icon}</div>
              <h3 style={{ fontSize: '1rem', marginBottom: 8, color: f.accent === 'cyan' ? 'var(--cyan)' : 'var(--red)' }}>{f.title}</h3>
              <p style={{ fontSize: 13, color: 'var(--chrome-dim)', lineHeight: 1.6 }}>{f.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* ─── Vehicle Types ─── */}
      <section style={{ background: 'var(--bg-panel)', padding: '60px 24px', textAlign: 'center' }}>
        <h2 style={{ marginBottom: 12 }}>Every <span style={{ color: 'var(--red)' }}>Vehicle</span> Type</h2>
        <p style={{ color: 'var(--chrome-dim)', marginBottom: 40 }}>Cars, bikes, boats, aircraft, and more</p>
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: 12, justifyContent: 'center' }}>
          {VEHICLE_TYPES.map(v => (
            <div key={v.type} style={{ background: 'var(--bg-surface)', border: 'var(--border)', borderRadius: 2, padding: '12px 20px', display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 6, minWidth: 90 }}>
              <span style={{ fontSize: 28 }}>{v.icon}</span>
              <span style={{ fontFamily: 'var(--font-display)', fontSize: 11, fontWeight: 600, letterSpacing: '0.06em', textTransform: 'uppercase', color: 'var(--chrome-dim)' }}>{v.type}</span>
            </div>
          ))}
        </div>
      </section>

      {/* ─── Pricing ─── */}
      <section style={{ padding: '80px 24px', maxWidth: 900, margin: '0 auto' }}>
        <h2 style={{ textAlign: 'center', marginBottom: 8 }}>Simple <span style={{ color: 'var(--red)' }}>Pricing</span></h2>
        <p style={{ textAlign: 'center', color: 'var(--chrome-dim)', marginBottom: 48 }}>Start free. Upgrade when you're ready to dominate.</p>

        <div className="grid-3">
          {PRICING.map((p, i) => (
            <div key={i} className="card" style={{ border: p.featured ? 'var(--border-red)' : 'var(--border)', position: 'relative', overflow: 'visible' }}>
              {p.featured && <div style={{ position: 'absolute', top: -12, left: '50%', transform: 'translateX(-50%)', background: 'var(--red)', fontFamily: 'var(--font-display)', fontSize: 10, fontWeight: 700, letterSpacing: '0.1em', textTransform: 'uppercase', padding: '3px 12px', color: '#fff', borderRadius: 1 }}>Most Popular</div>}
              <div style={{ fontFamily: 'var(--font-display)', fontSize: 13, fontWeight: 600, letterSpacing: '0.08em', textTransform: 'uppercase', color: 'var(--chrome-dim)', marginBottom: 12 }}>{p.name}</div>
              <div style={{ fontFamily: 'var(--font-mono)', fontSize: '2rem', fontWeight: 700, color: p.featured ? 'var(--red)' : 'var(--chrome-bright)', marginBottom: 4 }}>{p.price}</div>
              <div style={{ fontSize: 11, color: 'var(--chrome-dim)', marginBottom: 20 }}>{p.period}</div>
              <ul style={{ listStyle: 'none', marginBottom: 24 }}>
                {p.features.map((f, j) => (
                  <li key={j} style={{ fontSize: 12, color: 'var(--chrome)', paddingBottom: 8, display: 'flex', gap: 8 }}>
                    <span style={{ color: 'var(--green)' }}>✓</span> {f}
                  </li>
                ))}
              </ul>
              <Link to="/register" className={`btn ${p.featured ? 'btn-primary' : 'btn-ghost'}`} style={{ width: '100%', justifyContent: 'center' }}>
                {p.cta}
              </Link>
            </div>
          ))}
        </div>
      </section>

      {/* ─── Footer ─── */}
      <footer style={{ background: 'var(--bg-panel)', borderTop: 'var(--border)', padding: '40px 24px', textAlign: 'center' }}>
        <div style={{ fontFamily: 'var(--font-display)', fontSize: '1.2rem', fontWeight: 700, letterSpacing: '0.1em', marginBottom: 8 }}>
          <span style={{ color: 'var(--chrome-bright)' }}>DAISY</span>
          <span style={{ color: 'var(--red)' }}>GT</span>
          <span style={{ color: 'var(--chrome-dim)', fontSize: '0.7rem', verticalAlign: 'super', marginLeft: 4 }}>OS</span>
        </div>
        <p style={{ fontSize: 12, color: 'var(--chrome-dim)' }}>
          Part of the <strong>DaisyOS</strong> ecosystem · daisyapps.com
        </p>
        <div style={{ marginTop: 16, display: 'flex', gap: 16, justifyContent: 'center', flexWrap: 'wrap' }}>
          {['SaysoSocial', 'DaisyAI Hunting', 'DaisyOS Platform', 'Privacy Policy', 'Terms'].map(l => (
            <a key={l} href="#" style={{ fontSize: 11, color: 'var(--chrome-dim)', textDecoration: 'none' }}>{l}</a>
          ))}
        </div>
        <p style={{ fontSize: 10, color: 'rgba(255,255,255,0.2)', marginTop: 24 }}>
          © 2025 DaisyOS. Daisy GT. All rights reserved. Racing responsibly, legally, on private roads or tracks only.
        </p>
      </footer>
    </div>
  );
}

const FEATURES = [
  { icon: '👻', title: 'Ghost Vehicle Overlay', desc: 'Race against real-time ghost overlays of opponents anywhere in the world. See them on your map as you race.', accent: 'red' },
  { icon: '📡', title: 'Real-Time GPS Racing', desc: 'Live GPS tracking with speed, distance, elevation, road grade, and heading. Up to 12 racers simultaneously.', accent: 'red' },
  { icon: '📊', title: 'Daisy Dyno (DDG)', desc: 'Professional telemetry: 0-60, 1/4 mile, top speed, G-force, launch analysis, braking distance. All from your phone.', accent: 'cyan' },
  { icon: '📺', title: 'Spectator Mode (Free)', desc: 'Watch any live race with GPS map, ghost overlay, live chat, and multi-angle streams. Unlimited spectators.', accent: 'cyan' },
  { icon: '🎧', title: 'Audio Engine Analysis', desc: 'Microphone-based RPM estimation, misfire detection, and spark event analysis. Experimental AI audio tech.', accent: 'red' },
  { icon: '🔌', title: 'OBD2 Integration', desc: 'Bluetooth OBD2 support for live RPM, throttle, engine load, temps, and full engine telemetry sync.', accent: 'cyan' },
  { icon: '🏆', title: 'Global Leaderboards', desc: 'Compete in 20+ categories: top speed, quarter mile, bench press, punch speed, hunting, and more.', accent: 'red' },
  { icon: '💎', title: 'Race NFT Marketplace', desc: 'Each race generates a unique digital asset. Buy, sell, and collect race records, POV footage, and telemetry data.', accent: 'cyan' },
  { icon: '🎯', title: 'DaisyAI Hunting', desc: 'AI-powered hunting guide with weather, terrain, animal behavior, seasonal tips, and harvest tracking.', accent: 'red' },
  { icon: '🔗', title: 'Racing Clubs', desc: 'Create or join racing clubs with up to 12 racers. Schedule events, chat, compete in private leagues.', accent: 'cyan' },
  { icon: '💪', title: 'Full Training Suite', desc: 'Boxing, weightlifting, agility, balance — track everything. 17+ leaderboard categories.', accent: 'red' },
  { icon: '⚽', title: 'Multi-Sport Platform', desc: 'NFL, NBA, MLB, F1, MMA and more. Live scores, stats, and betting insights all in one app.', accent: 'cyan' },
];

const VEHICLE_TYPES = [
  { icon: '🏎️', type: 'Supercar' },
  { icon: '🚗', type: 'Car' },
  { icon: '🏍️', type: 'Motorcycle' },
  { icon: '🚓', type: 'Muscle' },
  { icon: '🚚', type: 'Truck' },
  { icon: '🚤', type: 'Boat' },
  { icon: '⛵', type: 'Sailboat' },
  { icon: '✈️', type: 'Aircraft' },
  { icon: '🚁', type: 'Helicopter' },
  { icon: '🛺', type: 'Custom' },
  { icon: '🏋️', type: 'ATV/UTV' },
  { icon: '🛵', type: 'Scooter' },
];

const PRICING = [
  {
    name: 'Free',
    price: '$0',
    period: 'forever',
    features: [
      'GPS Race Tracking',
      'Spectator Mode',
      'Social Feed',
      'Basic Leaderboards',
      '1 Vehicle Garage Slot',
      'Club Membership',
    ],
    cta: 'Start Free',
    featured: false,
  },
  {
    name: 'Elite',
    price: '$4.99',
    period: 'one-time or $1.99/mo',
    features: [
      'Everything in Free',
      'Ghost Racing Overlay',
      'Daisy Dyno (DDG) Full',
      'OBD2 Integration',
      'Analytics Dashboard',
      'Race NFT Minting',
      'Audio Engine Analysis',
      'Training Leaderboards',
      'Priority Race Matching',
      '2-Week Free Trial',
    ],
    cta: 'Get Elite',
    featured: true,
  },
  {
    name: 'Pro Club',
    price: '$9.99',
    period: '/month',
    features: [
      'Everything in Elite',
      'Premium Club Features',
      'Featured Race Scheduling',
      'Sponsorship Placements',
      'Custom Club Branding',
      'Advanced AI Analysis',
      'Early Feature Access',
    ],
    cta: 'Go Pro',
    featured: false,
  },
];
