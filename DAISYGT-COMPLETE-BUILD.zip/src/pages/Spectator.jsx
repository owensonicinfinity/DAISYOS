import React, { useState, useEffect, useRef } from 'react';
import { Link, useParams } from 'react-router-dom';
import { startSimulation, stopSimulation, onTelemetryUpdate } from '../services/gps';

const CHAT_SEED = [
  { user: 'TurboFan_44', text: '🔥🔥🔥 GO TURBO QUEEN!', time: Date.now() - 8000 },
  { user: 'GhostWatcher', text: 'This ghost overlay is INSANE', time: Date.now() - 6000 },
  { user: 'DaisyOS_Fan', text: 'What app is this?? 🏎️', time: Date.now() - 5000 },
  { user: 'RacingLuv', text: 'She pulled away on turn 2', time: Date.now() - 3500 },
  { user: 'SpeedFreak', text: '⚡⚡⚡⚡', time: Date.now() - 2000 },
];

const REACTIONS_LIST = ['🔥','⚡','🏎️','👑','💨','🚀','🏁','💯'];

export default function Spectator() {
  const { raceId } = useParams();
  const [racers, setRacers] = useState([
    { id: 'r1', name: 'TurboQueen', color: 'var(--red)', speed: 0, distance: 0, topSpeed: 0, position: 1, vehicle: '🏎️' },
    { id: 'r2', name: 'RocketMike', color: 'var(--cyan)', speed: 0, distance: 0, topSpeed: 0, position: 2, vehicle: '🏍️' },
    { id: 'r3', name: 'GhostRider_X', color: 'var(--yellow)', speed: 0, distance: 0, topSpeed: 0, position: 3, vehicle: '🚗' },
  ]);
  const [chatMessages, setChatMessages] = useState(CHAT_SEED);
  const [chatInput, setChatInput] = useState('');
  const [spectatorCount, setSpectatorCount] = useState(847);
  const [elapsed, setElapsed] = useState(0);
  const [focusedRacer, setFocusedRacer] = useState(null);
  const chatRef = useRef(null);
  const startRef = useRef(Date.now());

  useEffect(() => {
    startSimulation();
    let t = 0;

    const interval = setInterval(() => {
      t += 0.5;
      setElapsed(Math.floor((Date.now() - startRef.current) / 1000));
      setSpectatorCount(c => c + Math.round((Math.random() - 0.48) * 3));

      setRacers(prev => {
        const updated = prev.map((r, i) => {
          const speed = 55 + Math.sin(t * 0.4 + i * 1.2) * 28 + Math.random() * 8;
          const dist = r.distance + (speed * 0.5 / 3600);
          return { ...r, speed, distance: dist, topSpeed: Math.max(r.topSpeed, speed) };
        });
        // Recalculate positions
        const sorted = [...updated].sort((a, b) => b.distance - a.distance);
        return updated.map(r => ({ ...r, position: sorted.findIndex(s => s.id === r.id) + 1 }));
      });

      // Random auto-chat
      if (Math.random() < 0.15) {
        const msgs = ['LETS GOOO 🔥', 'Who is winning??', '⚡⚡⚡', 'DAISY GT BEST APP', 'Ghost mode is crazy!', 'Top speed??', '🏁🏁🏁', 'Built different', 'That gap!', 'INSANE SPEED'];
        const users = ['SpeedFan_1','Viewer_99','RacerDave','TrackStar','GhostMode','NitroKid','TurboFan'];
        setChatMessages(m => [...m, { user: users[Math.floor(Math.random() * users.length)], text: msgs[Math.floor(Math.random() * msgs.length)], time: Date.now() }].slice(-80));
      }
    }, 500);

    return () => { stopSimulation(); clearInterval(interval); };
  }, []);

  useEffect(() => {
    chatRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [chatMessages]);

  const sendChat = () => {
    if (!chatInput.trim()) return;
    setChatMessages(m => [...m, { user: 'You', text: chatInput, time: Date.now(), isMe: true }]);
    setChatInput('');
  };

  const sendReaction = (r) => {
    setChatMessages(m => [...m, { user: 'You', text: r, time: Date.now(), isMe: true }]);
  };

  const formatTime = (s) => `${String(Math.floor(s / 60)).padStart(2,'0')}:${String(s % 60).padStart(2,'0')}`;

  const leader = racers.find(r => r.position === 1);

  return (
    <div style={{ height: '100vh', background: 'var(--bg-void)', display: 'flex', flexDirection: 'column', overflow: 'hidden', position: 'relative', zIndex: 1 }}>

      {/* ─── Top Bar ─── */}
      <div style={{ background: 'var(--bg-panel)', borderBottom: 'var(--border)', padding: '10px 16px', display: 'flex', alignItems: 'center', gap: 12, flexShrink: 0 }}>
        <Link to="/" style={{ color: 'var(--chrome-dim)', textDecoration: 'none', fontFamily: 'var(--font-display)', fontSize: 11, letterSpacing: '0.06em', textTransform: 'uppercase' }}>← Daisy GT</Link>
        <div style={{ flex: 1, fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: '1rem', letterSpacing: '0.08em', color: 'var(--chrome-bright)', textTransform: 'uppercase' }}>
          <span className="live-dot" style={{ marginRight: 8 }} />
          SPECTATOR MODE — Race #{raceId?.slice(0, 8) || 'DEMO'}
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          <span style={{ fontFamily: 'var(--font-mono)', fontSize: 12, color: 'var(--cyan)' }}>👁️ {spectatorCount.toLocaleString()} watching</span>
          <span className="badge badge-green">FREE</span>
        </div>
      </div>

      {/* ─── Main Content ─── */}
      <div style={{ flex: 1, display: 'grid', gridTemplateColumns: '1fr 300px', minHeight: 0 }}>

        {/* ─── Race View ─── */}
        <div style={{ display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>

          {/* Elapsed + Leader Banner */}
          <div style={{ background: 'rgba(224,0,32,0.08)', borderBottom: '1px solid rgba(224,0,32,0.2)', padding: '8px 16px', display: 'flex', gap: 20, alignItems: 'center', flexShrink: 0 }}>
            <div style={{ fontFamily: 'var(--font-mono)', fontSize: '1.2rem', color: 'var(--red)', fontWeight: 700 }}>{formatTime(elapsed)}</div>
            {leader && (
              <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                <span style={{ fontFamily: 'var(--font-mono)', fontSize: 10, color: 'var(--chrome-dim)', textTransform: 'uppercase' }}>Leading:</span>
                <span style={{ fontFamily: 'var(--font-display)', fontSize: 14, fontWeight: 700, color: leader.color }}>{leader.vehicle} {leader.name}</span>
                <span style={{ fontFamily: 'var(--font-mono)', fontSize: 12, color: leader.color }}>{Math.round(leader.speed)} mph</span>
              </div>
            )}
          </div>

          {/* Racer Cards */}
          <div style={{ flex: 1, padding: 16, display: 'flex', flexDirection: 'column', gap: 10, overflowY: 'auto' }}>
            {[...racers].sort((a, b) => a.position - b.position).map(racer => (
              <div key={racer.id}
                onClick={() => setFocusedRacer(focusedRacer === racer.id ? null : racer.id)}
                style={{ background: focusedRacer === racer.id ? `${racer.color.replace(')', ', 0.08)').replace('var(', 'rgba(').replace('--red','224,0,32').replace('--cyan','0,229,255').replace('--yellow','255,204,0')}` : 'var(--bg-panel)', border: `1px solid ${focusedRacer === racer.id ? racer.color : 'rgba(255,255,255,0.06)'}`, borderRadius: 2, padding: 14, cursor: 'pointer', transition: 'all 0.2s' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 10 }}>
                  <span style={{ fontFamily: 'var(--font-display)', fontSize: '1.4rem', fontWeight: 700, color: racer.position === 1 ? 'var(--yellow)' : 'var(--chrome-dim)', width: 32 }}>P{racer.position}</span>
                  <span style={{ fontSize: 24 }}>{racer.vehicle}</span>
                  <div style={{ flex: 1 }}>
                    <div style={{ fontFamily: 'var(--font-display)', fontSize: 15, fontWeight: 700, color: racer.color, letterSpacing: '0.04em', textTransform: 'uppercase' }}>{racer.name}</div>
                    {racer.position === 1 && <span className="badge badge-yellow">🏆 Leading</span>}
                  </div>
                  <div style={{ textAlign: 'right' }}>
                    <div style={{ fontFamily: 'var(--font-mono)', fontSize: '1.8rem', fontWeight: 700, color: racer.color, lineHeight: 1 }}>{Math.round(racer.speed)}</div>
                    <div style={{ fontFamily: 'var(--font-mono)', fontSize: 10, color: 'var(--chrome-dim)' }}>mph</div>
                  </div>
                </div>
                {/* Speed bar */}
                <div style={{ height: 4, background: 'var(--bg-elevated)', borderRadius: 2, marginBottom: 8 }}>
                  <div style={{ height: '100%', width: `${Math.min(100, (racer.speed / 200) * 100)}%`, background: racer.color, borderRadius: 2, transition: 'width 0.3s', boxShadow: `0 0 8px ${racer.color}` }} />
                </div>
                {/* Stats row */}
                <div style={{ display: 'flex', gap: 20 }}>
                  <div style={{ fontFamily: 'var(--font-mono)', fontSize: 11, color: 'var(--chrome-dim)' }}>Distance: <span style={{ color: 'var(--chrome)' }}>{racer.distance.toFixed(3)} mi</span></div>
                  <div style={{ fontFamily: 'var(--font-mono)', fontSize: 11, color: 'var(--chrome-dim)' }}>Top: <span style={{ color: racer.color }}>{Math.round(racer.topSpeed)} mph</span></div>
                </div>
              </div>
            ))}

            {/* Gap Analysis */}
            <div className="panel" style={{ padding: 14 }}>
              <div style={{ fontFamily: 'var(--font-display)', fontSize: 11, fontWeight: 700, letterSpacing: '0.08em', textTransform: 'uppercase', color: 'var(--chrome-dim)', marginBottom: 10 }}>Gap Analysis</div>
              {racers.sort((a, b) => a.position - b.position).map((r, i, arr) => {
                if (i === 0) return null;
                const gap = ((arr[0].distance - r.distance) * 5280).toFixed(0);
                return (
                  <div key={r.id} style={{ display: 'flex', justifyContent: 'space-between', padding: '4px 0', fontSize: 12 }}>
                    <span style={{ color: r.color, fontFamily: 'var(--font-display)', fontWeight: 600 }}>P{r.position} {r.name}</span>
                    <span style={{ fontFamily: 'var(--font-mono)', color: 'var(--red)' }}>-{gap} ft behind</span>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* ─── Chat Panel ─── */}
        <div style={{ background: 'var(--bg-panel)', borderLeft: 'var(--border)', display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
          <div style={{ padding: '12px 14px', borderBottom: 'var(--border)', display: 'flex', alignItems: 'center', gap: 8 }}>
            <span className="live-dot" />
            <span style={{ fontFamily: 'var(--font-display)', fontSize: 11, fontWeight: 600, letterSpacing: '0.06em', textTransform: 'uppercase', color: 'var(--chrome-dim)' }}>Live Chat</span>
            <span style={{ marginLeft: 'auto', fontFamily: 'var(--font-mono)', fontSize: 10, color: 'var(--chrome-dim)' }}>{spectatorCount.toLocaleString()}</span>
          </div>

          {/* Messages */}
          <div style={{ flex: 1, overflowY: 'auto', padding: 8, display: 'flex', flexDirection: 'column', gap: 3 }}>
            {chatMessages.map((msg, i) => (
              <div key={i} style={{ display: 'flex', gap: 6, padding: '3px 6px', background: msg.isMe ? 'rgba(224,0,32,0.06)' : 'transparent', borderRadius: 1 }}>
                <span style={{ fontFamily: 'var(--font-display)', fontSize: 10, fontWeight: 700, color: msg.isMe ? 'var(--red)' : 'var(--cyan)', minWidth: 70, maxWidth: 70, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', flexShrink: 0 }}>{msg.user}</span>
                <span style={{ fontSize: 12, color: 'var(--chrome)', flex: 1, wordBreak: 'break-word' }}>{msg.text}</span>
              </div>
            ))}
            <div ref={chatRef} />
          </div>

          {/* Reactions */}
          <div style={{ padding: '6px 10px', borderTop: 'var(--border)', display: 'flex', gap: 4, flexWrap: 'wrap' }}>
            {REACTIONS_LIST.map(r => <button key={r} onClick={() => sendReaction(r)} style={{ background: 'none', border: 'none', cursor: 'pointer', fontSize: 16, padding: '2px 3px' }}>{r}</button>)}
          </div>

          {/* Input */}
          <div style={{ padding: '8px 10px', borderTop: 'var(--border)', display: 'flex', gap: 6 }}>
            <input value={chatInput} onChange={e => setChatInput(e.target.value)} onKeyDown={e => e.key === 'Enter' && sendChat()} placeholder="Chat..." style={{ flex: 1, fontSize: 12, padding: '7px 10px' }} />
            <button onClick={sendChat} className="btn btn-primary btn-sm">→</button>
          </div>

          {/* CTA */}
          <div style={{ padding: '10px 12px', borderTop: 'var(--border)', background: 'rgba(224,0,32,0.05)' }}>
            <p style={{ fontSize: 11, color: 'var(--chrome-dim)', marginBottom: 8, lineHeight: 1.5 }}>Want to race? Join Daisy GT free.</p>
            <Link to="/register" className="btn btn-primary btn-sm" style={{ width: '100%', justifyContent: 'center' }}>🏁 Start Racing Free</Link>
          </div>
        </div>
      </div>
    </div>
  );
}
