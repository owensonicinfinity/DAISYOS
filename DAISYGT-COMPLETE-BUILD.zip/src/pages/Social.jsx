import React, { useState, useEffect, useRef } from 'react';
import { api } from '../services/api';
import { useAuthStore } from '../store/authStore';
import toast from 'react-hot-toast';

const REACTIONS = ['🔥','🏎️','💨','⚡','👑','💯','🏁','👻'];

function LiveChat({ roomId }) {
  const { user } = useAuthStore();
  const [messages, setMessages] = useState([
    { id: 1, user: 'TurboQueen', text: 'LETS GOOO 🔥🔥🔥', time: Date.now() - 5000 },
    { id: 2, user: 'RocketMike', text: 'Who tryna run tonight?', time: Date.now() - 3000 },
    { id: 3, user: 'GhostRider_X', text: 'DaisyGT is the wave 👻', time: Date.now() - 1000 },
  ]);
  const [input, setInput] = useState('');
  const endRef = useRef(null);

  useEffect(() => { endRef.current?.scrollIntoView({ behavior: 'smooth' }); }, [messages]);

  const send = () => {
    if (!input.trim()) return;
    setMessages(m => [...m, { id: Date.now(), user: user?.username || 'You', text: input, time: Date.now(), isMe: true }]);
    setInput('');
  };

  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100%', minHeight: 240 }}>
      <div style={{ flex: 1, overflowY: 'auto', padding: '8px 0', display: 'flex', flexDirection: 'column', gap: 4 }}>
        {messages.map(m => (
          <div key={m.id} style={{ display: 'flex', gap: 6, padding: '3px 8px', background: m.isMe ? 'rgba(224,0,32,0.06)' : 'transparent', borderRadius: 2 }}>
            <span style={{ fontFamily: 'var(--font-display)', fontSize: 11, fontWeight: 700, color: m.isMe ? 'var(--red)' : 'var(--cyan)', minWidth: 80, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{m.user}</span>
            <span style={{ fontSize: 12, color: 'var(--chrome)', flex: 1 }}>{m.text}</span>
          </div>
        ))}
        <div ref={endRef} />
      </div>
      <div style={{ padding: '8px 0 0', borderTop: 'var(--border)', display: 'flex', gap: 6 }}>
        <div style={{ display: 'flex', gap: 4, marginBottom: 4 }}>
          {REACTIONS.map(r => <button key={r} onClick={() => { setMessages(m => [...m, { id: Date.now(), user: user?.username || 'You', text: r, time: Date.now(), isMe: true }]); }} style={{ background: 'none', border: 'none', cursor: 'pointer', fontSize: 14, padding: '2px 3px' }}>{r}</button>)}
        </div>
      </div>
      <div style={{ display: 'flex', gap: 6 }}>
        <input value={input} onChange={e => setInput(e.target.value)} onKeyDown={e => e.key === 'Enter' && send()} placeholder="Say something..." style={{ flex: 1, fontSize: 12, padding: '7px 10px' }} />
        <button onClick={send} className="btn btn-primary btn-sm">Send</button>
      </div>
    </div>
  );
}

function PostCard({ post, onLike, onComment }) {
  const { user } = useAuthStore();
  const [showChat, setShowChat] = useState(false);
  const [commentInput, setCommentInput] = useState('');
  const liked = post.likes?.includes(user?.id);

  const submitComment = () => {
    if (!commentInput.trim()) return;
    onComment(post.id, { text: commentInput, username: user?.username, time: new Date().toISOString() });
    setCommentInput('');
  };

  return (
    <div className="panel" style={{ padding: 16, marginBottom: 12 }}>
      {/* Header */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 12 }}>
        <img src={post.avatar || `https://api.dicebear.com/7.x/avataaars/svg?seed=${post.username}`} alt="" style={{ width: 36, height: 36, borderRadius: '50%', border: '1px solid var(--red-dim)' }} />
        <div style={{ flex: 1 }}>
          <div style={{ fontFamily: 'var(--font-display)', fontSize: 13, fontWeight: 700, color: 'var(--chrome-bright)', letterSpacing: '0.04em' }}>{post.username}</div>
          <div style={{ fontSize: 10, color: 'var(--chrome-dim)', fontFamily: 'var(--font-mono)' }}>{new Date(post.createdAt).toLocaleString()}</div>
        </div>
        {post.type === 'race_result' && <span className="badge badge-red">🏁 Race</span>}
        {post.type === 'live' && <span className="badge badge-cyan">LIVE</span>}
      </div>

      {/* Content */}
      <p style={{ fontSize: 14, color: 'var(--chrome)', lineHeight: 1.7, marginBottom: 12 }}>{post.content}</p>

      {/* Race Stats Embed */}
      {post.raceStats && (
        <div style={{ background: 'var(--bg-surface)', border: 'var(--border)', borderRadius: 2, padding: 12, marginBottom: 12, display: 'flex', gap: 16 }}>
          {[
            { label: 'Top Speed', value: `${post.raceStats.topSpeed} mph` },
            { label: '¼ Mile', value: post.raceStats.quarter ? `${post.raceStats.quarter.toFixed(2)}s` : '—' },
            { label: 'Vehicle', value: post.raceStats.vehicle || '—' },
          ].map(s => (
            <div key={s.label} className="stat-box">
              <div className="stat-label">{s.label}</div>
              <div style={{ fontFamily: 'var(--font-mono)', fontSize: '1rem', fontWeight: 700, color: 'var(--red)' }}>{s.value}</div>
            </div>
          ))}
        </div>
      )}

      {/* Actions */}
      <div style={{ display: 'flex', gap: 12, alignItems: 'center', borderTop: 'var(--border)', paddingTop: 10 }}>
        <button onClick={() => onLike(post.id)} style={{ background: 'none', border: 'none', cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 5, color: liked ? 'var(--red)' : 'var(--chrome-dim)', fontSize: 13, fontFamily: 'var(--font-body)', transition: 'color 0.15s' }}>
          ❤️ {post.likes?.length || 0}
        </button>
        <button onClick={() => setShowChat(s => !s)} style={{ background: 'none', border: 'none', cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 5, color: 'var(--chrome-dim)', fontSize: 13, fontFamily: 'var(--font-body)' }}>
          💬 {post.comments?.length || 0}
        </button>
        <button style={{ background: 'none', border: 'none', cursor: 'pointer', color: 'var(--chrome-dim)', fontSize: 13, fontFamily: 'var(--font-body)' }}>
          📤 Share
        </button>
        <button style={{ background: 'none', border: 'none', cursor: 'pointer', color: 'var(--chrome-dim)', fontSize: 13, fontFamily: 'var(--font-body)' }}>
          👻 Ghost Race
        </button>
      </div>

      {/* Comments */}
      {showChat && (
        <div style={{ marginTop: 12, borderTop: 'var(--border)', paddingTop: 12 }}>
          {(post.comments || []).map((c, i) => (
            <div key={i} style={{ display: 'flex', gap: 8, marginBottom: 6 }}>
              <span style={{ fontFamily: 'var(--font-display)', fontSize: 12, fontWeight: 700, color: 'var(--cyan)' }}>{c.username}:</span>
              <span style={{ fontSize: 12, color: 'var(--chrome)' }}>{c.text}</span>
            </div>
          ))}
          <div style={{ display: 'flex', gap: 8, marginTop: 8 }}>
            <input value={commentInput} onChange={e => setCommentInput(e.target.value)} onKeyDown={e => e.key === 'Enter' && submitComment()} placeholder="Add a comment..." style={{ flex: 1, fontSize: 12 }} />
            <button onClick={submitComment} className="btn btn-primary btn-sm">→</button>
          </div>
        </div>
      )}
    </div>
  );
}

export default function Social() {
  const { user } = useAuthStore();
  const [posts, setPosts] = useState([]);
  const [tab, setTab] = useState('feed'); // feed | live | clubs
  const [newPost, setNewPost] = useState('');
  const [posting, setPosting] = useState(false);

  useEffect(() => { api.social.getFeed().then(setPosts); }, []);

  const handlePost = async () => {
    if (!newPost.trim()) return;
    setPosting(true);
    const post = await api.social.createPost({
      userId: user?.id,
      username: user?.username || 'Racer',
      avatar: user?.avatar,
      content: newPost,
      type: 'post',
      likes: [],
      comments: [],
    });
    setPosts(p => [post, ...p]);
    setNewPost('');
    setPosting(false);
    toast.success('Posted! 🏁');
  };

  const handleLike = async (postId) => {
    const updated = await api.social.likePost(postId, user?.id);
    if (updated) setPosts(p => p.map(post => post.id === postId ? updated : post));
  };

  const handleComment = async (postId, comment) => {
    const updated = await api.social.addComment(postId, comment);
    if (updated) setPosts(p => p.map(post => post.id === postId ? updated : post));
  };

  return (
    <div style={{ padding: 16, maxWidth: 720, margin: '0 auto' }}>
      <h2 style={{ marginBottom: 16 }}>SOCIAL <span style={{ color: 'var(--red)' }}>FEED</span></h2>

      {/* ─── Tabs ─── */}
      <div className="tab-bar" style={{ marginBottom: 16 }}>
        {[['feed','Global Feed'],['live','🔴 Live Races'],['clubs','Club Feed']].map(([val, label]) => (
          <button key={val} onClick={() => setTab(val)} className={`tab-btn ${tab === val ? 'active' : ''}`}>{label}</button>
        ))}
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 300px', gap: 16 }}>
        <div>
          {/* ─── Post Composer ─── */}
          <div className="panel" style={{ padding: 14, marginBottom: 16 }}>
            <div style={{ display: 'flex', gap: 10, marginBottom: 10 }}>
              <img src={user?.avatar || `https://api.dicebear.com/7.x/avataaars/svg?seed=${user?.username}`} alt="" style={{ width: 32, height: 32, borderRadius: '50%', border: '1px solid var(--red-dim)' }} />
              <textarea
                value={newPost}
                onChange={e => setNewPost(e.target.value)}
                placeholder="What happened on the track? Share your run... 🏎️"
                rows={3}
                style={{ flex: 1, resize: 'none', fontSize: 13 }}
              />
            </div>
            <div style={{ display: 'flex', gap: 8, justifyContent: 'flex-end' }}>
              <button className="btn btn-ghost btn-sm">📷 Photo</button>
              <button className="btn btn-ghost btn-sm">📊 Race Data</button>
              <button onClick={handlePost} disabled={posting || !newPost.trim()} className="btn btn-primary btn-sm">
                {posting ? 'Posting...' : '🏁 Post'}
              </button>
            </div>
          </div>

          {/* ─── Posts ─── */}
          {posts.length === 0 ? (
            <div style={{ textAlign: 'center', padding: '40px 20px', color: 'var(--chrome-dim)' }}>
              <div style={{ fontSize: 40, marginBottom: 12 }}>📡</div>
              <p>No posts yet. Be the first to share a run!</p>
            </div>
          ) : (
            posts.map(p => <PostCard key={p.id} post={p} onLike={handleLike} onComment={handleComment} />)
          )}
        </div>

        {/* ─── Right Panel: Live Chat ─── */}
        <div>
          <div className="panel" style={{ padding: 14, marginBottom: 12 }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 12 }}>
              <span className="live-dot" />
              <span style={{ fontFamily: 'var(--font-display)', fontSize: 12, fontWeight: 600, letterSpacing: '0.08em', textTransform: 'uppercase', color: 'var(--chrome-dim)' }}>Live Global Chat</span>
            </div>
            <LiveChat roomId="global" />
          </div>

          <div className="panel" style={{ padding: 14 }}>
            <div style={{ fontFamily: 'var(--font-display)', fontSize: 12, fontWeight: 600, letterSpacing: '0.08em', textTransform: 'uppercase', color: 'var(--chrome-dim)', marginBottom: 12 }}>🔥 Trending</div>
            {['#DaisyGT','#GhostRacing','#QuarterMile','#TurboLife','#DaisyOS'].map(tag => (
              <div key={tag} style={{ padding: '6px 0', borderBottom: 'var(--border)', fontSize: 13 }}>
                <span style={{ color: 'var(--red)', fontFamily: 'var(--font-display)', fontWeight: 600, letterSpacing: '0.04em' }}>{tag}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
