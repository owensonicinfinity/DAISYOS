import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { useAuthStore } from '../store/authStore';
import { api } from '../services/api';

export default function Dashboard() {
  const { user, isElite } = useAuthStore();
  const [liveRaces, setLiveRaces] = useState([]);
  const [recentPosts, setRecentPosts] = useState([]);
  const [stats, setStats] = useState(null);
  const [time, setTime] = useState(new Date());
  const elite = isElite();

  useEffect(() => {
    api.races.getLive().then(setLiveRaces);
    api.social.getFeed().then(posts => setRecentPosts(posts.slice(0, 3)));
    if (user?.id) api.profile.getStats(user.id).then(setStats);
    const tick = setInterval(() => setTime(new Date()), 1000);
    return () => clearInterval(tick);
  }, [user]);

  const timeStr = time.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', second: '2-digit' });

  return (
    <div style={{ padding: '16px', maxWidth: 1100, margin: '0 auto' }}>

      {/* ─── HUD Header ─── */}
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 20, flexWrap: 'wrap', gap: 10 }}>
        <div>
          <h1 style={{ fontSize: '1.6rem', color: 'var(--chrome-bright)', marginBottom: 2 }}>
            HQ <span style={{ color: 'var(--red)' }}>DASHBOARD</span>
          </h1>
          <p style={{ fontSize: 11, color: 'var(--chrome-dim)', fontFamily: 'var(--font-mono)' }}>
            Welcome back, {user?.username || 'Racer'}
          </p>
        </div>
        <div style={{ fontFamily: 'var(--font-mono)', fontSize: '1.4rem', color: 'var(--red)', letterSpacing: '0.08em' }}>
          {timeStr}
        </div>
      </div>

      {/* ─── Quick Actions ─── */}
      <div className="grid-4" style={{ marginBottom: 20 }}>
        <Link to="/app/race" className="card" style={{ textDecoration: 'none', textAlign: 'center', padding: '20px 12px', cursor: 'pointer' }}>
          <div style={{ fontSize: 28, marginBottom: 8 }}>🏁</div>
          <div style={{ fontFamily: 'var(--font-display)', fontSize: 12, fontWeight: 600, letterSpacing: '0.06em', textTransform: 'uppercase', color: 'var(--red)' }}>Start Race</div>
        </Link>
        <Link to="/app/dyno" className="card" style={{ textDecoration: 'none', textAlign: 'center', padding: '20px 12px', cursor: 'pointer', opacity: elite ? 1 : 0.6 }}>
          <div style={{ fontSize: 28, marginBottom: 8 }}>📊</div>
          <div style={{ fontFamily: 'var(--font-display)', fontSize: 12, fontWeight: 600, letterSpacing: '0.06em', textTransform: 'uppercase', color: elite ? 'var(--cyan)' : 'var(--chrome-dim)' }}>
            Dyno {!elite && '🔒'}
          </div>
        </Link>
        <Link to="/app/garage" className="card" style={{ textDecoration: 'none', textAlign: 'center', padding: '20px 12px', cursor: 'pointer' }}>
          <div style={{ fontSize: 28, marginBottom: 8 }}>🔧</div>
          <div style={{ fontFamily: 'var(--font-display)', fontSize: 12, fontWeight: 600, letterSpacing: '0.06em', textTransform: 'uppercase', color: 'var(--chrome)' }}>Garage</div>
        </Link>
        <Link to="/app/social" className="card" style={{ textDecoration: 'none', textAlign: 'center', padding: '20px 12px', cursor: 'pointer' }}>
          <div style={{ fontSize: 28, marginBottom: 8 }}>📡</div>
          <div style={{ fontFamily: 'var(--font-display)', fontSize: 12, fontWeight: 600, letterSpacing: '0.06em', textTransform: 'uppercase', color: 'var(--chrome)' }}>Social</div>
        </Link>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16 }}>

        {/* ─── My Stats ─── */}
        <div className="panel" style={{ padding: 16 }}>
          <div style={{ fontFamily: 'var(--font-display)', fontSize: 12, fontWeight: 600, letterSpacing: '0.08em', textTransform: 'uppercase', color: 'var(--chrome-dim)', marginBottom: 14 }}>My Stats</div>
          <div className="grid-3" style={{ gap: 10 }}>
            {[
              { label: 'Races', value: stats?.totalRaces || user?.races || 0 },
              { label: 'Wins', value: stats?.wins || user?.wins || 0 },
              { label: 'Win %', value: `${stats?.winRate || 0}%` },
              { label: 'Best Speed', value: `${stats?.bestSpeed || 0}`, unit: 'mph' },
              { label: 'Distance', value: `${Math.round(stats?.totalDistance || 0)}`, unit: 'mi' },
              { label: 'Level', value: user?.level || 1 },
            ].map(s => (
              <div key={s.label} className="stat-box" style={{ background: 'var(--bg-surface)', padding: '10px 8px', borderRadius: 2 }}>
                <div className="stat-label">{s.label}</div>
                <div className="stat-value" style={{ fontSize: '1.4rem' }}>{s.value}</div>
                {s.unit && <div className="stat-unit">{s.unit}</div>}
              </div>
            ))}
          </div>
          <div style={{ marginTop: 12 }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 4 }}>
              <span style={{ fontFamily: 'var(--font-mono)', fontSize: 10, color: 'var(--chrome-dim)' }}>XP PROGRESS</span>
              <span style={{ fontFamily: 'var(--font-mono)', fontSize: 10, color: 'var(--red)' }}>{user?.xp || 0} / {((user?.level || 1) * 500)}</span>
            </div>
            <div style={{ height: 4, background: 'var(--bg-elevated)', borderRadius: 2 }}>
              <div style={{ height: '100%', background: 'var(--red)', borderRadius: 2, width: `${Math.min(100, ((user?.xp || 0) % 500) / 5)}%`, transition: 'width 0.3s' }} />
            </div>
          </div>
        </div>

        {/* ─── Live Races ─── */}
        <div className="panel" style={{ padding: 16 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 14 }}>
            <span className="live-dot" />
            <span style={{ fontFamily: 'var(--font-display)', fontSize: 12, fontWeight: 600, letterSpacing: '0.08em', textTransform: 'uppercase', color: 'var(--chrome-dim)' }}>Live Races</span>
          </div>
          {liveRaces.length === 0 ? (
            <div style={{ textAlign: 'center', padding: '30px 0', color: 'var(--chrome-dim)', fontSize: 13 }}>
              <div style={{ fontSize: 32, marginBottom: 8 }}>🏁</div>
              No live races right now
              <br />
              <Link to="/app/race" style={{ color: 'var(--red)', fontSize: 12, textDecoration: 'none', marginTop: 8, display: 'inline-block' }}>Start one →</Link>
            </div>
          ) : (
            liveRaces.map(r => (
              <div key={r.id} style={{ padding: '10px 0', borderBottom: 'var(--border)', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                <div>
                  <div style={{ fontFamily: 'var(--font-display)', fontSize: 13, color: 'var(--chrome)' }}>{r.name || 'Race'}</div>
                  <div style={{ fontSize: 11, color: 'var(--chrome-dim)' }}>{r.type} · {r.racers?.length || 0} racers</div>
                </div>
                <Link to={`/spectator/${r.id}`} className="btn btn-cyan btn-sm">Watch</Link>
              </div>
            ))
          )}
        </div>

        {/* ─── Social Feed Preview ─── */}
        <div className="panel" style={{ padding: 16 }}>
          <div style={{ fontFamily: 'var(--font-display)', fontSize: 12, fontWeight: 600, letterSpacing: '0.08em', textTransform: 'uppercase', color: 'var(--chrome-dim)', marginBottom: 14 }}>Social Feed</div>
          {recentPosts.map(p => (
            <div key={p.id} style={{ paddingBottom: 12, marginBottom: 12, borderBottom: 'var(--border)' }}>
              <div style={{ display: 'flex', gap: 8, marginBottom: 6 }}>
                <img src={p.avatar} alt="" style={{ width: 24, height: 24, borderRadius: '50%', border: '1px solid var(--red-dim)' }} />
                <span style={{ fontFamily: 'var(--font-display)', fontSize: 12, fontWeight: 600, color: 'var(--chrome)' }}>{p.username}</span>
                <span style={{ fontSize: 10, color: 'var(--chrome-dim)', marginLeft: 'auto' }}>{new Date(p.createdAt).toLocaleTimeString()}</span>
              </div>
              <p style={{ fontSize: 12, color: 'var(--chrome)', lineHeight: 1.5 }}>{p.content}</p>
              <div style={{ display: 'flex', gap: 12, marginTop: 6, fontSize: 11, color: 'var(--chrome-dim)' }}>
                <span>❤️ {p.likes?.length || 0}</span>
                <span>💬 {p.comments?.length || 0}</span>
              </div>
            </div>
          ))}
          <Link to="/app/social" style={{ fontSize: 12, color: 'var(--red)', textDecoration: 'none' }}>View full feed →</Link>
        </div>

        {/* ─── Quick Links ─── */}
        <div className="panel" style={{ padding: 16 }}>
          <div style={{ fontFamily: 'var(--font-display)', fontSize: 12, fontWeight: 600, letterSpacing: '0.08em', textTransform: 'uppercase', color: 'var(--chrome-dim)', marginBottom: 14 }}>Quick Access</div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 4 }}>
            {[
              { to: '/app/leaderboards', icon: '🏆', label: 'Global Leaderboards', color: 'var(--yellow)' },
              { to: '/app/clubs', icon: '🔗', label: 'Racing Clubs', color: 'var(--chrome)' },
              { to: '/app/marketplace', icon: '💎', label: 'Race NFT Marketplace', color: 'var(--cyan)' },
              { to: '/app/analytics', icon: '📈', label: 'Race Analytics', color: 'var(--green)' },
              { to: '/app/training', icon: '💪', label: 'Training Hub', color: 'var(--red)' },
              { to: '/app/hunting', icon: '🎯', label: 'DaisyAI Hunting', color: 'var(--orange)' },
              { to: '/app/sports', icon: '⚽', label: 'Live Sports', color: 'var(--chrome)' },
            ].map(item => (
              <Link key={item.to} to={item.to} style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '8px 10px', background: 'var(--bg-surface)', borderRadius: 2, textDecoration: 'none', color: 'var(--chrome)', fontSize: 13, border: 'var(--border)', transition: 'border-color 0.15s' }}
                onMouseEnter={e => e.currentTarget.style.borderColor = 'rgba(224,0,32,0.3)'}
                onMouseLeave={e => e.currentTarget.style.borderColor = 'rgba(255,255,255,0.06)'}>
                <span>{item.icon}</span>
                <span style={{ fontFamily: 'var(--font-display)', fontSize: 12, fontWeight: 600, letterSpacing: '0.04em', textTransform: 'uppercase', color: item.color }}>{item.label}</span>
                <span style={{ marginLeft: 'auto', color: 'var(--chrome-dim)' }}>›</span>
              </Link>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
