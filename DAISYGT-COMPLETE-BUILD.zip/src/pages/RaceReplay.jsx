import React, { useState, useEffect, useRef } from 'react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, ReferenceLine } from 'recharts';
import { replayAPI, api } from '../services/api';
import { useAuthStore } from '../store/authStore';
import { Link } from 'react-router-dom';

// Generate a realistic demo replay dataset
function generateReplay(name, topSpeed, duration) {
  const points = [];
  let dist = 0;
  for (let t = 0; t <= duration; t += 0.5) {
    const speed = Math.min(topSpeed, (topSpeed * (1 - Math.exp(-t / 8))) + Math.sin(t * 0.4) * 8 + Math.random() * 4);
    dist += (speed * 0.5) / 3600;
    points.push({
      t: parseFloat(t.toFixed(1)),
      speed: Math.round(Math.max(0, speed)),
      dist: parseFloat(dist.toFixed(4)),
      gForce: parseFloat((Math.abs(Math.sin(t * 0.3)) * 0.8 + Math.random() * 0.2).toFixed(2)),
      throttle: Math.round(Math.min(100, speed / topSpeed * 100 + Math.random() * 10)),
    });
  }
  return { name, topSpeed: Math.round(topSpeed), duration, points, quarterMile: points.find(p => p.dist >= 0.25)?.t };
}

const DEMO_REPLAYS = [
  { id: 'r1', name: '10.8s Quarter Mile — Personal Best', date: '2025-05-30', vehicle: 'Dodge Challenger SRT', ...generateReplay('TurboQueen', 162, 35) },
  { id: 'r2', name: '0-60 Launch Test', date: '2025-05-28', vehicle: 'Ford Mustang GT500', ...generateReplay('RocketMike', 145, 20) },
  { id: 'r3', name: 'Full Mile Sprint', date: '2025-05-25', vehicle: 'Chevrolet Camaro ZL1', ...generateReplay('NightRunner', 178, 55) },
];

export default function RaceReplay() {
  const { user } = useAuthStore();
  const [replays, setReplays] = useState(DEMO_REPLAYS);
  const [selected, setSelected] = useState(null);
  const [playing, setPlaying] = useState(false);
  const [playhead, setPlayhead] = useState(0);
  const [speed, setSpeed] = useState(1); // playback speed multiplier
  const [compareMode, setCompareMode] = useState(false);
  const [compareReplay, setCompareReplay] = useState(null);
  const intervalRef = useRef(null);

  useEffect(() => {
    if (user?.id) replayAPI.getAll(user.id).then(saved => {
      if (saved.length) setReplays(prev => [...saved, ...prev]);
    });
  }, [user]);

  const play = () => {
    if (!selected) return;
    setPlaying(true);
    intervalRef.current = setInterval(() => {
      setPlayhead(p => {
        const next = p + (0.5 * speed);
        if (next >= selected.duration) { clearInterval(intervalRef.current); setPlaying(false); return selected.duration; }
        return parseFloat(next.toFixed(1));
      });
    }, 250);
  };

  const pause = () => { setPlaying(false); clearInterval(intervalRef.current); };
  const reset = () => { pause(); setPlayhead(0); };

  useEffect(() => () => clearInterval(intervalRef.current), []);

  const currentPoint = selected?.points?.find(p => p.t >= playhead) || selected?.points?.[selected.points.length - 1];
  const comparePoint = compareReplay?.points?.find(p => p.t >= playhead) || compareReplay?.points?.[compareReplay.points.length - 1];

  const chartData = selected?.points?.map(p => {
    const cp = compareReplay?.points?.find(cp2 => cp2.t === p.t);
    return { ...p, compareSpeed: cp?.speed, compareDist: cp?.dist };
  });

  return (
    <div style={{ padding: 16, maxWidth: 1000, margin: '0 auto' }}>
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 20 }}>
        <div>
          <h2>RACE <span style={{ color: 'var(--cyan)' }}>REPLAY</span></h2>
          <p style={{ fontSize: 11, fontFamily: 'var(--font-mono)', color: 'var(--chrome-dim)' }}>Full run playback · Ghost comparison · Data overlay</p>
        </div>
        <Link to="/app/race" className="btn btn-ghost btn-sm">← Race</Link>
      </div>

      <div className="grid-2" style={{ gap: 16, alignItems: 'start' }}>
        {/* Replay List */}
        <div>
          <div style={{ fontFamily: 'var(--font-display)', fontSize: 11, fontWeight: 600, letterSpacing: '0.08em', textTransform: 'uppercase', color: 'var(--chrome-dim)', marginBottom: 10 }}>Saved Runs</div>
          {replays.map(r => (
            <div key={r.id} style={{ marginBottom: 8 }}>
              <div
                onClick={() => { setSelected(r); reset(); setCompareReplay(null); }}
                style={{ background: selected?.id === r.id ? 'rgba(224,0,32,0.08)' : 'var(--bg-panel)', border: selected?.id === r.id ? 'var(--border-red)' : 'var(--border)', borderRadius: 2, padding: '12px 14px', cursor: 'pointer', transition: 'all 0.15s' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 6 }}>
                  <div style={{ fontFamily: 'var(--font-display)', fontSize: 13, fontWeight: 700, color: selected?.id === r.id ? 'var(--red)' : 'var(--chrome-bright)', letterSpacing: '0.02em', textTransform: 'uppercase' }}>{r.name}</div>
                  <span style={{ fontFamily: 'var(--font-mono)', fontSize: 10, color: 'var(--chrome-dim)' }}>{r.date}</span>
                </div>
                <div style={{ fontSize: 12, color: 'var(--chrome-dim)', marginBottom: 8 }}>{r.vehicle}</div>
                <div style={{ display: 'flex', gap: 12 }}>
                  <span style={{ fontFamily: 'var(--font-mono)', fontSize: 11, color: 'var(--red)' }}>🏎️ {r.topSpeed} mph</span>
                  {r.quarterMile && <span style={{ fontFamily: 'var(--font-mono)', fontSize: 11, color: 'var(--yellow)' }}>⏱ {r.quarterMile}s ¼ mile</span>}
                  <span style={{ fontFamily: 'var(--font-mono)', fontSize: 11, color: 'var(--chrome-dim)' }}>{r.duration}s run</span>
                </div>
              </div>
              {selected?.id === r.id && compareMode && (
                <div style={{ padding: '8px 12px', background: 'var(--bg-surface)', border: 'var(--border)', borderTop: 'none', borderRadius: '0 0 2px 2px' }}>
                  <div style={{ fontSize: 11, color: 'var(--chrome-dim)', marginBottom: 6 }}>Compare with:</div>
                  {replays.filter(rr => rr.id !== r.id).map(rr => (
                    <button key={rr.id} onClick={() => setCompareReplay(compareReplay?.id === rr.id ? null : rr)}
                      style={{ display: 'block', width: '100%', textAlign: 'left', background: compareReplay?.id === rr.id ? 'rgba(0,229,255,0.1)' : 'transparent', border: compareReplay?.id === rr.id ? 'var(--border-cyan)' : 'var(--border)', borderRadius: 2, padding: '6px 10px', cursor: 'pointer', marginBottom: 4, fontSize: 11, color: compareReplay?.id === rr.id ? 'var(--cyan)' : 'var(--chrome-dim)', fontFamily: 'var(--font-display)' }}>
                      {rr.name}
                    </button>
                  ))}
                </div>
              )}
            </div>
          ))}
        </div>

        {/* Playback Panel */}
        <div>
          {selected ? (
            <>
              {/* Live readout */}
              <div className="panel" style={{ padding: 14, marginBottom: 12 }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 }}>
                  <span style={{ fontFamily: 'var(--font-display)', fontSize: 11, fontWeight: 700, letterSpacing: '0.08em', textTransform: 'uppercase', color: 'var(--chrome-dim)' }}>Live Readout</span>
                  <div style={{ display: 'flex', gap: 4 }}>
                    {[0.5, 1, 2, 4].map(s => (
                      <button key={s} onClick={() => setSpeed(s)}
                        style={{ fontFamily: 'var(--font-mono)', fontSize: 10, padding: '3px 7px', background: speed === s ? 'var(--red)' : 'var(--bg-surface)', border: 'var(--border)', borderRadius: 1, cursor: 'pointer', color: speed === s ? '#fff' : 'var(--chrome-dim)' }}>
                        {s}x
                      </button>
                    ))}
                  </div>
                </div>

                <div className="grid-2" style={{ gap: 8, marginBottom: 12 }}>
                  {[
                    { label: 'Speed', value: currentPoint?.speed || 0, unit: 'mph', color: 'var(--red)' },
                    { label: 'Distance', value: currentPoint?.dist?.toFixed(3) || '0.000', unit: 'mi', color: 'var(--cyan)' },
                    { label: 'G-Force', value: currentPoint?.gForce || '0.00', unit: 'g', color: 'var(--yellow)' },
                    { label: 'Throttle', value: currentPoint?.throttle || 0, unit: '%', color: 'var(--green)' },
                  ].map(s => (
                    <div key={s.label} className="stat-box" style={{ background: 'var(--bg-surface)', padding: 10, textAlign: 'center' }}>
                      <div className="stat-label">{s.label}</div>
                      <div style={{ fontFamily: 'var(--font-mono)', fontSize: '1.3rem', fontWeight: 700, color: s.color }}>{s.value}</div>
                      <div className="stat-unit">{s.unit}</div>
                    </div>
                  ))}
                </div>

                {compareReplay && comparePoint && (
                  <div style={{ background: 'rgba(0,229,255,0.05)', border: 'var(--border-cyan)', borderRadius: 2, padding: '8px 12px', marginBottom: 12 }}>
                    <div style={{ fontSize: 10, color: 'var(--cyan)', fontFamily: 'var(--font-mono)', marginBottom: 4 }}>GHOST: {compareReplay.name}</div>
                    <div style={{ display: 'flex', gap: 16 }}>
                      <span style={{ fontFamily: 'var(--font-mono)', fontSize: 12, color: 'var(--cyan)' }}>{comparePoint.speed} mph</span>
                      <span style={{ fontFamily: 'var(--font-mono)', fontSize: 12, color: currentPoint?.speed > comparePoint.speed ? 'var(--green)' : 'var(--red)' }}>
                        {currentPoint?.speed > comparePoint.speed ? '▲' : '▼'} {Math.abs((currentPoint?.speed || 0) - comparePoint.speed)} mph gap
                      </span>
                    </div>
                  </div>
                )}

                {/* Playhead scrubber */}
                <div style={{ marginBottom: 10 }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 4 }}>
                    <span style={{ fontFamily: 'var(--font-mono)', fontSize: 10, color: 'var(--chrome-dim)' }}>{playhead.toFixed(1)}s</span>
                    <span style={{ fontFamily: 'var(--font-mono)', fontSize: 10, color: 'var(--chrome-dim)' }}>{selected.duration}s</span>
                  </div>
                  <input type="range" min={0} max={selected.duration} step={0.5} value={playhead}
                    onChange={e => { pause(); setPlayhead(parseFloat(e.target.value)); }}
                    style={{ width: '100%', accentColor: 'var(--red)', cursor: 'pointer' }} />
                </div>

                {/* Controls */}
                <div style={{ display: 'flex', gap: 8, justifyContent: 'center' }}>
                  <button onClick={reset} className="btn btn-ghost btn-sm">⏮ Reset</button>
                  {playing
                    ? <button onClick={pause} className="btn btn-primary btn-sm">⏸ Pause</button>
                    : <button onClick={play} className="btn btn-primary btn-sm">▶ Play</button>}
                  <button onClick={() => setCompareMode(m => !m)} className={`btn btn-sm ${compareMode ? 'btn-cyan' : 'btn-ghost'}`}>👻 Compare</button>
                </div>
              </div>

              {/* Speed chart with playhead */}
              <div className="panel" style={{ padding: 14 }}>
                <div style={{ fontFamily: 'var(--font-display)', fontSize: 11, fontWeight: 600, letterSpacing: '0.08em', textTransform: 'uppercase', color: 'var(--chrome-dim)', marginBottom: 10 }}>Speed Trace</div>
                <ResponsiveContainer width="100%" height={160}>
                  <LineChart data={chartData}>
                    <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.04)" />
                    <XAxis dataKey="t" stroke="rgba(255,255,255,0.15)" tick={{ fontSize: 8, fontFamily: 'JetBrains Mono' }} />
                    <YAxis stroke="rgba(255,255,255,0.15)" tick={{ fontSize: 8, fontFamily: 'JetBrains Mono' }} />
                    <Tooltip contentStyle={{ background: 'var(--bg-panel)', border: '1px solid rgba(224,0,32,0.3)', fontFamily: 'JetBrains Mono', fontSize: 10 }} />
                    <ReferenceLine x={playhead} stroke="rgba(255,255,255,0.4)" strokeWidth={2} strokeDasharray="4 2" />
                    <Line type="monotone" dataKey="speed" stroke="var(--red)" strokeWidth={2} dot={false} name={selected.name} />
                    {compareReplay && <Line type="monotone" dataKey="compareSpeed" stroke="var(--cyan)" strokeWidth={1.5} dot={false} strokeDasharray="5 3" name={compareReplay.name} />}
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </>
          ) : (
            <div style={{ textAlign: 'center', padding: '60px 20px', background: 'var(--bg-panel)', border: 'var(--border)', borderRadius: 2 }}>
              <div style={{ fontSize: 48, marginBottom: 12 }}>🎬</div>
              <h3 style={{ color: 'var(--chrome-dim)', marginBottom: 8 }}>Select a Run</h3>
              <p style={{ fontSize: 13, color: 'var(--chrome-dim)' }}>Choose a saved run from the list to play it back.</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
