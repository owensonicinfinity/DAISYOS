import React, { useState, useEffect } from 'react';
import { api } from '../services/api';
import { useAuthStore } from '../store/authStore';
import { getHuntingAdvice } from '../services/gemini';
import toast from 'react-hot-toast';

const ANIMALS = ['Whitetail Deer', 'Elk', 'Bear', 'Turkey', 'Duck', 'Pheasant', 'Wild Boar', 'Moose', 'Antelope', 'Rabbit', 'Quail', 'Coyote', 'Fox', 'Goose', 'Dove', 'Other'];
const STATES = ['Alabama','Alaska','Arizona','Arkansas','California','Colorado','Connecticut','Delaware','Florida','Georgia','Hawaii','Idaho','Illinois','Indiana','Iowa','Kansas','Kentucky','Louisiana','Maine','Maryland','Massachusetts','Michigan','Minnesota','Mississippi','Missouri','Montana','Nebraska','Nevada','New Hampshire','New Jersey','New Mexico','New York','North Carolina','North Dakota','Ohio','Oklahoma','Oregon','Pennsylvania','Rhode Island','South Carolina','South Dakota','Tennessee','Texas','Utah','Vermont','Virginia','Washington','West Virginia','Wisconsin','Wyoming'];
const WEATHER_CONDITIONS = ['Clear & Sunny', 'Partly Cloudy', 'Overcast', 'Light Rain', 'Heavy Rain', 'Foggy', 'Windy', 'Cold Front', 'Warm Front', 'Snow'];
const WIND_DIRS = ['N', 'NE', 'E', 'SE', 'S', 'SW', 'W', 'NW'];
const TERRAIN = ['Hardwood Forest', 'Pine Forest', 'Open Field', 'Marsh/Wetland', 'Mountain', 'Prairie', 'River Bottom', 'Scrub/Brush', 'Food Plot', 'Clear Cut'];

const MOON_PHASES = [
  { phase: 'New Moon', icon: '🌑', activity: 95 },
  { phase: 'Waxing Crescent', icon: '🌒', activity: 78 },
  { phase: 'First Quarter', icon: '🌓', activity: 82 },
  { phase: 'Waxing Gibbous', icon: '🌔', activity: 71 },
  { phase: 'Full Moon', icon: '🌕', activity: 55 },
  { phase: 'Waning Gibbous', icon: '🌖', activity: 68 },
  { phase: 'Last Quarter', icon: '🌗', activity: 80 },
  { phase: 'Waning Crescent', icon: '🌘', activity: 88 },
];

const currentMoon = MOON_PHASES[2]; // First Quarter demo

export default function Hunting() {
  const { user } = useAuthStore();
  const [tab, setTab] = useState('advisor');
  const [conditions, setConditions] = useState({ animal: 'Whitetail Deer', state: 'Texas', weather: 'Partly Cloudy', wind: 'NW', temp: '58', terrain: 'Hardwood Forest', timeOfDay: 'Morning', season: 'Rut' });
  const [advice, setAdvice] = useState('');
  const [loading, setLoading] = useState(false);
  const [trips, setTrips] = useState([]);
  const [tripForm, setTripForm] = useState({ animal: 'Whitetail Deer', state: 'Texas', date: '', location: '', result: 'scouting', notes: '', weight: '', points: '', distance: '' });
  const [loggingTrip, setLoggingTrip] = useState(false);
  const [leaderboard, setLeaderboard] = useState([]);
  const [showTripModal, setShowTripModal] = useState(false);

  useEffect(() => {
    if (user?.id) {
      api.hunting.getTrips(user.id).then(setTrips);
      api.hunting.getLeaderboard().then(setLeaderboard);
    }
  }, [user]);

  const setC = (k, v) => setConditions(c => ({ ...c, [k]: v }));
  const setT = (k, v) => setTripForm(f => ({ ...f, [k]: v }));

  const getAdvice = async () => {
    setLoading(true);
    setAdvice('');
    try {
      const result = await getHuntingAdvice(conditions);
      setAdvice(result);
    } catch {
      setAdvice('Unable to connect to DaisyAI right now. Check your connection and try again.');
    }
    setLoading(false);
  };

  const logTrip = async () => {
    if (!tripForm.date || !tripForm.animal) { toast.error('Fill in date and animal'); return; }
    setLoggingTrip(true);
    await api.hunting.logTrip({ ...tripForm, userId: user?.id });
    if (tripForm.result === 'harvest') {
      await api.hunting.logHarvest({ ...tripForm, userId: user?.id });
    }
    setTrips(t => [{ ...tripForm, userId: user?.id, id: `trip_${Date.now()}`, createdAt: new Date().toISOString() }, ...t]);
    setShowTripModal(false);
    setTripForm({ animal: 'Whitetail Deer', state: 'Texas', date: '', location: '', result: 'scouting', notes: '', weight: '', points: '', distance: '' });
    toast.success(tripForm.result === 'harvest' ? '🎯 Harvest logged! Great hunt!' : '🌲 Trip logged!');
    setLoggingTrip(false);
    api.hunting.getLeaderboard().then(setLeaderboard);
  };

  const activityScore = () => {
    let score = currentMoon.activity;
    if (conditions.weather === 'Clear & Sunny') score -= 5;
    if (conditions.weather === 'Overcast') score += 8;
    if (conditions.weather === 'Cold Front') score += 15;
    if (conditions.wind === 'NW' || conditions.wind === 'N') score += 5;
    if (conditions.timeOfDay === 'Morning' || conditions.timeOfDay === 'Evening') score += 10;
    if (conditions.season === 'Rut') score += 20;
    return Math.min(100, Math.max(0, score));
  };

  const activity = activityScore();
  const activityColor = activity >= 80 ? 'var(--green)' : activity >= 60 ? 'var(--yellow)' : 'var(--red)';

  return (
    <div style={{ padding: 16, maxWidth: 1000, margin: '0 auto' }}>
      <div style={{ marginBottom: 20 }}>
        <h2>DAISYAI <span style={{ color: 'var(--red)' }}>HUNTING</span></h2>
        <p style={{ fontSize: 12, color: 'var(--chrome-dim)', marginTop: 4 }}>AI-powered hunting guide · Weather · Moon Phase · Terrain Analysis</p>
      </div>

      <div className="tab-bar" style={{ marginBottom: 20 }}>
        {[['advisor','🎯 AI Advisor'],['conditions','🌤 Conditions'],['trips','📋 Trip Log'],['leaderboard','🏆 Harvests'],['gear','🔧 Gear']].map(([val, label]) => (
          <button key={val} onClick={() => setTab(val)} className={`tab-btn ${tab === val ? 'active' : ''}`}>{label}</button>
        ))}
      </div>

      {tab === 'advisor' && (
        <div className="grid-2" style={{ gap: 16, alignItems: 'start' }}>
          {/* Conditions Form */}
          <div className="panel" style={{ padding: 20 }}>
            <div style={{ fontFamily: 'var(--font-display)', fontSize: 13, fontWeight: 700, letterSpacing: '0.08em', textTransform: 'uppercase', color: 'var(--chrome-bright)', marginBottom: 16 }}>Hunt Setup</div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
              <div><label>Target Animal</label>
                <select value={conditions.animal} onChange={e => setC('animal', e.target.value)}>
                  {ANIMALS.map(a => <option key={a}>{a}</option>)}
                </select>
              </div>
              <div className="grid-2">
                <div><label>State</label>
                  <select value={conditions.state} onChange={e => setC('state', e.target.value)}>
                    {STATES.map(s => <option key={s}>{s}</option>)}
                  </select>
                </div>
                <div><label>Season</label>
                  <select value={conditions.season} onChange={e => setC('season', e.target.value)}>
                    {['Pre-Rut','Rut','Post-Rut','Early Season','Late Season','Spring','Summer'].map(s => <option key={s}>{s}</option>)}
                  </select>
                </div>
              </div>
              <div className="grid-2">
                <div><label>Weather</label>
                  <select value={conditions.weather} onChange={e => setC('weather', e.target.value)}>
                    {WEATHER_CONDITIONS.map(w => <option key={w}>{w}</option>)}
                  </select>
                </div>
                <div><label>Temperature (°F)</label>
                  <input type="number" value={conditions.temp} onChange={e => setC('temp', e.target.value)} placeholder="58" />
                </div>
              </div>
              <div className="grid-2">
                <div><label>Wind Direction</label>
                  <select value={conditions.wind} onChange={e => setC('wind', e.target.value)}>
                    {WIND_DIRS.map(w => <option key={w}>{w}</option>)}
                  </select>
                </div>
                <div><label>Time of Day</label>
                  <select value={conditions.timeOfDay} onChange={e => setC('timeOfDay', e.target.value)}>
                    {['Pre-Dawn','Morning','Mid-Morning','Midday','Afternoon','Evening','Dusk','Night'].map(t => <option key={t}>{t}</option>)}
                  </select>
                </div>
              </div>
              <div><label>Terrain</label>
                <select value={conditions.terrain} onChange={e => setC('terrain', e.target.value)}>
                  {TERRAIN.map(t => <option key={t}>{t}</option>)}
                </select>
              </div>
              <button onClick={getAdvice} disabled={loading} className="btn btn-primary" style={{ width: '100%', justifyContent: 'center', marginTop: 4 }}>
                {loading ? '🎯 Analyzing...' : '🎯 Get DaisyAI Advice'}
              </button>
            </div>
          </div>

          {/* Right Panel */}
          <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
            {/* Activity Score */}
            <div className="panel" style={{ padding: 16 }}>
              <div style={{ fontFamily: 'var(--font-display)', fontSize: 12, fontWeight: 700, letterSpacing: '0.08em', textTransform: 'uppercase', color: 'var(--chrome-dim)', marginBottom: 12 }}>Hunt Activity Score</div>
              <div style={{ textAlign: 'center' }}>
                <div style={{ fontFamily: 'var(--font-mono)', fontSize: '3rem', fontWeight: 700, color: activityColor, lineHeight: 1 }}>{activity}</div>
                <div style={{ fontFamily: 'var(--font-mono)', fontSize: 11, color: 'var(--chrome-dim)', marginBottom: 12 }}>/100 — {activity >= 80 ? 'EXCELLENT' : activity >= 60 ? 'GOOD' : 'FAIR'} CONDITIONS</div>
                <div style={{ height: 6, background: 'var(--bg-elevated)', borderRadius: 3 }}>
                  <div style={{ height: '100%', width: `${activity}%`, background: activityColor, borderRadius: 3, boxShadow: `0 0 10px ${activityColor}`, transition: 'width 0.5s' }} />
                </div>
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-around', marginTop: 16 }}>
                <div style={{ textAlign: 'center' }}>
                  <div style={{ fontSize: 24 }}>{currentMoon.icon}</div>
                  <div style={{ fontFamily: 'var(--font-mono)', fontSize: 9, color: 'var(--chrome-dim)', marginTop: 4 }}>{currentMoon.phase}</div>
                  <div style={{ fontFamily: 'var(--font-mono)', fontSize: 11, color: 'var(--cyan)', fontWeight: 700 }}>{currentMoon.activity}%</div>
                </div>
                <div style={{ textAlign: 'center' }}>
                  <div style={{ fontFamily: 'var(--font-mono)', fontSize: '1.2rem', color: 'var(--chrome)' }}>{conditions.temp}°F</div>
                  <div style={{ fontFamily: 'var(--font-mono)', fontSize: 9, color: 'var(--chrome-dim)', marginTop: 4 }}>TEMP</div>
                </div>
                <div style={{ textAlign: 'center' }}>
                  <div style={{ fontFamily: 'var(--font-mono)', fontSize: '1.2rem', color: 'var(--chrome)' }}>{conditions.wind}</div>
                  <div style={{ fontFamily: 'var(--font-mono)', fontSize: 9, color: 'var(--chrome-dim)', marginTop: 4 }}>WIND DIR</div>
                </div>
              </div>
            </div>

            {/* AI Answer */}
            {loading && (
              <div style={{ background: 'var(--bg-panel)', border: 'var(--border)', borderRadius: 2, padding: 16, display: 'flex', gap: 12, alignItems: 'center' }}>
                <div className="loading-spinner" style={{ width: 20, height: 20 }} />
                <span style={{ fontSize: 12, color: 'var(--chrome-dim)' }}>DaisyAI analyzing conditions...</span>
              </div>
            )}
            {advice && (
              <div style={{ background: 'rgba(0,255,136,0.04)', border: '1px solid rgba(0,255,136,0.2)', borderRadius: 2, padding: 16 }}>
                <div style={{ fontFamily: 'var(--font-display)', fontSize: 11, fontWeight: 600, letterSpacing: '0.08em', textTransform: 'uppercase', color: 'var(--green)', marginBottom: 8 }}>🎯 DaisyAI Hunt Guide</div>
                <p style={{ fontSize: 13, lineHeight: 1.8, color: 'var(--chrome)' }}>{advice}</p>
              </div>
            )}

            {/* Quick Tips */}
            <div className="panel" style={{ padding: 14 }}>
              <div style={{ fontFamily: 'var(--font-display)', fontSize: 12, fontWeight: 600, letterSpacing: '0.08em', textTransform: 'uppercase', color: 'var(--chrome-dim)', marginBottom: 10 }}>Quick Tips</div>
              {[
                conditions.season === 'Rut' ? '🦌 Rut is active — use grunt calls and rattling antlers' : '🌲 Concentrate near food sources during this season',
                conditions.wind === 'NW' || conditions.wind === 'N' ? '💨 Cold NW wind — deer will be moving heavily' : '💨 Check wind direction before setup',
                parseInt(conditions.temp) < 45 ? '🌡️ Cold temps increase deer movement significantly' : '☀️ Warm temps slow midday movement — focus dawn/dusk',
                conditions.terrain === 'Hardwood Forest' ? '🌰 Hardwoods dropping acorns — set up near fresh scrapes' : '🏔️ Use terrain features to funnel deer movement',
              ].map((tip, i) => (
                <div key={i} style={{ fontSize: 12, color: 'var(--chrome)', lineHeight: 1.6, padding: '6px 0', borderBottom: 'var(--border)' }}>{tip}</div>
              ))}
            </div>
          </div>
        </div>
      )}

      {tab === 'conditions' && (
        <div className="grid-2" style={{ gap: 16 }}>
          {/* Moon Calendar */}
          <div className="panel" style={{ padding: 16 }}>
            <div style={{ fontFamily: 'var(--font-display)', fontSize: 13, fontWeight: 700, letterSpacing: '0.08em', textTransform: 'uppercase', color: 'var(--chrome-bright)', marginBottom: 16 }}>Moon Phase Calendar</div>
            <div className="grid-2" style={{ gap: 8 }}>
              {MOON_PHASES.map(m => (
                <div key={m.phase} style={{ background: m.phase === currentMoon.phase ? 'rgba(0,229,255,0.08)' : 'var(--bg-surface)', border: m.phase === currentMoon.phase ? 'var(--border-cyan)' : 'var(--border)', borderRadius: 2, padding: 10, textAlign: 'center' }}>
                  <div style={{ fontSize: 24, marginBottom: 4 }}>{m.icon}</div>
                  <div style={{ fontFamily: 'var(--font-mono)', fontSize: 9, color: 'var(--chrome-dim)', marginBottom: 4 }}>{m.phase}</div>
                  <div style={{ fontFamily: 'var(--font-mono)', fontSize: '1rem', fontWeight: 700, color: m.activity >= 80 ? 'var(--green)' : m.activity >= 65 ? 'var(--yellow)' : 'var(--red)' }}>{m.activity}%</div>
                </div>
              ))}
            </div>
          </div>

          {/* Seasonal Rut Map */}
          <div className="panel" style={{ padding: 16 }}>
            <div style={{ fontFamily: 'var(--font-display)', fontSize: 13, fontWeight: 700, letterSpacing: '0.08em', textTransform: 'uppercase', color: 'var(--chrome-bright)', marginBottom: 16 }}>Rut Activity by Region</div>
            {[
              { region: 'Northern States (MI, MN, WI)', peak: 'Nov 1–15', status: 'Post-Rut', activity: 45 },
              { region: 'Mid-Atlantic (PA, VA, MD)', peak: 'Nov 10–20', status: 'Late Rut', activity: 62 },
              { region: 'Deep South (TX, LA, AL)', peak: 'Dec 1–20', status: 'Pre-Rut', activity: 78 },
              { region: 'Midwest (OH, IN, IL)', peak: 'Nov 5–18', status: 'Rut Active', activity: 88 },
              { region: 'Mountain West (CO, WY, MT)', peak: 'Oct 25–Nov 10', status: 'Post-Rut', activity: 40 },
              { region: 'Southeast (GA, SC, FL)', peak: 'Jan 1–Feb 15', status: 'Pre-Rut', activity: 71 },
            ].map(r => (
              <div key={r.region} style={{ padding: '10px 0', borderBottom: 'var(--border)' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 6 }}>
                  <div>
                    <div style={{ fontSize: 12, color: 'var(--chrome)' }}>{r.region}</div>
                    <div style={{ fontFamily: 'var(--font-mono)', fontSize: 10, color: 'var(--chrome-dim)' }}>Peak: {r.peak}</div>
                  </div>
                  <div style={{ textAlign: 'right' }}>
                    <span className={`badge badge-${r.activity >= 80 ? 'green' : r.activity >= 60 ? 'yellow' : 'red'}`}>{r.status}</span>
                    <div style={{ fontFamily: 'var(--font-mono)', fontSize: 11, color: 'var(--chrome-dim)', marginTop: 2 }}>{r.activity}% activity</div>
                  </div>
                </div>
                <div style={{ height: 3, background: 'var(--bg-elevated)', borderRadius: 2 }}>
                  <div style={{ height: '100%', width: `${r.activity}%`, background: r.activity >= 80 ? 'var(--green)' : r.activity >= 60 ? 'var(--yellow)' : 'var(--red)', borderRadius: 2 }} />
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {tab === 'trips' && (
        <div>
          <div style={{ display: 'flex', justifyContent: 'flex-end', marginBottom: 16 }}>
            <button onClick={() => setShowTripModal(true)} className="btn btn-primary">+ Log Trip</button>
          </div>
          {trips.length === 0 ? (
            <div style={{ textAlign: 'center', padding: '60px 20px', color: 'var(--chrome-dim)' }}>
              <div style={{ fontSize: 48, marginBottom: 12 }}>🌲</div>
              <h3 style={{ marginBottom: 8 }}>No trips logged yet</h3>
              <p style={{ fontSize: 13 }}>Log your hunting trips to build your history and compete on the leaderboard.</p>
            </div>
          ) : (
            <div className="grid-2" style={{ gap: 12 }}>
              {trips.map((trip, i) => (
                <div key={i} className="card">
                  <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 10 }}>
                    <span className={`badge badge-${trip.result === 'harvest' ? 'green' : trip.result === 'miss' ? 'red' : 'cyan'}`}>
                      {trip.result === 'harvest' ? '🎯 Harvest' : trip.result === 'miss' ? '💨 Miss' : trip.result === 'scouting' ? '🔍 Scouting' : trip.result}
                    </span>
                    <span style={{ fontFamily: 'var(--font-mono)', fontSize: 10, color: 'var(--chrome-dim)' }}>{trip.date}</span>
                  </div>
                  <div style={{ fontFamily: 'var(--font-display)', fontSize: 14, fontWeight: 700, color: 'var(--chrome-bright)', marginBottom: 4 }}>{trip.animal}</div>
                  <div style={{ fontSize: 12, color: 'var(--chrome-dim)', marginBottom: 8 }}>{trip.state} · {trip.location}</div>
                  {trip.result === 'harvest' && (
                    <div style={{ display: 'flex', gap: 12 }}>
                      {trip.weight && <span style={{ fontFamily: 'var(--font-mono)', fontSize: 11, color: 'var(--red)' }}>⚖️ {trip.weight} lbs</span>}
                      {trip.points && <span style={{ fontFamily: 'var(--font-mono)', fontSize: 11, color: 'var(--yellow)' }}>🦌 {trip.points} pts</span>}
                      {trip.distance && <span style={{ fontFamily: 'var(--font-mono)', fontSize: 11, color: 'var(--cyan)' }}>📏 {trip.distance} yds</span>}
                    </div>
                  )}
                  {trip.notes && <p style={{ fontSize: 11, color: 'var(--chrome-dim)', marginTop: 8 }}>{trip.notes}</p>}
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {tab === 'leaderboard' && (
        <div className="grid-2" style={{ gap: 16 }}>
          <div className="panel" style={{ padding: 16 }}>
            <div style={{ fontFamily: 'var(--font-display)', fontSize: 13, fontWeight: 700, letterSpacing: '0.08em', textTransform: 'uppercase', color: 'var(--chrome-dim)', marginBottom: 16 }}>🏆 Most Harvests</div>
            {(leaderboard.length > 0 ? leaderboard : DEMO_HUNTERS).map((entry, i) => (
              <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '10px 0', borderBottom: 'var(--border)' }}>
                <span style={{ fontSize: i < 3 ? 18 : 12, width: 28 }}>{i === 0 ? '🥇' : i === 1 ? '🥈' : i === 2 ? '🥉' : `#${i+1}`}</span>
                <img src={entry.user?.avatar || `https://api.dicebear.com/7.x/avataaars/svg?seed=${entry.user?.username}`} alt="" style={{ width: 28, height: 28, borderRadius: '50%' }} />
                <span style={{ flex: 1, fontFamily: 'var(--font-display)', fontSize: 13, fontWeight: 600, color: 'var(--chrome)' }}>{entry.user?.username || 'Hunter'}</span>
                <span style={{ fontFamily: 'var(--font-mono)', fontSize: 14, fontWeight: 700, color: 'var(--red)' }}>{entry.value}</span>
                <span style={{ fontFamily: 'var(--font-mono)', fontSize: 10, color: 'var(--chrome-dim)' }}>harvests</span>
              </div>
            ))}
          </div>
          <div className="panel" style={{ padding: 16 }}>
            <div style={{ fontFamily: 'var(--font-display)', fontSize: 13, fontWeight: 700, letterSpacing: '0.08em', textTransform: 'uppercase', color: 'var(--chrome-dim)', marginBottom: 16 }}>🦌 Trophy Records</div>
            {[
              { hunter: 'TexasRanch_X', animal: 'Whitetail Deer', score: '214 B&C', state: 'TX' },
              { hunter: 'MountainMan99', animal: 'Elk', score: '381 B&C', state: 'CO' },
              { hunter: 'DuckHunter_K', animal: 'Turkey', score: '12" beard', state: 'MS' },
              { hunter: 'WildBoarZ', animal: 'Wild Boar', score: '387 lbs', state: 'FL' },
            ].map((r, i) => (
              <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '10px 0', borderBottom: 'var(--border)' }}>
                <span style={{ fontSize: 18 }}>{i === 0 ? '🥇' : i === 1 ? '🥈' : i === 2 ? '🥉' : '🎯'}</span>
                <div style={{ flex: 1 }}>
                  <div style={{ fontFamily: 'var(--font-display)', fontSize: 12, fontWeight: 600, color: 'var(--chrome)' }}>{r.hunter}</div>
                  <div style={{ fontSize: 11, color: 'var(--chrome-dim)' }}>{r.animal} · {r.state}</div>
                </div>
                <span style={{ fontFamily: 'var(--font-mono)', fontSize: 12, color: 'var(--yellow)', fontWeight: 700 }}>{r.score}</span>
              </div>
            ))}
          </div>
        </div>
      )}

      {tab === 'gear' && (
        <div className="grid-3" style={{ gap: 14 }}>
          {[
            { category: '🔫 Rifles & Firearms', items: ['Remington 700 .308 Win', 'Winchester Model 70 .30-06', 'Browning X-Bolt .270 Win', 'Tikka T3x .243 Win', 'Ruger American 6.5 Creedmoor'] },
            { category: '🏹 Archery', items: ['Mathews Phase 4 Bow', 'Hoyt RX-7 Compound', 'Easton 6.5mm Arrows', 'Rage Hypodermic Broadheads', 'Garmin Xero A1 Sight'] },
            { category: '🌿 Scent Control', items: ['ScentLok Carbon Suit', 'Dead Down Wind Spray', 'Ozonics Unit', 'Scent Killer Body Wash', 'Wildlife Research Cover Scent'] },
            { category: '📍 Scouting Tech', items: ['Stealth Cam Connect LTE', 'Garmin inReach Mini 2', 'Vortex Viper HD 15x50 Binos', 'Leupold RX-2800 Rangefinder', 'HuntStand Pro App'] },
            { category: '🦺 Safety & Clothing', items: ['Hunter Safety HSS Treestand', 'Sitka Gear Coldfront Jacket', 'Danner Pronghorn Boots', 'First Lite Corrugate Guide Pant', 'Blaze Orange Safety Vest'] },
            { category: '🔧 Field Gear', items: ['Gerber StrongArm Fixed Blade', 'Havalon Piranta Skinning Knife', 'Hunters Specialties Pack System', 'Thermacell Mosquito Repeller', 'Black Diamond Storm Headlamp'] },
          ].map(cat => (
            <div key={cat.category} className="card">
              <div style={{ fontFamily: 'var(--font-display)', fontSize: 12, fontWeight: 700, letterSpacing: '0.06em', textTransform: 'uppercase', color: 'var(--chrome-bright)', marginBottom: 12 }}>{cat.category}</div>
              {cat.items.map((item, i) => (
                <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '6px 0', borderBottom: 'var(--border)', fontSize: 12, color: 'var(--chrome-dim)' }}>
                  <span style={{ color: 'var(--red)' }}>›</span> {item}
                </div>
              ))}
            </div>
          ))}
        </div>
      )}

      {/* Trip Log Modal */}
      {showTripModal && (
        <div style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.85)', zIndex: 500, display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 16 }}>
          <div style={{ background: 'var(--bg-panel)', border: 'var(--border-red)', borderRadius: 2, padding: 24, width: '100%', maxWidth: 480, maxHeight: '90vh', overflowY: 'auto' }}>
            <div style={{ fontFamily: 'var(--font-display)', fontSize: '1rem', fontWeight: 700, letterSpacing: '0.08em', textTransform: 'uppercase', marginBottom: 20, color: 'var(--chrome-bright)', display: 'flex', justifyContent: 'space-between' }}>
              Log Hunt Trip
              <button onClick={() => setShowTripModal(false)} style={{ background: 'none', border: 'none', color: 'var(--chrome-dim)', cursor: 'pointer', fontSize: 20 }}>×</button>
            </div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
              <div className="grid-2">
                <div><label>Animal</label><select value={tripForm.animal} onChange={e => setT('animal', e.target.value)}>{ANIMALS.map(a => <option key={a}>{a}</option>)}</select></div>
                <div><label>State</label><select value={tripForm.state} onChange={e => setT('state', e.target.value)}>{STATES.map(s => <option key={s}>{s}</option>)}</select></div>
              </div>
              <div className="grid-2">
                <div><label>Date</label><input type="date" value={tripForm.date} onChange={e => setT('date', e.target.value)} /></div>
                <div><label>Result</label>
                  <select value={tripForm.result} onChange={e => setT('result', e.target.value)}>
                    {['scouting','harvest','miss','seen_only','no_activity'].map(r => <option key={r} value={r}>{r.replace('_', ' ')}</option>)}
                  </select>
                </div>
              </div>
              <div><label>Location / Stand</label><input value={tripForm.location} onChange={e => setT('location', e.target.value)} placeholder="South ridge stand, River bottom..." /></div>
              {tripForm.result === 'harvest' && (
                <div className="grid-3">
                  <div><label>Weight (lbs)</label><input type="number" value={tripForm.weight} onChange={e => setT('weight', e.target.value)} placeholder="180" /></div>
                  <div><label>Points/Score</label><input value={tripForm.points} onChange={e => setT('points', e.target.value)} placeholder="8pt / 142 B&C" /></div>
                  <div><label>Shot Distance (yds)</label><input type="number" value={tripForm.distance} onChange={e => setT('distance', e.target.value)} placeholder="45" /></div>
                </div>
              )}
              <div><label>Notes</label><textarea value={tripForm.notes} onChange={e => setT('notes', e.target.value)} rows={3} placeholder="Wind was out of the NW, saw 3 does and a shooter buck..." style={{ resize: 'none' }} /></div>
              <div style={{ display: 'flex', gap: 10, marginTop: 4 }}>
                <button onClick={logTrip} disabled={loggingTrip} className="btn btn-primary" style={{ flex: 1, justifyContent: 'center' }}>{loggingTrip ? 'Logging...' : '🎯 Log Trip'}</button>
                <button onClick={() => setShowTripModal(false)} className="btn btn-ghost">Cancel</button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

const DEMO_HUNTERS = [
  { user: { username: 'TexasRanch_X', avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=ranch' }, value: 28 },
  { user: { username: 'MountainMan99', avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=mountain' }, value: 24 },
  { user: { username: 'DuckHunter_K', avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=duck' }, value: 21 },
  { user: { username: 'WildBoarZ', avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=boar' }, value: 18 },
  { user: { username: 'NightStalker', avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=night' }, value: 16 },
];
