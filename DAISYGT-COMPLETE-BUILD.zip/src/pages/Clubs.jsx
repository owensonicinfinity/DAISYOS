import React, { useState, useEffect } from 'react';
import { api } from '../services/api';
import { useAuthStore } from '../store/authStore';
import toast from 'react-hot-toast';

const CLUB_ICONS = ['🏆','👑','👻','🔥','⚡','💎','🏁','🎯','🔗','🛡️','🚀','🏎️'];

export default function Clubs() {
  const { user } = useAuthStore();
  const [clubs, setClubs] = useState([]);
  const [myClubs, setMyClubs] = useState([]);
  const [tab, setTab] = useState('discover');
  const [showCreate, setShowCreate] = useState(false);
  const [form, setForm] = useState({ name: '', description: '', type: 'open', avatar: '🏆' });

  useEffect(() => {
    api.clubs.getAll().then(setClubs);
    if (user?.id) api.clubs.getMyClubs(user.id).then(setMyClubs);
  }, [user]);

  const handleJoin = async (clubId) => {
    try {
      await api.clubs.join(clubId, user.id);
      const updated = await api.clubs.getAll();
      setClubs(updated);
      setMyClubs(await api.clubs.getMyClubs(user.id));
      toast.success('Joined club! 🔗');
    } catch (e) { toast.error(e.message); }
  };

  const handleLeave = async (clubId) => {
    await api.clubs.leave(clubId, user.id);
    setMyClubs(await api.clubs.getMyClubs(user.id));
    toast.success('Left club');
  };

  const handleCreate = async () => {
    if (!form.name) { toast.error('Club needs a name'); return; }
    const club = await api.clubs.create({ ...form, members: [user.id], createdBy: user.id });
    setClubs(c => [club, ...c]);
    setMyClubs(m => [club, ...m]);
    setShowCreate(false);
    setForm({ name: '', description: '', type: 'open', avatar: '🏆' });
    toast.success(`${form.name} created! 🏆`);
  };

  const displayClubs = tab === 'my' ? myClubs : clubs;

  return (
    <div style={{ padding: 16, maxWidth: 900, margin: '0 auto' }}>
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 20 }}>
        <h2>RACING <span style={{ color: 'var(--red)' }}>CLUBS</span></h2>
        <button onClick={() => setShowCreate(true)} className="btn btn-primary">+ Create Club</button>
      </div>

      <div className="tab-bar" style={{ marginBottom: 16 }}>
        {[['discover','Discover'],['my','My Clubs'],['events','Events']].map(([val, label]) => (
          <button key={val} onClick={() => setTab(val)} className={`tab-btn ${tab === val ? 'active' : ''}`}>{label}</button>
        ))}
      </div>

      {tab === 'events' ? (
        <div className="panel" style={{ padding: 20 }}>
          <div style={{ fontFamily: 'var(--font-display)', fontSize: 13, fontWeight: 700, letterSpacing: '0.08em', textTransform: 'uppercase', color: 'var(--chrome-dim)', marginBottom: 16 }}>Upcoming Club Events</div>
          {[
            { name: 'Friday Night Drags', club: 'Houston Street Kings', date: 'Fri Jun 6', time: '10:00 PM', location: 'TBD (Private Track)', members: 8 },
            { name: 'Ghost Race Championship', club: 'Ghost Protocol Racing', date: 'Sat Jun 7', time: '8:00 PM', location: 'DaisyGT Virtual', members: 12 },
            { name: 'Elite Time Attack', club: 'Daisy Elite Runners', date: 'Sun Jun 8', time: '2:00 PM', location: 'Invitational Only', members: 6 },
          ].map((e, i) => (
            <div key={i} style={{ padding: '14px 0', borderBottom: 'var(--border)', display: 'flex', gap: 14, alignItems: 'center' }}>
              <div style={{ background: 'var(--bg-surface)', border: 'var(--border)', borderRadius: 2, padding: '8px 12px', textAlign: 'center', minWidth: 60 }}>
                <div style={{ fontFamily: 'var(--font-mono)', fontSize: 9, color: 'var(--chrome-dim)' }}>{e.date.split(' ')[0]}</div>
                <div style={{ fontFamily: 'var(--font-display)', fontSize: 16, fontWeight: 700, color: 'var(--red)' }}>{e.date.split(' ')[1]}</div>
              </div>
              <div style={{ flex: 1 }}>
                <div style={{ fontFamily: 'var(--font-display)', fontSize: 14, fontWeight: 700, color: 'var(--chrome-bright)', letterSpacing: '0.04em' }}>{e.name}</div>
                <div style={{ fontSize: 11, color: 'var(--chrome-dim)', marginTop: 2 }}>{e.club} · {e.time} · {e.location}</div>
              </div>
              <div style={{ textAlign: 'right' }}>
                <div style={{ fontFamily: 'var(--font-mono)', fontSize: 10, color: 'var(--cyan)' }}>{e.members}/12 racers</div>
                <button className="btn btn-primary btn-sm" style={{ marginTop: 6 }}>Join Event</button>
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div className="grid-2" style={{ gap: 16 }}>
          {displayClubs.length === 0 ? (
            <div style={{ gridColumn: '1/-1', textAlign: 'center', padding: '40px 20px', color: 'var(--chrome-dim)' }}>
              <div style={{ fontSize: 40, marginBottom: 12 }}>🔗</div>
              <p>{tab === 'my' ? 'Not in any clubs yet.' : 'No clubs found.'}</p>
            </div>
          ) : displayClubs.map(club => {
            const isMember = club.members?.includes(user?.id);
            const full = (club.members?.length || 0) >= 12;
            return (
              <div key={club.id} className="panel" style={{ padding: 16 }}>
                <div style={{ display: 'flex', gap: 12, marginBottom: 14 }}>
                  <div style={{ fontSize: 36 }}>{club.avatar}</div>
                  <div style={{ flex: 1 }}>
                    <div style={{ fontFamily: 'var(--font-display)', fontSize: 15, fontWeight: 700, letterSpacing: '0.04em', color: 'var(--chrome-bright)', textTransform: 'uppercase' }}>{club.name}</div>
                    <div style={{ display: 'flex', gap: 6, marginTop: 4 }}>
                      <span className={`badge ${club.type === 'invite' ? 'badge-red' : 'badge-cyan'}`}>{club.type === 'invite' ? 'Invite Only' : 'Open'}</span>
                      {isMember && <span className="badge badge-green">Member</span>}
                    </div>
                  </div>
                </div>
                <p style={{ fontSize: 13, color: 'var(--chrome-dim)', marginBottom: 14, lineHeight: 1.6 }}>{club.description}</p>
                <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                  <div>
                    <div style={{ fontFamily: 'var(--font-mono)', fontSize: 11, color: 'var(--chrome-dim)' }}>
                      {club.members?.length || 0}<span style={{ color: 'var(--chrome-dim)' }}>/12 racers</span>
                    </div>
                    <div style={{ height: 3, width: 80, background: 'var(--bg-elevated)', borderRadius: 2, marginTop: 4 }}>
                      <div style={{ height: '100%', width: `${((club.members?.length || 0) / 12) * 100}%`, background: full ? 'var(--red)' : 'var(--cyan)', borderRadius: 2 }} />
                    </div>
                  </div>
                  {isMember ? (
                    <div style={{ display: 'flex', gap: 6 }}>
                      <button className="btn btn-cyan btn-sm">💬 Chat</button>
                      <button onClick={() => handleLeave(club.id)} className="btn btn-ghost btn-sm" style={{ color: 'var(--red)' }}>Leave</button>
                    </div>
                  ) : (
                    <button onClick={() => handleJoin(club.id)} disabled={full || club.type === 'invite'} className="btn btn-primary btn-sm">
                      {full ? 'Full' : club.type === 'invite' ? 'Invite Only' : 'Join'}
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Create Modal */}
      {showCreate && (
        <div style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.8)', zIndex: 500, display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 16 }}>
          <div style={{ background: 'var(--bg-panel)', border: 'var(--border-red)', borderRadius: 2, padding: 24, width: '100%', maxWidth: 440 }}>
            <div style={{ fontFamily: 'var(--font-display)', fontSize: '1rem', fontWeight: 700, letterSpacing: '0.08em', textTransform: 'uppercase', marginBottom: 20, color: 'var(--chrome-bright)', display: 'flex', justifyContent: 'space-between' }}>
              Create Racing Club
              <button onClick={() => setShowCreate(false)} style={{ background: 'none', border: 'none', color: 'var(--chrome-dim)', cursor: 'pointer', fontSize: 20 }}>×</button>
            </div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
              <div>
                <label>Club Icon</label>
                <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6, marginTop: 6 }}>
                  {CLUB_ICONS.map(icon => (
                    <button key={icon} onClick={() => setForm(f => ({ ...f, avatar: icon }))}
                      style={{ fontSize: 20, padding: '4px 6px', background: form.avatar === icon ? 'rgba(224,0,32,0.15)' : 'var(--bg-surface)', border: form.avatar === icon ? 'var(--border-red)' : 'var(--border)', borderRadius: 2, cursor: 'pointer' }}>
                      {icon}
                    </button>
                  ))}
                </div>
              </div>
              <div><label>Club Name</label><input value={form.name} onChange={e => setForm(f => ({ ...f, name: e.target.value }))} placeholder="Houston Street Kings" /></div>
              <div><label>Description</label><textarea value={form.description} onChange={e => setForm(f => ({ ...f, description: e.target.value }))} placeholder="What's your club about?" rows={2} style={{ resize: 'none' }} /></div>
              <div>
                <label>Type</label>
                <div style={{ display: 'flex', gap: 8, marginTop: 6 }}>
                  {['open','invite'].map(t => (
                    <button key={t} onClick={() => setForm(f => ({ ...f, type: t }))}
                      className={form.type === t ? 'btn btn-primary btn-sm' : 'btn btn-ghost btn-sm'}>
                      {t === 'open' ? '🔓 Open' : '🔒 Invite Only'}
                    </button>
                  ))}
                </div>
              </div>
              <div style={{ display: 'flex', gap: 10, marginTop: 4 }}>
                <button onClick={handleCreate} className="btn btn-primary" style={{ flex: 1, justifyContent: 'center' }}>Create Club</button>
                <button onClick={() => setShowCreate(false)} className="btn btn-ghost">Cancel</button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
