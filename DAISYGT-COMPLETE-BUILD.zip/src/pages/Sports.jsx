import React, { useState, useEffect } from 'react';
import { getSportsInsight } from '../services/gemini';
import toast from 'react-hot-toast';

const SPORTS = [
  { id: 'nfl', label: 'NFL', icon: '🏈' },
  { id: 'nba', label: 'NBA', icon: '🏀' },
  { id: 'mlb', label: 'MLB', icon: '⚾' },
  { id: 'nhl', label: 'NHL', icon: '🏒' },
  { id: 'f1', label: 'F1', icon: '🏎️' },
  { id: 'mma', label: 'MMA/UFC', icon: '🥊' },
  { id: 'soccer', label: 'Soccer', icon: '⚽' },
  { id: 'nascar', label: 'NASCAR', icon: '🏁' },
  { id: 'boxing', label: 'Boxing', icon: '🥋' },
  { id: 'tennis', label: 'Tennis', icon: '🎾' },
  { id: 'golf', label: 'Golf', icon: '⛳' },
  { id: 'wnba', label: 'WNBA', icon: '🏀' },
];

const MOCK_SCORES = {
  nfl: [
    { home: 'Kansas City Chiefs', away: 'Dallas Cowboys', homeScore: 28, awayScore: 21, status: 'Final', quarter: 'F', time: '' },
    { home: 'San Francisco 49ers', away: 'Philadelphia Eagles', homeScore: 17, awayScore: 17, status: 'Live', quarter: 'Q3', time: '4:22' },
    { home: 'Buffalo Bills', away: 'Miami Dolphins', homeScore: 31, awayScore: 10, status: 'Final', quarter: 'F', time: '' },
  ],
  nba: [
    { home: 'Boston Celtics', away: 'Miami Heat', homeScore: 112, awayScore: 98, status: 'Final', quarter: 'Final', time: '' },
    { home: 'Golden State Warriors', away: 'Los Angeles Lakers', homeScore: 88, awayScore: 94, status: 'Live', quarter: 'Q4', time: '2:11' },
    { home: 'Denver Nuggets', away: 'Phoenix Suns', homeScore: 0, awayScore: 0, status: 'Tonight', quarter: '', time: '7:30 PM ET' },
  ],
  mlb: [
    { home: 'New York Yankees', away: 'Boston Red Sox', homeScore: 7, awayScore: 4, status: 'Final', quarter: 'F/9', time: '' },
    { home: 'Houston Astros', away: 'Texas Rangers', homeScore: 3, awayScore: 5, status: 'Live', quarter: '8th', time: '2 outs' },
    { home: 'Los Angeles Dodgers', away: 'San Francisco Giants', homeScore: 0, awayScore: 0, status: 'Tonight', quarter: '', time: '9:10 PM ET' },
  ],
  nhl: [
    { home: 'Florida Panthers', away: 'New York Rangers', homeScore: 4, awayScore: 2, status: 'Final', quarter: 'F', time: '' },
    { home: 'Colorado Avalanche', away: 'Dallas Stars', homeScore: 1, awayScore: 2, status: 'Live', quarter: 'P3', time: '11:33' },
  ],
  f1: [
    { home: 'Max Verstappen (Red Bull)', away: 'Lewis Hamilton (Mercedes)', homeScore: 1, awayScore: 2, status: 'Race Result', quarter: 'Monaco GP', time: '' },
    { home: 'Charles Leclerc (Ferrari)', away: 'Lando Norris (McLaren)', homeScore: 3, awayScore: 4, status: 'Race Result', quarter: 'Monaco GP', time: '' },
  ],
  mma: [
    { home: 'Jon Jones', away: 'Stipe Miocic', homeScore: 0, awayScore: 0, status: 'Upcoming', quarter: 'UFC 309', time: 'Nov 16' },
    { home: 'Islam Makhachev', away: 'Dustin Poirier', homeScore: 0, awayScore: 0, status: 'Recent', quarter: 'UFC 302', time: 'Decision Win' },
  ],
  soccer: [
    { home: 'Manchester City', away: 'Arsenal', homeScore: 2, awayScore: 1, status: 'Final', quarter: 'FT', time: '' },
    { home: 'Real Madrid', away: 'Barcelona', homeScore: 3, awayScore: 2, status: 'Final', quarter: 'FT', time: '' },
    { home: 'Bayern Munich', away: 'Borussia Dortmund', homeScore: 0, awayScore: 0, status: 'Live', quarter: '62\'', time: '' },
  ],
  nascar: [
    { home: 'Kyle Larson (#5)', away: 'Denny Hamlin (#11)', homeScore: 1, awayScore: 2, status: 'Race Result', quarter: 'Coca-Cola 600', time: '' },
  ],
  boxing: [
    { home: 'Canelo Álvarez', away: 'Jaime Munguia', homeScore: 0, awayScore: 0, status: 'Upcoming', quarter: 'Super Middleweight', time: 'May 4' },
  ],
  tennis: [
    { home: 'Novak Djokovic', away: 'Carlos Alcaraz', homeScore: 6, awayScore: 7, status: 'Live', quarter: 'Set 3', time: '3-3' },
  ],
  golf: [
    { home: 'Scottie Scheffler', away: '-18 under par', homeScore: 0, awayScore: 0, status: 'Leader', quarter: 'PGA Championship', time: 'R4' },
  ],
  wnba: [
    { home: 'Las Vegas Aces', away: 'New York Liberty', homeScore: 84, awayScore: 79, status: 'Final', quarter: 'F', time: '' },
  ],
};

const STANDINGS = {
  nfl: [
    { team: 'Kansas City Chiefs', w: 11, l: 2, pct: '.846', pf: 387, pa: 218 },
    { team: 'San Francisco 49ers', w: 10, l: 3, pct: '.769', pf: 341, pa: 217 },
    { team: 'Dallas Cowboys', w: 9, l: 4, pct: '.692', pf: 312, pa: 261 },
    { team: 'Philadelphia Eagles', w: 8, l: 5, pct: '.615', pf: 289, pa: 247 },
    { team: 'Buffalo Bills', w: 8, l: 5, pct: '.615', pf: 298, pa: 265 },
  ],
  nba: [
    { team: 'Boston Celtics', w: 58, l: 14, pct: '.806', pf: 121.1, pa: 108.3 },
    { team: 'Oklahoma City Thunder', w: 55, l: 17, pct: '.764', pf: 118.2, pa: 109.1 },
    { team: 'Denver Nuggets', w: 52, l: 20, pct: '.722', pf: 116.8, pa: 110.4 },
    { team: 'Milwaukee Bucks', w: 48, l: 24, pct: '.667', pf: 118.4, pa: 114.2 },
    { team: 'New York Knicks', w: 46, l: 26, pct: '.639', pf: 114.7, pa: 112.9 },
  ],
};

function ScoreCard({ game, sport }) {
  const statusColor = game.status === 'Live' ? 'var(--red)' : game.status === 'Final' ? 'var(--chrome-dim)' : 'var(--cyan)';
  const isLive = game.status === 'Live';

  return (
    <div className="card" style={{ padding: 14 }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginBottom: 10 }}>
        {isLive && <span className="live-dot" />}
        <span style={{ fontFamily: 'var(--font-mono)', fontSize: 10, color: statusColor, letterSpacing: '0.08em', textTransform: 'uppercase' }}>
          {game.status} {game.quarter && `· ${game.quarter}`} {game.time && `· ${game.time}`}
        </span>
      </div>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
        {['away', 'home'].map(side => (
          <div key={side} style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
            <span style={{ fontSize: 13, color: 'var(--chrome)', fontFamily: 'var(--font-display)', fontWeight: 600, letterSpacing: '0.02em', flex: 1 }}>
              {game[side]}
            </span>
            {game.status !== 'Upcoming' && game.status !== 'Tonight' && (
              <span style={{ fontFamily: 'var(--font-mono)', fontSize: '1.2rem', fontWeight: 700, color: game[`${side}Score`] > game[`${side === 'home' ? 'away' : 'home'}Score`] ? 'var(--chrome-bright)' : 'var(--chrome-dim)', minWidth: 32, textAlign: 'right' }}>
                {game[`${side}Score`]}
              </span>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}

export default function Sports() {
  const [sport, setSport] = useState('nfl');
  const [tab, setTab] = useState('scores');
  const [aiQuestion, setAiQuestion] = useState('');
  const [aiAnswer, setAiAnswer] = useState('');
  const [aiLoading, setAiLoading] = useState(false);
  const [betSlip, setBetSlip] = useState([]);

  const games = MOCK_SCORES[sport] || [];
  const standings = STANDINGS[sport];

  const askAI = async () => {
    if (!aiQuestion.trim()) return;
    setAiLoading(true);
    try {
      const answer = await getSportsInsight(sport.toUpperCase(), { question: aiQuestion });
      setAiAnswer(answer);
    } catch {
      setAiAnswer('DaisyAI is analyzing the matchup... try again in a moment.');
    }
    setAiLoading(false);
  };

  const addToBetSlip = (game, pick) => {
    setBetSlip(b => [...b, { game: `${game.away} vs ${game.home}`, pick, odds: '-110' }]);
    toast.success(`${pick} added to bet tracker`);
  };

  return (
    <div style={{ padding: 16, maxWidth: 1000, margin: '0 auto' }}>
      <h2 style={{ marginBottom: 16 }}>LIVE <span style={{ color: 'var(--red)' }}>SPORTS</span></h2>

      {/* Sport Selector */}
      <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap', marginBottom: 20 }}>
        {SPORTS.map(s => (
          <button key={s.id} onClick={() => setSport(s.id)}
            style={{ display: 'flex', alignItems: 'center', gap: 6, padding: '7px 12px', background: sport === s.id ? 'rgba(224,0,32,0.12)' : 'var(--bg-panel)', border: sport === s.id ? 'var(--border-red)' : 'var(--border)', borderRadius: 2, cursor: 'pointer', fontFamily: 'var(--font-display)', fontSize: 11, fontWeight: 600, letterSpacing: '0.06em', textTransform: 'uppercase', color: sport === s.id ? 'var(--red)' : 'var(--chrome-dim)', transition: 'all 0.15s' }}>
            <span style={{ fontSize: 14 }}>{s.icon}</span> {s.label}
          </button>
        ))}
      </div>

      <div className="tab-bar" style={{ marginBottom: 16 }}>
        {[['scores', 'Scores'], ['standings', 'Standings'], ['ai', '⚡ AI Analysis'], ['tracker', '📋 Bet Tracker']].map(([val, label]) => (
          <button key={val} onClick={() => setTab(val)} className={`tab-btn ${tab === val ? 'active' : ''}`}>{label}</button>
        ))}
      </div>

      {tab === 'scores' && (
        <div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 14 }}>
            <span className="live-dot" />
            <span style={{ fontFamily: 'var(--font-mono)', fontSize: 11, color: 'var(--red)', letterSpacing: '0.1em', textTransform: 'uppercase' }}>
              Live & Recent — {SPORTS.find(s => s.id === sport)?.label}
            </span>
          </div>
          <div className="grid-2" style={{ gap: 12 }}>
            {games.length === 0 ? (
              <div style={{ gridColumn: '1/-1', textAlign: 'center', padding: '40px 20px', color: 'var(--chrome-dim)' }}>
                <div style={{ fontSize: 40, marginBottom: 12 }}>{SPORTS.find(s => s.id === sport)?.icon}</div>
                <p>No games scheduled right now. Check back soon!</p>
              </div>
            ) : games.map((game, i) => (
              <div key={i}>
                <ScoreCard game={game} sport={sport} />
                {game.status !== 'Upcoming' && game.status !== 'Tonight' && (
                  <div style={{ display: 'flex', gap: 6, marginTop: 6 }}>
                    <button onClick={() => addToBetSlip(game, game.home)} className="btn btn-ghost btn-sm" style={{ fontSize: 10 }}>Track {game.home.split(' ').pop()}</button>
                    <button onClick={() => addToBetSlip(game, game.away)} className="btn btn-ghost btn-sm" style={{ fontSize: 10 }}>Track {game.away.split(' ').pop()}</button>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      )}

      {tab === 'standings' && (
        <div className="panel" style={{ padding: 16 }}>
          {standings ? (
            <>
              <div style={{ fontFamily: 'var(--font-display)', fontSize: 13, fontWeight: 700, letterSpacing: '0.08em', textTransform: 'uppercase', color: 'var(--chrome-dim)', marginBottom: 16 }}>
                {SPORTS.find(s => s.id === sport)?.label} Standings
              </div>
              <div style={{ overflowX: 'auto' }}>
                <table style={{ width: '100%', borderCollapse: 'collapse' }}>
                  <thead>
                    <tr style={{ borderBottom: 'var(--border)' }}>
                      {['#', 'Team', 'W', 'L', 'PCT', 'PF', 'PA'].map(h => (
                        <th key={h} style={{ fontFamily: 'var(--font-mono)', fontSize: 10, letterSpacing: '0.1em', textTransform: 'uppercase', color: 'var(--chrome-dim)', padding: '6px 10px', textAlign: h === 'Team' ? 'left' : 'right' }}>{h}</th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {standings.map((team, i) => (
                      <tr key={team.team} style={{ borderBottom: 'var(--border)' }}>
                        <td style={{ fontFamily: 'var(--font-mono)', fontSize: 12, color: i === 0 ? 'var(--yellow)' : 'var(--chrome-dim)', padding: '10px', textAlign: 'right' }}>{i + 1}</td>
                        <td style={{ fontFamily: 'var(--font-display)', fontSize: 13, color: 'var(--chrome-bright)', padding: '10px', letterSpacing: '0.02em' }}>{team.team}</td>
                        <td style={{ fontFamily: 'var(--font-mono)', fontSize: 12, color: 'var(--green)', padding: '10px', textAlign: 'right' }}>{team.w}</td>
                        <td style={{ fontFamily: 'var(--font-mono)', fontSize: 12, color: 'var(--red)', padding: '10px', textAlign: 'right' }}>{team.l}</td>
                        <td style={{ fontFamily: 'var(--font-mono)', fontSize: 12, color: 'var(--chrome)', padding: '10px', textAlign: 'right' }}>{team.pct}</td>
                        <td style={{ fontFamily: 'var(--font-mono)', fontSize: 12, color: 'var(--chrome-dim)', padding: '10px', textAlign: 'right' }}>{team.pf}</td>
                        <td style={{ fontFamily: 'var(--font-mono)', fontSize: 12, color: 'var(--chrome-dim)', padding: '10px', textAlign: 'right' }}>{team.pa}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </>
          ) : (
            <div style={{ textAlign: 'center', padding: '40px 0', color: 'var(--chrome-dim)' }}>
              <p>Standings not available for {SPORTS.find(s => s.id === sport)?.label} yet.</p>
            </div>
          )}
        </div>
      )}

      {tab === 'ai' && (
        <div className="panel" style={{ padding: 20 }}>
          <div style={{ fontFamily: 'var(--font-display)', fontSize: 13, fontWeight: 700, letterSpacing: '0.08em', textTransform: 'uppercase', color: 'var(--chrome-bright)', marginBottom: 16 }}>
            ⚡ DaisyAI Sports Analyst
          </div>
          <p style={{ fontSize: 13, color: 'var(--chrome-dim)', marginBottom: 20 }}>
            Ask DaisyAI anything about {SPORTS.find(s => s.id === sport)?.label} — matchups, predictions, stats, player analysis.
          </p>
          <div style={{ display: 'flex', gap: 10, marginBottom: 16 }}>
            <input value={aiQuestion} onChange={e => setAiQuestion(e.target.value)} onKeyDown={e => e.key === 'Enter' && askAI()} placeholder={`Ask about ${SPORTS.find(s => s.id === sport)?.label}...`} />
            <button onClick={askAI} disabled={aiLoading} className="btn btn-primary" style={{ whiteSpace: 'nowrap' }}>
              {aiLoading ? '...' : '⚡ Ask AI'}
            </button>
          </div>
          <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6, marginBottom: 16 }}>
            {[
              `Who is the MVP favorite in ${sport.toUpperCase()}?`,
              'Best game tonight?',
              `${sport.toUpperCase()} championship prediction`,
              'Top player stats this week',
            ].map(q => (
              <button key={q} onClick={() => { setAiQuestion(q); setTimeout(askAI, 50); }}
                style={{ fontSize: 11, padding: '4px 10px', background: 'var(--bg-surface)', border: 'var(--border)', color: 'var(--chrome-dim)', borderRadius: 1, cursor: 'pointer' }}>
                {q}
              </button>
            ))}
          </div>
          {aiLoading && (
            <div style={{ display: 'flex', alignItems: 'center', gap: 10, padding: 16 }}>
              <div className="loading-spinner" style={{ width: 20, height: 20 }} />
              <span style={{ fontSize: 12, color: 'var(--chrome-dim)' }}>DaisyAI analyzing...</span>
            </div>
          )}
          {aiAnswer && (
            <div style={{ background: 'rgba(0,229,255,0.05)', border: '1px solid rgba(0,229,255,0.2)', borderRadius: 2, padding: 16 }}>
              <div style={{ fontFamily: 'var(--font-display)', fontSize: 10, fontWeight: 600, letterSpacing: '0.1em', textTransform: 'uppercase', color: 'var(--cyan)', marginBottom: 8 }}>DaisyAI Response</div>
              <p style={{ fontSize: 13, lineHeight: 1.8, color: 'var(--chrome)' }}>{aiAnswer}</p>
            </div>
          )}
        </div>
      )}

      {tab === 'tracker' && (
        <div>
          <div style={{ background: 'rgba(255,204,0,0.05)', border: '1px solid rgba(255,204,0,0.2)', borderRadius: 2, padding: '10px 14px', marginBottom: 16, fontSize: 12, color: 'var(--yellow)', lineHeight: 1.6 }}>
            ⚠️ <strong>Disclaimer:</strong> This tracker logs your personal picks for entertainment purposes only. Daisy GT does not facilitate betting or gambling. All wagers are made privately and independently. Race responsibly.
          </div>
          {betSlip.length === 0 ? (
            <div style={{ textAlign: 'center', padding: '40px 20px', color: 'var(--chrome-dim)' }}>
              <div style={{ fontSize: 40, marginBottom: 12 }}>📋</div>
              <p>No picks tracked yet. Click "Track" on any game from the Scores tab.</p>
            </div>
          ) : (
            <div className="panel" style={{ padding: 16 }}>
              <div style={{ fontFamily: 'var(--font-display)', fontSize: 13, fontWeight: 700, letterSpacing: '0.08em', textTransform: 'uppercase', color: 'var(--chrome-dim)', marginBottom: 14 }}>My Pick Tracker</div>
              {betSlip.map((b, i) => (
                <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '10px 0', borderBottom: 'var(--border)' }}>
                  <div style={{ flex: 1 }}>
                    <div style={{ fontFamily: 'var(--font-display)', fontSize: 13, color: 'var(--chrome-bright)', fontWeight: 600 }}>{b.pick}</div>
                    <div style={{ fontSize: 11, color: 'var(--chrome-dim)' }}>{b.game}</div>
                  </div>
                  <span style={{ fontFamily: 'var(--font-mono)', fontSize: 12, color: 'var(--cyan)' }}>{b.odds}</span>
                  <button onClick={() => setBetSlip(bs => bs.filter((_, j) => j !== i))} style={{ background: 'none', border: 'none', color: 'var(--red)', cursor: 'pointer', fontSize: 16 }}>×</button>
                </div>
              ))}
              <button onClick={() => setBetSlip([])} className="btn btn-ghost btn-sm" style={{ marginTop: 12 }}>Clear All</button>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
