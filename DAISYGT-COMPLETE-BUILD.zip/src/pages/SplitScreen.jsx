import React, { useState, useEffect, useRef } from 'react';
import { Link } from 'react-router-dom';
import { onTelemetryUpdate, startSimulation, stopSimulation } from '../services/gps';
import { useAuthStore } from '../store/authStore';

const VEHICLE_ICONS = { Car: '🏎️', Motorcycle: '🏍️', Truck: '🚚', Boat: '🚤', Aircraft: '✈️', Other: '🚗' };

function RacerPanel({ racer, isYou, elapsed }) {
  const barColor = isYou ? 'var(--green)' : racer.color || 'var(--cyan)';
  const speedPct = Math.min(100, (racer.speed / 200) * 100);

  return (
    <div style={{
      background: 'var(--bg-panel)',
      border: `1px solid ${isYou ? 'rgba(0,255,136,0.3)' : 'rgba(0,229,255,0.2)'}`,
      borderRadius: 2,
      padding: 16,
      position: 'relative',
      overflow: 'hidden',
      display: 'flex',
      flexDirection: 'column',
      gap: 12,
    }}>
      {/* Scan line effect */}
      <div style={{ position: 'absolute', top: 0, left: 0, right: 0, height: 2, background: `linear-gradient(90deg, transparent, ${barColor}, transparent)`, animation: 'scanLine 2s linear infinite', opacity: 0.6 }} />

      {/* Header */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
        <div style={{ fontSize: 28 }}>{VEHICLE_ICONS[racer.vehicle] || '🏎️'}</div>
        <div style={{ flex: 1 }}>
          <div style={{ fontFamily: 'var(--font-display)', fontSize: 14, fontWeight: 700, letterSpacing: '0.06em', textTransform: 'uppercase', color: barColor }}>{racer.name}</div>
          <div style={{ fontFamily: 'var(--font-mono)', fontSize: 10, color: 'var(--chrome-dim)' }}>{isYou ? 'YOU' : 'GHOST'} · {racer.vehicle || 'Car'}</div>
        </div>
        <div style={{ textAlign: 'right' }}>
          <div style={{ fontFamily: 'var(--font-display)', fontSize: 12, fontWeight: 700, color: racer.position === 1 ? 'var(--yellow)' : 'var(--chrome-dim)', letterSpacing: '0.06em' }}>P{racer.position || 1}</div>
          {isYou && <span className="live-dot" style={{ marginTop: 4, display: 'block' }} />}
        </div>
      </div>

      {/* Big Speed */}
      <div style={{ textAlign: 'center', padding: '12px 0', borderTop: 'var(--border)', borderBottom: 'var(--border)' }}>
        <div style={{ fontFamily: 'var(--font-mono)', fontSize: '3.8rem', fontWeight: 700, color: barColor, lineHeight: 1, textShadow: `0 0 30px ${barColor}` }}>
          {Math.round(racer.speed)}
        </div>
        <div style={{ fontFamily: 'var(--font-mono)', fontSize: 11, color: 'var(--chrome-dim)', marginTop: 4 }}>MPH</div>
        {/* Speed bar */}
        <div style={{ height: 3, background: 'var(--bg-elevated)', borderRadius: 2, margin: '10px 0 0' }}>
          <div style={{ height: '100%', width: `${speedPct}%`, background: barColor, borderRadius: 2, transition: 'width 0.3s ease', boxShadow: `0 0 8px ${barColor}` }} />
        </div>
      </div>

      {/* Telemetry Grid */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8 }}>
        {[
          { label: 'Distance', value: racer.distance?.toFixed(3) || '0.000', unit: 'mi' },
          { label: 'G-Force', value: (racer.gForce || 0).toFixed(2), unit: 'g' },
          { label: 'Elevation', value: Math.round(racer.altitude || 0), unit: 'ft' },
          { label: 'Top Speed', value: Math.round(racer.topSpeed || racer.speed || 0), unit: 'mph' },
        ].map(s => (
          <div key={s.label} style={{ background: 'var(--bg-surface)', padding: '8px 10px', borderRadius: 2 }}>
            <div style={{ fontFamily: 'var(--font-mono)', fontSize: 9, letterSpacing: '0.1em', textTransform: 'uppercase', color: 'var(--chrome-dim)' }}>{s.label}</div>
            <div style={{ fontFamily: 'var(--font-mono)', fontSize: '1.2rem', fontWeight: 700, color: 'var(--chrome-bright)', marginTop: 2 }}>{s.value} <span style={{ fontSize: 9, color: 'var(--chrome-dim)' }}>{s.unit}</span></div>
          </div>
        ))}
      </div>

      {/* Gap indicator */}
      {!isYou && (
        <div style={{ background: 'rgba(0,229,255,0.06)', border: '1px solid rgba(0,229,255,0.15)', borderRadius: 2, padding: '6px 10px', textAlign: 'center' }}>
          <span style={{ fontFamily: 'var(--font-mono)', fontSize: 11, color: 'var(--cyan)' }}>
            GAP: {racer.gap > 0 ? `+${racer.gap}s` : `${racer.gap}s`}
          </span>
        </div>
      )}
    </div>
  );
}

export default function SplitScreen() {
  const { user } = useAuthStore();
  const [myData, setMyData] = useState({ name: user?.username || 'YOU', vehicle: user?.primaryVehicle || 'Car', speed: 0, distance: 0, gForce: 0, altitude: 0, topSpeed: 0, position: 1 });
  const [ghost1, setGhost1] = useState({ name: 'TurboQueen', vehicle: 'Car', color: 'var(--cyan)', speed: 0, distance: 0, gForce: 0, altitude: 0, topSpeed: 0, position: 2, gap: 0 });
  const [ghost2, setGhost2] = useState({ name: 'RocketMike', vehicle: 'Motorcycle', color: 'var(--orange)', speed: 0, distance: 0, gForce: 0, altitude: 0, topSpeed: 0, position: 3, gap: 0 });
  const [elapsed, setElapsed] = useState(0);
  const [layout, setLayout] = useState('split2'); // split2 | split3 | focus
  const startRef = useRef(Date.now());

  useEffect(() => {
    const cleanup = onTelemetryUpdate((data) => {
      setMyData(prev => ({
        ...prev,
        speed: data.speed,
        distance: (prev.distance || 0) + (data.speed * 0.5 / 3600),
        gForce: data.gForce || 0,
        altitude: data.altitude || 0,
        topSpeed: Math.max(prev.topSpeed, data.speed),
      }));
    });

    startSimulation();

    // Simulate ghost updates
    let t = 0;
    const ghostInterval = setInterval(() => {
      t += 0.5;
      const g1Speed = 70 + Math.sin(t * 0.5) * 20 + Math.random() * 6;
      const g2Speed = 65 + Math.sin(t * 0.3 + 1) * 25 + Math.random() * 8;
      setGhost1(prev => {
        const dist = (prev.distance || 0) + (g1Speed * 0.5 / 3600);
        return { ...prev, speed: g1Speed, distance: dist, topSpeed: Math.max(prev.topSpeed, g1Speed), gForce: Math.abs(Math.sin(t) * 0.4), gap: parseFloat((Math.sin(t * 0.2) * 1.5).toFixed(1)) };
      });
      setGhost2(prev => {
        const dist = (prev.distance || 0) + (g2Speed * 0.5 / 3600);
        return { ...prev, speed: g2Speed, distance: dist, topSpeed: Math.max(prev.topSpeed, g2Speed), gForce: Math.abs(Math.cos(t) * 0.5), gap: parseFloat((Math.cos(t * 0.15) * 2.2).toFixed(1)) };
      });
      setElapsed(Math.floor((Date.now() - startRef.current) / 1000));
    }, 500);

    return () => {
      cleanup();
      stopSimulation();
      clearInterval(ghostInterval);
    };
  }, []);

  const formatTime = (s) => `${String(Math.floor(s / 60)).padStart(2,'0')}:${String(s % 60).padStart(2,'0')}`;

  const gridConfig = layout === 'split3'
    ? { gridTemplateColumns: '1fr 1fr 1fr' }
    : layout === 'focus'
    ? { gridTemplateColumns: '2fr 1fr' }
    : { gridTemplateColumns: '1fr 1fr' };

  return (
    <div style={{ padding: 12, height: 'calc(100vh - 56px)', display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>

      {/* ─── Header Bar ─── */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 12, flexWrap: 'wrap' }}>
        <Link to="/app/race" style={{ color: 'var(--chrome-dim)', textDecoration: 'none', fontFamily: 'var(--font-display)', fontSize: 11, letterSpacing: '0.06em', textTransform: 'uppercase' }}>← Race</Link>
        <div style={{ flex: 1, fontFamily: 'var(--font-display)', fontSize: '1rem', fontWeight: 700, letterSpacing: '0.08em', color: 'var(--chrome-bright)', textTransform: 'uppercase' }}>
          ⊡ SPLIT-SCREEN RACE VIEW
        </div>
        <div style={{ fontFamily: 'var(--font-mono)', fontSize: '1.2rem', color: 'var(--red)', letterSpacing: '0.06em' }}>{formatTime(elapsed)}</div>
        <div className="tab-bar" style={{ borderBottom: 'none', gap: 4 }}>
          {[['split2','2-WAY'],['split3','3-WAY'],['focus','FOCUS']].map(([val, label]) => (
            <button key={val} onClick={() => setLayout(val)} className={`tab-btn ${layout === val ? 'active' : ''}`} style={{ padding: '6px 12px', fontSize: 10 }}>{label}</button>
          ))}
        </div>
      </div>

      {/* ─── Comparison Bar ─── */}
      <div style={{ background: 'var(--bg-panel)', border: 'var(--border)', borderRadius: 2, padding: '8px 16px', marginBottom: 12, display: 'flex', alignItems: 'center', gap: 20, flexWrap: 'wrap' }}>
        <span style={{ fontFamily: 'var(--font-mono)', fontSize: 10, color: 'var(--chrome-dim)', letterSpacing: '0.1em', textTransform: 'uppercase' }}>Live Comparison</span>
        {[
          { label: 'Speed Lead', value: `${Math.round(myData.speed - ghost1.speed)} mph`, positive: myData.speed > ghost1.speed },
          { label: 'Distance Lead', value: `${((myData.distance - ghost1.distance) * 5280).toFixed(0)} ft`, positive: myData.distance > ghost1.distance },
          { label: 'Top Speed', value: `${Math.round(Math.max(myData.topSpeed, ghost1.topSpeed, ghost2.topSpeed))} mph`, positive: true },
        ].map(c => (
          <div key={c.label} style={{ display: 'flex', gap: 6, alignItems: 'center' }}>
            <span style={{ fontFamily: 'var(--font-mono)', fontSize: 9, color: 'var(--chrome-dim)', textTransform: 'uppercase' }}>{c.label}:</span>
            <span style={{ fontFamily: 'var(--font-mono)', fontSize: 12, fontWeight: 700, color: c.positive ? 'var(--green)' : 'var(--red)' }}>{c.value}</span>
          </div>
        ))}
        <div style={{ marginLeft: 'auto', display: 'flex', alignItems: 'center', gap: 6 }}>
          <span className="live-dot" />
          <span style={{ fontFamily: 'var(--font-mono)', fontSize: 10, color: 'var(--red)' }}>LIVE</span>
        </div>
      </div>

      {/* ─── Racer Panels ─── */}
      <div style={{ flex: 1, display: 'grid', gap: 12, minHeight: 0, ...gridConfig }}>
        <RacerPanel racer={{ ...myData, position: myData.distance >= ghost1.distance && myData.distance >= ghost2.distance ? 1 : myData.distance >= ghost1.distance || myData.distance >= ghost2.distance ? 2 : 3 }} isYou elapsed={elapsed} />
        <RacerPanel racer={{ ...ghost1, position: ghost1.distance >= myData.distance && ghost1.distance >= ghost2.distance ? 1 : ghost1.distance >= myData.distance || ghost1.distance >= ghost2.distance ? 2 : 3 }} elapsed={elapsed} />
        {layout === 'split3' && (
          <RacerPanel racer={{ ...ghost2, position: ghost2.distance >= myData.distance && ghost2.distance >= ghost1.distance ? 1 : ghost2.distance >= myData.distance || ghost2.distance >= ghost1.distance ? 2 : 3 }} elapsed={elapsed} />
        )}
      </div>

      {/* ─── Bottom G-Force Bars ─── */}
      <div style={{ marginTop: 12, background: 'var(--bg-panel)', border: 'var(--border)', borderRadius: 2, padding: '10px 16px' }}>
        <div style={{ fontFamily: 'var(--font-mono)', fontSize: 9, color: 'var(--chrome-dim)', letterSpacing: '0.1em', textTransform: 'uppercase', marginBottom: 8 }}>G-Force Monitor (Lateral)</div>
        <div style={{ display: 'flex', gap: 16, alignItems: 'center' }}>
          {[
            { name: myData.name, g: myData.gForce, color: 'var(--green)' },
            { name: ghost1.name, g: ghost1.gForce, color: 'var(--cyan)' },
            { name: ghost2.name, g: ghost2.gForce, color: 'var(--orange)' },
          ].map(r => (
            <div key={r.name} style={{ flex: 1 }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 4 }}>
                <span style={{ fontFamily: 'var(--font-mono)', fontSize: 9, color: r.color }}>{r.name}</span>
                <span style={{ fontFamily: 'var(--font-mono)', fontSize: 9, color: 'var(--chrome-dim)' }}>{r.g.toFixed(2)}g</span>
              </div>
              <div style={{ height: 4, background: 'var(--bg-elevated)', borderRadius: 2 }}>
                <div style={{ height: '100%', width: `${Math.min(100, r.g * 80)}%`, background: r.color, borderRadius: 2, transition: 'width 0.2s', boxShadow: `0 0 6px ${r.color}` }} />
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
