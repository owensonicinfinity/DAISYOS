import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App';

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<React.StrictMode><App /></React.StrictMode>);

// ─── Service Worker Registration ─────────────────────
if ('serviceWorker' in navigator && process.env.NODE_ENV === 'production') {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('/sw.js').then((reg) => {
      setInterval(() => reg.update(), 30 * 60 * 1000);
      reg.addEventListener('updatefound', () => {
        const w = reg.installing;
        w?.addEventListener('statechange', () => {
          if (w.state === 'installed' && navigator.serviceWorker.controller) w.postMessage({ type: 'SKIP_WAITING' });
        });
      });
    }).catch(err => console.warn('[DaisyGT] SW failed:', err));

    navigator.serviceWorker.ready.then(reg => {
      if ('sync' in reg) reg.sync.register('daisygt-upload-telemetry').catch(() => {});
    });

    navigator.serviceWorker.addEventListener('message', (e) => {
      if (e.data?.type === 'SYNC_TELEMETRY') window.dispatchEvent(new CustomEvent('daisygt:syncTelemetry'));
    });
  });
}

// ─── Offline/Online banner ───────────────────────────
window.addEventListener('offline', () => {
  if (document.getElementById('offline-banner')) return;
  const b = document.createElement('div');
  b.id = 'offline-banner';
  b.style.cssText = 'position:fixed;bottom:0;left:0;right:0;background:#8c0012;color:#fff;padding:8px 16px;text-align:center;font-family:"JetBrains Mono",monospace;font-size:11px;z-index:9999;letter-spacing:0.08em;';
  b.textContent = '📡 OFFLINE MODE — Race data saving locally · Will sync on reconnect';
  document.body.appendChild(b);
});
window.addEventListener('online', () => document.getElementById('offline-banner')?.remove());
