# 🏎️ DAISY GT — DaisyOS Racing Platform

> The world's most advanced multi-vehicle racing platform. Real-time GPS racing, professional telemetry, ghost overlays, social media, global leaderboards, and DaisyAI integration — all in one ecosystem.

**Part of the [DaisyOS](https://daisyapps.com) Ecosystem** · SaysoSocial · DaisyAI Hunting · DaisyGT Racing

---

## 🚀 Quick Deploy to Netlify (Free)

### Option 1: Netlify Drop (Fastest — 60 seconds)
1. Run `npm run build` locally
2. Go to [netlify.com/drop](https://app.netlify.com/drop)
3. Drag the `build/` folder to the page
4. Done — you get a free `.netlify.app` URL instantly

### Option 2: GitHub + Netlify Auto-Deploy (Recommended)
1. Push this repo to GitHub
2. Go to [netlify.com](https://netlify.com) → **Add new site** → **Import from Git**
3. Select your GitHub repo
4. Build settings are auto-detected from `netlify.toml`
5. Click **Deploy** — every push to `main` auto-deploys

### Option 3: Netlify CLI
```bash
npm install -g netlify-cli
netlify login
npm run build
netlify deploy --prod --dir=build
```

---

## 🛠 Local Development

```bash
# Install dependencies
npm install

# Start development server
npm start

# Build for production
npm run build
```

App runs at `http://localhost:3000`

---

## 🎁 Free Trial Code
```
DAISYGT-FREE-2025
```
Activates 14-day Elite access. Share with users.

---

## 🏗 Architecture

```
src/
├── pages/
│   ├── Landing.jsx          # Marketing + pricing page
│   ├── Login.jsx            # Auth with Google OAuth support
│   ├── Register.jsx         # Registration (auto-activates trial)
│   ├── Dashboard.jsx        # Main HQ HUD
│   ├── Race.jsx             # GPS racing + ghost overlay
│   ├── SplitScreen.jsx      # Multi-racer split view
│   ├── Garage.jsx           # Vehicle management
│   ├── Dyno.jsx             # Telemetry (DDG system)
│   ├── Social.jsx           # Feed + live chat
│   ├── Leaderboards.jsx     # 17+ global categories
│   ├── Clubs.jsx            # Racing clubs (max 12 racers)
│   ├── Marketplace.jsx      # Race NFT collectibles
│   ├── Analytics.jsx        # Performance charts
│   ├── Training.jsx         # Boxing + lifting + agility
│   ├── Sports.jsx           # Live sports hub (NFL/NBA/etc)
│   ├── Hunting.jsx          # DaisyAI hunting companion
│   ├── Profile.jsx          # User profile + settings
│   └── Spectator.jsx        # Free live race viewer
├── components/
│   ├── AppShell.jsx         # Nav + sidebar layout
│   ├── HelpWidget.jsx       # AI help (every screen)
│   └── TrialBanner.jsx      # Trial code activation
├── services/
│   ├── api.js               # Full mock backend (localStorage)
│   ├── gemini.js            # Google Gemini AI integration
│   └── gps.js               # GPS + accelerometer + simulation
├── store/
│   ├── authStore.js         # Auth + trial management (Zustand)
│   └── raceStore.js         # Live race state
└── styles/
    └── global.css           # Full design system
```

---

## 🔑 Features

### 🏁 Racing
- Real-time GPS racing (1–12 racers)
- Ghost vehicle overlay (cyan = spectator, red = leading)
- Split-screen 2-way and 3-way race view
- Route replay and race history
- Simulation mode for desktop/no-GPS

### 📊 Daisy Dyno (DDG)
- 0-60, ⅛ mile, ¼ mile, ½ mile, full mile
- Top speed, braking distance
- G-force tracking (accelerometer)
- Launch analysis and reaction time
- Audio-based RPM estimation (mic)
- OBD2 Bluetooth support architecture

### 👁️ Spectator Mode (FREE)
- Watch any live race
- GPS map + ghost overlay
- Live TikTok-style chat with reactions
- Real-time racer gap analysis

### 💎 Race NFT Marketplace
- Mint races as digital collectibles
- Buy/sell race POV + telemetry
- Rarity tiers: Mythic → Uncommon

### 🎯 DaisyAI Hunting
- Hunt activity scoring (moon + weather + terrain)
- Rut calendar by region
- Trip log + harvest tracking
- Leaderboards + trophy records
- Full gear recommendations

### 💪 Training Hub
- Boxing: punch speed, bag power, combos, rounds
- Lifting: all major lifts + bodyweight
- Agility: shuttle run, balance, jump rope
- 17 leaderboard categories

### ⚽ Sports Hub
- NFL, NBA, MLB, NHL, F1, MMA, Soccer, NASCAR, Boxing, Tennis, Golf, WNBA
- Live scores, standings, DaisyAI analysis
- Pick tracker

---

## 💰 Monetization
- **Free tier**: GPS racing, spectator, social, clubs
- **Elite**: $4.99 one-time or $1.99/mo — Dyno, Ghost Racing, NFTs, Analytics
- **Pro Club**: $9.99/mo — premium clubs, sponsorships
- **2-week trial**: `DAISYGT-FREE-2025`

---

## 🎨 Design System
- **Font Display**: Rajdhani (headers/HUD)
- **Font Mono**: JetBrains Mono (telemetry/data)
- **Font Body**: IBM Plex Sans
- **Primary**: `#e00020` Racing Red
- **Ghost**: `#00e5ff` Electric Cyan
- **Background**: `#0a0a0c` Carbon Black
- **Mode**: Dark only

---

## 🔧 GitHub Actions Setup (Optional)
For auto-deploy, add these GitHub secrets:
- `NETLIFY_AUTH_TOKEN` — from Netlify user settings
- `NETLIFY_SITE_ID` — from your Netlify site settings

---

## ⚠️ Legal
Daisy GT is for entertainment, performance tracking, and data visualization purposes only. Race exclusively on private property, designated tracks, or closed courses. Never race on public roads. DaisyOS is not liable for misuse.

---

*Built with ❤️ for DaisyOS · daisyapps.com*
